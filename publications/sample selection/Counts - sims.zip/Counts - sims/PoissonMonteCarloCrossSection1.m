function PoissonMonteCarloCrossSection1(choice)
% Simulations for Poisson model
% cross-section data
% several user-set bandwidths

display('initiated');

%clear; close all; clc;

%% DESIGN

% parameters
switch choice
    case 1
         % exogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);                      %varrho = -varrho;
            rho =  .0; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;
         
    case 2
         % endogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);                      %varrho = -varrho;
            rho = -.5; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;

    case 3
         % endogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);    % varrho = -varrho;
            rho =  .5; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;
    
    
    
%     case 4
%          % exogeneity 
%          varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);                      %varrho = -varrho;
%             rho =  .0; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
%    
%          beta  =  1.0; 
%          gamma =  1.0;
%          
%     case 5
%          % endogeneity 
%          varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);                      %varrho = -varrho;
%             rho = -.5; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
%    
%          beta  =  1.0; 
%          gamma =  1.0;
% 
%     case 6
%          % endogeneity 
%          varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);    % varrho = -varrho;
%             rho =  .5; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
%    
%          beta  =  1.0; 
%          gamma =  1.0;
 
end


%% VARIATIONS

nn = [250 500]; % sample sizes

for i=1:2, Activate(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,nn(i));  end


function Activate(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n) % ,hh,kern

R = 1000;

for r=1:R, % fea4 fea5 fea6
    [rnk rkstd rankttest naive fea1 fea2 fea3 fea4] = Run(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n); % [rank rkvar rankttest gmm1 gmm2 avar1 avar2 gmmttest1 gmmttest2 gmmJtest1 gmmJtest2 nn]
    
    RNK(r,:) = rnk; RTST(r,:) = rankttest; RSTD(r,:) = rkstd; 
    
    i = 1; GMM1(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    i = 2; GMM2(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    
    i = 3; TST1(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    i = 4; TST2(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    
    i = 5; JST1(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    i = 6; JST2(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    
    i = 7; STD1(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    i = 8; STD2(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    
     
end

STDE = [   std(RNK)    std(GMM1)    std(GMM2)]; SESD = [mean(RSTD) mean(STD1) mean(STD2)                      ]./STDE;  
MEAN = [  mean(RNK)   mean(GMM1)   mean(GMM2)], SIZE = [mean(RTST) mean(TST1) mean(TST2) mean(JST1) mean(JST2)]      ;
MEDN = [median(RNK) median(GMM1) median(GMM2)]; 

PARS = [varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n]; % hh,kern

FILE=strcat('MonteCarlo_crosssection','.xls'); fid=fopen(FILE,'a+');
fprintf(fid,'%g\t',PARS);
fprintf(fid,'%g\t',MEAN); fprintf(fid,'%g\t',MEDN);
fprintf(fid,'%g\t',STDE); fprintf(fid,'%g\t',SESD);
fprintf(fid,'%g\t',SIZE); fprintf(fid, '\n'      );    fclose(fid);


function [rk rkstd rkttest naive fea1 fea2 fea3 fea4] = Run(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n) % fea4 fea5 fea6

L = 2; c = -(sigmaw^2/2);

%% DATA GENERATION

xx = mvnrnd(zeros(2,1),[sigmax^2,varrho*sigmax*sigmaa;varrho*sigmax*sigmaa,sigmaa^2],n); x = xx(:,1); a = xx(:,2); clear xx;
ee = mvnrnd(zeros(2,1),[sigmaw^2,   rho*sigmaw*sigmav;   rho*sigmaw*sigmav,sigmav^2],n); w = ee(:,1); v = ee(:,2); clear ee;

p = x+a*gamma; s = (p>=v); y = random('Poisson',exp(x*beta+w-c)); X = [x a]; clear u v; % nn = sum(s);

y = y.*(s==1)-10.*(s==0); % y(y==-1) = NaN;

%% FIRST-STAGE ESTIMATION and INFERENCE
% rank estimation of gamma
P  = @(theta) x+a*theta; 
DP = @(theta) P(theta)*ones(1,n)-ones(n,1)*P(theta)';
DS =                 s*ones(1,n)-ones(n,1)*s'       ;

%R  = @(theta) mean(mean((DS>0).*(DP(theta)>0))); 
%Rval = -1; rval = 0; ii = -L:.01:L; 
%for i=1:length(ii),  if R(ii(i))>Rval, rval = ii(i); Rval = R(ii(i)); end; end; 
%rk = rval, phat = x+a*rk; clear R Rval rval ii;

h1=  1.06*n^(-1/4);
R  = @(theta) mean(mean((DS>0).*normcdf(DP(theta)/h1))); rk = fminsearch(@(e) -R(e),0); phat = x+a*rk; clear R



% AsyVar estimation from smoothed objective function
h1=  1.06*n^(-1/4);
z =  mean((DS>0)/h1.*normpdf(DP(rk)/h1).*(a*ones(1,n)-ones(n,1)*a')   /h1               ); z =    2*z';
H = -mean((DS>0)/h1.*normpdf(DP(rk)/h1).*(a*ones(1,n)-ones(n,1)*a').^2/h1^2.*(DP(rk)/h1)); H = mean(H);

psi= -inv(H)*z; clear z H; % mean(psi),

% test statistic
rkvar = var(psi); rktstat = sqrt(n)*(rk-gamma)/sqrt(rkvar); rkttest = abs(rktstat)>=norminv(.975); rkstd = sqrt(rkvar)/sqrt(n);

%% SECOND-STAGE ESTIMATION and INFERENCE
% naive estimation and inference on beta
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,1,0,1,0,p,phat,psi,beta); naive = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];


hh = [1 1.5 2.5 3];
%hh = [.25 .5 1 2 3 4]; % bandwidth factors: h = hh*n^(-1/7)
%hh = [2 3 4]; % bandwidth factors: h = hh*n^(-1/7)
%kf = [0   1]; % higher-order kernel: no/yes
kf = [1 0];
%hh = [1 2 4]; % bandwidth factors: h = hh*n^(-1/7)
%kf = [0   1]; % higher-order kernel: no/yes

% feasible inference: bandwidth variations for 4th-order kernel
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,0,1,hh(1),kf(1),p,phat,psi,beta); fea1 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,0,1,hh(2),kf(1),p,phat,psi,beta); fea2 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,0,1,hh(3),kf(1),p,phat,psi,beta); fea3 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,0,1,hh(4),kf(1),p,phat,psi,beta); fea4 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];

%[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,0,1,hh(4),kf(1),p,phat,psi,beta); fea4 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];
%[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,0,1,hh(5),kf(1),p,phat,psi,beta); fea5 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];
%[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,0,1,hh(6),kf(1),p,phat,psi,beta); fea6 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];



function [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,naive,feasible,hh,kern,p,phat,psi,beta)

n = length(s); nn = sum(s); x = X(:,1); a = X(:,2);

G = @(e) exp(e); g = @(e) G(e); 

tau  = @(theta) y./G(x*theta)                             ;  dtau = @(theta) -x.*tau(theta)                              ;  
Dtau = @(theta) tau(theta)*ones(1,n)-ones(n,1)*tau(theta)'; Ddtau = @(theta) dtau(theta)*ones(1,n)-ones(n,1)*dtau(theta)';

omega  = @(theta,i) -X(:,i)                           ;                  domega = @(theta,i) zeros(n,1)                                          ;
Domega = @(theta,i) omega(theta,i)*ones(1,n)-ones(n,1)*omega(theta,i)'; Ddomega = @(theta,i) domega(theta,i)*ones(1,n)-ones(n,1)*domega(theta,i)'; 


switch kern
    
    case 0
         obs   = (s*ones(1,n)).*(ones(n,1)*s')             ; h2          =    hh*n^(-1/7); 
         i_arg = p   *ones(1,n)-ones(n,1)*p'   /(std(p   )); i_ker = normpdf(i_arg/h2)/h2;
         f_arg = phat*ones(1,n)-ones(n,1)*phat'/(std(phat)); f_ker = normpdf(f_arg/h2)/h2;
         
    case 1
         obs   = (s*ones(1,n)).*(ones(n,1)*s')             ; h2                                   =    hh*n^(-1/7); 
         i_arg = p   *ones(1,n)-ones(n,1)*p'   /(std(p   )); i_ker = normpdf(i_arg/h2).*(3/2-1/2*(i_arg/h2).^2)/h2;
         f_arg = phat*ones(1,n)-ones(n,1)*phat'/(std(phat)); f_ker = normpdf(f_arg/h2).*(3/2-1/2*(f_arg/h2).^2)/h2;
         
end
        

% moments
uq = @(theta,i) mean(mean(Domega(theta,i).*Dtau(theta).*obs          )); 
iq = @(theta,i) mean(mean(Domega(theta,i).*Dtau(theta).*obs.*i_ker));
fq = @(theta,i) mean(mean(Domega(theta,i).*Dtau(theta).*obs.*f_ker));
%iq = @(theta,i) mean(mean(Domega(theta,i).*Dtau(theta).*obs.*i_ker/h2));
%fq = @(theta,i) mean(mean(Domega(theta,i).*Dtau(theta).*obs.*f_ker/h2));

% Jacobian and derivative functions
% averaged scores
uzeta = @(theta,i) mean(Domega(theta,i).*Dtau(theta).*obs          ,2); 
izeta = @(theta,i) mean(Domega(theta,i).*Dtau(theta).*obs.*i_ker,2);
fzeta = @(theta,i) mean(Domega(theta,i).*Dtau(theta).*obs.*f_ker,2);
% Jacobian
uQ = @(theta,i) mean(mean(Ddomega(theta,i).*Dtau(theta).*obs          ))+mean(mean(Domega(theta,i).*Ddtau(theta).*obs    ));
iQ = @(theta,i) mean(mean(Ddomega(theta,i).*Dtau(theta).*obs.*i_ker))+mean(mean(Domega(theta,i).*Ddtau(theta).*obs.*i_ker));
fQ = @(theta,i) mean(mean(Ddomega(theta,i).*Dtau(theta).*obs.*f_ker))+mean(mean(Domega(theta,i).*Ddtau(theta).*obs.*f_ker));
%iQ = @(theta,i) mean(mean(Ddomega(theta,i).*Dtau(theta).*obs.*i_ker/h2))+mean(mean(Domega(theta,i).*Ddtau(theta).*obs.*i_ker/h2));
%fQ = @(theta,i) mean(mean(Ddomega(theta,i).*Dtau(theta).*obs.*i_ker/h2))+mean(mean(Domega(theta,i).*Ddtau(theta).*obs.*f_ker/h2));
% penalty for feasibility
switch kern
    
    case 0
        H = @(theta,i) mean(mean((Domega(theta,i).*Dtau(theta).*obs).*(-f_ker.*f_arg/h2)                         .*(a*ones(1,n)-ones(n,1)*a')/(h2*std(phat))));
        %H = @(theta,i) mean(mean((Domega(theta,i).*Dtau(theta).*obs).*(-f_ker/h2.*f_arg/h2)                         .*(a*ones(1,n)-ones(n,1)*a')/(h2*std(phat)))); % not based on higher-order kernel
        tzeta = @(theta,i) fzeta(theta,i)+H(theta,i)*psi;

         
    case 1
        H = @(theta,i) mean(mean((Domega(theta,i).*Dtau(theta).*obs).*(-f_ker.*f_arg/h2).*(5/2+1/2*(f_arg/h2).^2).*(a*ones(1,n)-ones(n,1)*a')/(h2*std(phat))));
        %H = @(theta,i) mean(mean((Domega(theta,i).*Dtau(theta).*obs).*(-f_ker/h2.*f_arg/h2).*(5/2+1/2*(f_arg/h2).^2).*(a*ones(1,n)-ones(n,1)*a')/(h2*std(phat)))); %     based on higher-order kernel
        tzeta = @(theta,i) fzeta(theta,i)+H(theta,i)*psi;        
end


%% ONE-STEP ESTIMATION AND INFERENCE

switch naive 
    case 1
         R = @(theta) [uq(theta,1),uq(theta,2)]*[uq(theta,1);uq(theta,2)]; gmm1 = fminsearch(@(e) R(e),0); clear R;
         u_influence = [uzeta(gmm1,1),uzeta(gmm1,2)]; uSigma = 4*cov(u_influence);
         uD = [uQ(gmm1,1),uQ(gmm1,2)]*[uQ(gmm1,1);uQ(gmm1,2)]; %uD = 1/uD;
         uX = [uQ(gmm1,1),uQ(gmm1,2)]*uSigma*[uQ(gmm1,1);uQ(gmm1,2)];
         uvar = inv(uD)*uX*inv(uD); utstat = sqrt(n)*(gmm1-beta)/sqrt(uvar); ttest1 = abs(utstat)>=norminv(.975);  std1 = sqrt(uvar)/sqrt(n);
         uJstat = n*[uq(gmm1,1),uq(gmm1,2)]*inv(uSigma)*[uq(gmm1,1);uq(gmm1,2)]; jtest1 = uJstat>=chi2inv(.95,1);
    case 0
         switch feasible  
             case 0
                 R = @(theta) [iq(theta,1),iq(theta,2)]*[iq(theta,1);iq(theta,2)]; gmm1 = fminsearch(@(e) R(e),0); clear R;
                 i_influence = [izeta(gmm1,1),izeta(gmm1,2)]; iSigma = 4*cov(i_influence);
                 iD = [iQ(gmm1,1),iQ(gmm1,2)]*[iQ(gmm1,1);iQ(gmm1,2)]; %iD = 1/iD;
                 iX = [iQ(gmm1,1),iQ(gmm1,2)]*iSigma*[iQ(gmm1,1);iQ(gmm1,2)]; 
                 ivar = inv(iD)*iX*inv(iD); itstat = sqrt(n)*(gmm1-beta)/sqrt(ivar); ttest1 = abs(itstat)>=norminv(.975); std1 = sqrt(ivar)/sqrt(n);
                 iJstat = n*[iq(gmm1,1),iq(gmm1,2)]*inv(iSigma)*[iq(gmm1,1);iq(gmm1,2)]; jtest1 = iJstat>=chi2inv(.95,1);
             case 1
                 R = @(theta) [fq(theta,1),fq(theta,2)]*[fq(theta,1);fq(theta,2)]; gmm1 = fminsearch(@(e) R(e),0); clear R;
                 f_influence = [tzeta(gmm1,1),tzeta(gmm1,2)]; fSigma = 4*cov(f_influence);
                 fD = [fQ(gmm1,1),fQ(gmm1,2)]*[fQ(gmm1,1);fQ(gmm1,2)]; %fD = 1/fD;
                 fX = [fQ(gmm1,1),fQ(gmm1,2)]*fSigma*[fQ(gmm1,1);fQ(gmm1,2)];
                 fvar = inv(fD)*fX*inv(fD); ftstat = sqrt(n)*(gmm1-beta)/sqrt(fvar); ttest1 = abs(ftstat)>=norminv(.975); std1 = sqrt(fvar)/sqrt(n);
                 fJstat = n*[fq(gmm1,1),fq(gmm1,2)]*inv(fSigma)*[fq(gmm1,1);fq(gmm1,2)]; jtest1 = fJstat>=chi2inv(.95,1);
        end
end

%% TWO-STEP ESTIMATION AND INFERENCE

switch naive 
    case 1
         R = @(theta) [uq(theta,1),uq(theta,2)]*inv(uSigma)*[uq(theta,1);uq(theta,2)]; gmm2 = fminsearch(@(e) R(e),0); clear R;
         u_influence = [uzeta(gmm2,1),uzeta(gmm2,2)]; uSigma = 4*cov(u_influence);
         uX = [uQ(gmm2,1),uQ(gmm2,2)]*inv(uSigma)*[uQ(gmm2,1);uQ(gmm2,2)];
         uvar = inv(uX); utstat = sqrt(n)*(gmm2-beta)/sqrt(uvar); ttest2 = abs(utstat)>=norminv(.975); std2 = sqrt(uvar)/sqrt(n);
         uJstat = n*[uq(gmm2,1),uq(gmm2,2)]*inv(uSigma)*[uq(gmm2,1);uq(gmm2,2)]; jtest2 = uJstat>=chi2inv(.95,1);
    case 0
         switch feasible  
             case 0
                  R = @(theta) [iq(theta,1),iq(theta,2)]*inv(iSigma)*[iq(theta,1);iq(theta,2)]; gmm2 = fminsearch(@(e) R(e),0); clear R;
                  i_influence = [izeta(gmm2,1),izeta(gmm2,2)]; iSigma = 4*cov(i_influence);
                  iX = [iQ(gmm2,1),iQ(gmm2,2)]*inv(iSigma)*[iQ(gmm2,1);iQ(gmm2,2)]; 
                  ivar = inv(iX); itstat = sqrt(n)*(gmm2-beta)/sqrt(ivar); ttest2 = abs(itstat)>=norminv(.975); std2 = sqrt(ivar)/sqrt(n);
                  iJstat = n*[iq(gmm2,1),iq(gmm2,2)]*inv(iSigma)*[iq(gmm2,1);iq(gmm2,2)]; jtest2 = iJstat>=chi2inv(.95,1); 
             case 1
                  R = @(theta) [fq(theta,1),fq(theta,2)]*inv(fSigma)*[fq(theta,1);fq(theta,2)]; gmm2 = fminsearch(@(e) R(e),0); clear R;
                  f_influence = [tzeta(gmm2,1),tzeta(gmm2,2)]; fSigma = 4*cov(f_influence);
                  fX = [fQ(gmm2,1),fQ(gmm2,2)]*inv(fSigma)*[fQ(gmm2,1);fQ(gmm2,2)];
                  fvar = inv(fX); ftstat = sqrt(n)*(gmm2-beta)/sqrt(fvar); ttest2 = abs(ftstat)>=norminv(.975); std2 = sqrt(fvar)/sqrt(n);
                  fJstat = n*[fq(gmm2,1),fq(gmm2,2)]*inv(fSigma)*[fq(gmm2,1);fq(gmm2,2)]; jtest2 = fJstat>=chi2inv(.95,1);
 
         end
end
