function PoissonMonteCarloPanel1(choice)
% Simulations for Poisson model
% panel data
% several user-set bandwidths

display('initiated');

%clear; close all; clc;

%% DESIGN

% parameters
switch choice
    case 1
         % exogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);                      %varrho = -varrho;
            rho =  .0; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;
         
    case 2
         % endogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);                      %varrho = -varrho;
            rho = -.5; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;

    case 3
         % endogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);    % varrho = -varrho;
            rho =  .5; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;
    

 
end


%% VARIATIONS

nn = [500 1000]; % sample sizes

for i=1:2, Activate(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,nn(i));  end


function Activate(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n) % ,hh,kern

R = 1000;

for r=1:R, % fea4 fea5 fea6
    [rnk naive fea1 fea2 fea3 fea4] = Run(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n); % [rank rkvar rankttest gmm1 gmm2 avar1 avar2 gmmttest1 gmmttest2 gmmJtest1 gmmJtest2 nn]
    
    RNK(r,:) = rnk;  
    
    i = 1; GMM1(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    i = 2; GMM2(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    
    i = 3; TST1(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    i = 4; TST2(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    
    i = 5; JST1(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    i = 6; JST2(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    
    i = 7; STD1(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    i = 8; STD2(r,:) = [naive(i), fea1(i) fea2(i) fea3(i) fea4(i)];
    
     
end

STDE = [ std(GMM1)    std(GMM2)]; SESD = [mean(STD1) mean(STD2)                      ]./STDE;  
MEAN = [ mean(GMM1)   mean(GMM2)], SIZE = [mean(TST1) mean(TST2) mean(JST1) mean(JST2)]      ;
MEDN = [ median(GMM1) median(GMM2)]; 

PARS = [varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n]; % hh,kern

FILE=strcat('MonteCarlo_paneldata','.xls'); fid=fopen(FILE,'a+');
fprintf(fid,'%g\t',PARS);
fprintf(fid,'%g\t',MEAN); fprintf(fid,'%g\t',MEDN);
fprintf(fid,'%g\t',STDE); fprintf(fid,'%g\t',SESD);
fprintf(fid,'%g\t',SIZE); fprintf(fid, '\n'      );    fclose(fid);


function [rk naive fea1 fea2 fea3 fea4] = Run(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n) % fea4 fea5 fea6

L = 2; c = -(sigmaw^2/2);

%% DATA GENERATION

% time period 1
xx = mvnrnd(zeros(2,1),[sigmax^2,varrho*sigmax*sigmaa;varrho*sigmax*sigmaa,sigmaa^2],n); x = xx(:,1); a = xx(:,2); clear xx;
ee = mvnrnd(zeros(2,1),[sigmaw^2,   rho*sigmaw*sigmav;   rho*sigmaw*sigmav,sigmav^2],n); w = ee(:,1); v = ee(:,2); clear ee;

p = x+a*gamma; s = (p>=v); y = random('Poisson',exp(x*beta+w-c)); X = [x a]; clear u v; % nn = sum(s);

y = y.*(s==1)-10.*(s==0); % y(y==-1) = NaN;

X1 = X; y1 = y; s1 = s;

% time period 2
xx = mvnrnd(zeros(2,1),[sigmax^2,varrho*sigmax*sigmaa;varrho*sigmax*sigmaa,sigmaa^2],n); x = xx(:,1); a = xx(:,2); clear xx;
ee = mvnrnd(zeros(2,1),[sigmaw^2,   rho*sigmaw*sigmav;   rho*sigmaw*sigmav,sigmav^2],n); w = ee(:,1); v = ee(:,2); clear ee;

p = x+a*gamma; s = (p>=v); y = random('Poisson',exp(x*beta+w-c)); X = [x a]; clear u v; % nn = sum(s);

y = y.*(s==1)-10.*(s==0); % y(y==-1) = NaN;

X2 = X; y2 = y; s2 = s;

%% FIRST-STAGE ESTIMATION
% score estimation of gamma
P1 = @(theta) X1(:,1)+X1(:,2)*theta;
P2 = @(theta) X2(:,1)+X2(:,2)*theta;
DP = @(theta) P2(theta)-P1(theta);
DS =          s2       -s1       ;

h1=  1.06*n^(-1/4);
R  = @(theta) mean(DS.*normcdf(DP(theta)/h1)); rk = fminsearch(@(e) -R(e),0); 

phat1 = X1(:,1)+X1(:,2)*rk; 
phat2 = X2(:,1)+X2(:,2)*rk; clear R


%% SECOND-STAGE ESTIMATION and INFERENCE
% naive estimation and inference on beta
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y1,y2,X1,X2,s1,s2,1,0,0,phat1,phat2,beta); naive = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];

hh = [.5 1 1.5 2.5];
kf = [1 0];

% feasible inference: bandwidth variations for 4th-order kernel
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y1,y2,X1,X2,s1,s2,0,hh(1),kf(1),phat1,phat2,beta); fea1 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y1,y2,X1,X2,s1,s2,0,hh(2),kf(1),phat1,phat2,beta); fea2 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y1,y2,X1,X2,s1,s2,0,hh(3),kf(1),phat1,phat2,beta); fea3 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y1,y2,X1,X2,s1,s2,0,hh(4),kf(1),phat1,phat2,beta); fea4 = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];


function [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y1,y2,X1,X2,s1,s2,naive,h,kern,phat1,phat2,beta)

n = length(s1); x1 = X1(:,1); a1 = X1(:,2); x2 = X2(:,1); a2 = X2(:,2);

G = @(e) exp(e); g = @(e) G(e); 

tau1  = @(theta) y1./G(x1*theta)        ; dtau1 = @(theta) -x1.*tau1(theta)         ;
tau2  = @(theta) y2./G(x2*theta)        ; dtau2 = @(theta) -x2.*tau2(theta)         ;
Dtau  = @(theta) tau2(theta)-tau1(theta); Ddtau = @(theta) dtau2(theta)-dtau1(theta);

Domega = @(i) -(X2(:,i)-X1(:,i));


switch kern
    case 0
         obs   =  s1.*s2                       ; h2    =                  h*n^(-1/7); 
         f_arg = (phat2-phat1)/std(phat2-phat1); f_ker =  normpdf(f_arg/h2)/h2; 
         
    case 1
         obs   =  s1.*s2                       ; h2    =                  h*n^(-1/7); 
         f_arg = (phat2-phat1)/std(phat2-phat1); f_ker =  normpdf(f_arg/h2).*(3/2-1/2*(f_arg/h2).^2)/h2;        
end
        

% moments
uq = @(theta,i) mean(Domega(i).*Dtau(theta).*obs       ); 
fq = @(theta,i) mean(Domega(i).*Dtau(theta).*obs.*f_ker);

% Jacobian and derivative functions
% averaged scores
uzeta = @(theta,i) Domega(i).*Dtau(theta).*obs       ; 
fzeta = @(theta,i) Domega(i).*Dtau(theta).*obs.*f_ker;
% Jacobian
uQ = @(theta,i) mean(mean(Domega(i).*Ddtau(theta).*obs       ));
fQ = @(theta,i) mean(mean(Domega(i).*Ddtau(theta).*obs.*f_ker));



%% ONE-STEP ESTIMATION AND INFERENCE

options = optimset('Display', 'off','GradObj','off','LargeScale','off','Algorithm','active-set');

switch naive 
    case 1
         R = @(theta) [uq(theta,1),uq(theta,2)]*[uq(theta,1);uq(theta,2)]; gmm1 = fminsearch(@(e) R(e),0); clear R;
         u_influence = [uzeta(gmm1,1),uzeta(gmm1,2)]; uSigma = cov(u_influence);
         uD = [uQ(gmm1,1),uQ(gmm1,2)]*[uQ(gmm1,1);uQ(gmm1,2)]; %uD = 1/uD;
         uX = [uQ(gmm1,1),uQ(gmm1,2)]*uSigma*[uQ(gmm1,1);uQ(gmm1,2)];
         uvar = inv(uD)*uX*inv(uD); utstat = sqrt(n)*(gmm1-beta)/sqrt(uvar); ttest1 = abs(utstat)>=norminv(.975);  std1 = sqrt(uvar)/sqrt(n);
         uJstat = n*[uq(gmm1,1),uq(gmm1,2)]*inv(uSigma)*[uq(gmm1,1);uq(gmm1,2)]; jtest1 = uJstat>=chi2inv(.95,1);
    case 0

          R = @(theta) [fq(theta,1),fq(theta,2)]*[fq(theta,1);fq(theta,2)]; gmm1 = fminsearch(@(e) R(e),0); clear R; rate = h2;
          f_influence = [fzeta(gmm1,1),fzeta(gmm1,2)]; fSigma = cov(f_influence)*rate;
          fD = [fQ(gmm1,1),fQ(gmm1,2)]*[fQ(gmm1,1);fQ(gmm1,2)]; %fD = 1/fD;
          fX = [fQ(gmm1,1),fQ(gmm1,2)]*fSigma*[fQ(gmm1,1);fQ(gmm1,2)]; 
          fvar = inv(fD)*fX*inv(fD); ftstat = sqrt(n*rate)*(gmm1-beta)/sqrt(fvar); ttest1 = abs(ftstat)>=norminv(.975); std1 = sqrt(fvar)/sqrt(n*rate);
          fJstat = (n*rate)*[fq(gmm1,1),fq(gmm1,2)]*inv(fSigma)*[fq(gmm1,1);fq(gmm1,2)]; jtest1 = fJstat>=chi2inv(.95,1);
end

%% TWO-STEP ESTIMATION AND INFERENCE

switch naive 
    case 1
         R = @(theta) [uq(theta,1),uq(theta,2)]*inv(uSigma)*[uq(theta,1);uq(theta,2)]; gmm2 = fminsearch(@(e) R(e),0); clear R;
         u_influence = [uzeta(gmm2,1),uzeta(gmm2,2)]; uSigma = cov(u_influence);
         uX = [uQ(gmm2,1),uQ(gmm2,2)]*inv(uSigma)*[uQ(gmm2,1);uQ(gmm2,2)];
         uvar = inv(uX); utstat = sqrt(n)*(gmm2-beta)/sqrt(uvar); ttest2 = abs(utstat)>=norminv(.975); std2 = sqrt(uvar)/sqrt(n);
         uJstat = n*[uq(gmm2,1),uq(gmm2,2)]*inv(uSigma)*[uq(gmm2,1);uq(gmm2,2)]; jtest2 = uJstat>=chi2inv(.95,1);
    case 0
         R = @(theta) [fq(theta,1),fq(theta,2)]*inv(fSigma)*[fq(theta,1);fq(theta,2)]; gmm2 = fminsearch(@(e) R(e),0); clear R; rate = h2;
         f_influence = [fzeta(gmm2,1),fzeta(gmm2,2)]; fSigma = cov(f_influence)*rate;
         fX = [fQ(gmm2,1),fQ(gmm2,2)]*inv(fSigma)*[fQ(gmm2,1);fQ(gmm2,2)];
         fvar = inv(fX); ftstat = sqrt(n*rate)*(gmm2-beta)/sqrt(fvar); ttest2 = abs(ftstat)>=norminv(.975); std2 = sqrt(fvar)/sqrt(n*rate);
         fJstat = (n*rate)*[fq(gmm2,1),fq(gmm2,2)]*inv(fSigma)*[fq(gmm2,1);fq(gmm2,2)]; jtest2 = fJstat>=chi2inv(.95,1);

end
