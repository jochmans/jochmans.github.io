function PoissonMonteCarloCrossSection2(choice)
% Simulations for Poisson model
% cross-section data
% automated bandwidth

display('initiated');

%clear; close all; clc;

%% DESIGN

% parameters
switch choice
    case 1
         % exogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);                      %varrho = -varrho;
            rho =  .0; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;
         
    case 2
         % endogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);                      %varrho = -varrho;
            rho = -.5; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;

    case 3
         % endogeneity 
         varrho = -.5; sigmax = sqrt(1/2); sigmaa = sqrt(1/2);    % varrho = -varrho;
            rho =  .5; sigmaw = sqrt(1/2); sigmav = 1        ; C = exp(sigmaw^2/2); %rho = -rho;
   
         beta  =  1.0; 
         gamma = -1.0;
    

 
end


%% VARIATIONS

nn = [250 500]; % sample sizes

for i=1:2, Activate(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,nn(i));  end


function Activate(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n) % ,hh,kern

R = 1000;

for r=1:R, % fea4 fea5 fea6
    [rnk rkstd rankttest naive fea] = Run(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n); % [rank rkvar rankttest gmm1 gmm2 avar1 avar2 gmmttest1 gmmttest2 gmmJtest1 gmmJtest2 nn]
    
    RNK(r,:) = rnk; RTST(r,:) = rankttest; RSTD(r,:) = rkstd; 
    
    i = 1; GMM1(r,:) = [naive(i), fea(i)];
    i = 2; GMM2(r,:) = [naive(i), fea(i)];
    
    i = 3; TST1(r,:) = [naive(i), fea(i)];
    i = 4; TST2(r,:) = [naive(i), fea(i)];
    
    i = 5; JST1(r,:) = [naive(i), fea(i)];
    i = 6; JST2(r,:) = [naive(i), fea(i)];
    
    i = 7; STD1(r,:) = [naive(i), fea(i)];
    i = 8; STD2(r,:) = [naive(i), fea(i)];
    
     
end

STDE = [   std(RNK)    std(GMM1)    std(GMM2)]; SESD = [mean(RSTD) mean(STD1) mean(STD2)                      ]./STDE;  
MEAN = [  mean(RNK)   mean(GMM1)   mean(GMM2)], SIZE = [mean(RTST) mean(TST1) mean(TST2) mean(JST1) mean(JST2)]      ;
MEDN = [median(RNK) median(GMM1) median(GMM2)]; 

PARS = [varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n]; % hh,kern

FILE=strcat('MonteCarlo_crosssection_automated','.xls'); fid=fopen(FILE,'a+');
fprintf(fid,'%g\t',PARS);
fprintf(fid,'%g\t',MEAN); fprintf(fid,'%g\t',MEDN);
fprintf(fid,'%g\t',STDE); fprintf(fid,'%g\t',SESD);
fprintf(fid,'%g\t',SIZE); fprintf(fid, '\n'      );    fclose(fid);


function [rk rkstd rkttest naive fea] = Run(varrho,rho,sigmax,sigmaw,sigmaa,sigmav,beta,gamma,n) % fea4 fea5 fea6

L = 2; c = -(sigmaw^2/2);

%% DATA GENERATION

xx = mvnrnd(zeros(2,1),[sigmax^2,varrho*sigmax*sigmaa;varrho*sigmax*sigmaa,sigmaa^2],n); x = xx(:,1); a = xx(:,2); clear xx;
ee = mvnrnd(zeros(2,1),[sigmaw^2,   rho*sigmaw*sigmav;   rho*sigmaw*sigmav,sigmav^2],n); w = ee(:,1); v = ee(:,2); clear ee;

p = x+a*gamma; s = (p>=v); y = random('Poisson',exp(x*beta+w-c)); X = [x a]; clear u v; % nn = sum(s);

y = y.*(s==1)-10.*(s==0); % y(y==-1) = NaN;

%% FIRST-STAGE ESTIMATION and INFERENCE
% rank estimation of gamma
P  = @(theta) x+a*theta; 
DP = @(theta) P(theta)*ones(1,n)-ones(n,1)*P(theta)';
DS =                 s*ones(1,n)-ones(n,1)*s'       ;

%R  = @(theta) mean(mean((DS>0).*(DP(theta)>0))); 
%Rval = -1; rval = 0; ii = -L:.01:L; 
%for i=1:length(ii),  if R(ii(i))>Rval, rval = ii(i); Rval = R(ii(i)); end; end; 
%rk = rval, phat = x+a*rk; clear R Rval rval ii;

h1=  1.06*n^(-1/4);
R  = @(theta) mean(mean((DS>0).*normcdf(DP(theta)/h1))); rk = fminsearch(@(e) -R(e),0); phat = x+a*rk; clear R



% AsyVar estimation from smoothed objective function
h1=  1.06*n^(-1/4);
z =  mean((DS>0)/h1.*normpdf(DP(rk)/h1).*(a*ones(1,n)-ones(n,1)*a')   /h1               ); z =    2*z';
H = -mean((DS>0)/h1.*normpdf(DP(rk)/h1).*(a*ones(1,n)-ones(n,1)*a').^2/h1^2.*(DP(rk)/h1)); H = mean(H);

psi= -inv(H)*z; clear z H; % mean(psi),

% test statistic
rkvar = var(psi); rktstat = sqrt(n)*(rk-gamma)/sqrt(rkvar); rkttest = abs(rktstat)>=norminv(.975); rkstd = sqrt(rkvar)/sqrt(n);

%% SECOND-STAGE ESTIMATION and INFERENCE
% naive estimation and inference on beta
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,1,0,0,p,phat,psi,beta); naive = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];


kf = [1 0];


% feasible inference: bandwidth variations for 4th-order kernel
[gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,0,1,kf(1),p,phat,psi,beta); fea = [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2];


function [gmm1 gmm2 ttest1 ttest2 jtest1 jtest2 std1 std2] = GMM(y,X,s,naive,feasible,kern,p,phat,psi,beta)

n = length(s); nn = sum(s); x = X(:,1); a = X(:,2);

G = @(e) exp(e); g = @(e) G(e); 

tau  = @(theta) y./G(x*theta)                             ;  dtau = @(theta) -x.*tau(theta)                              ;  
Dtau = @(theta) tau(theta)*ones(1,n)-ones(n,1)*tau(theta)'; Ddtau = @(theta) dtau(theta)*ones(1,n)-ones(n,1)*dtau(theta)';

omega  = @(theta,i) -X(:,i)                           ;                  domega = @(theta,i) zeros(n,1)                                          ;
Domega = @(theta,i) omega(theta,i)*ones(1,n)-ones(n,1)*omega(theta,i)'; Ddomega = @(theta,i) domega(theta,i)*ones(1,n)-ones(n,1)*domega(theta,i)'; 


switch kern
    
    case 0
         obs   = (s*ones(1,n)).*(ones(n,1)*s')             ; h2    = @(h)           h*n^(-1/7); 
         i_arg = p   *ones(1,n)-ones(n,1)*p'   /(std(p   )); i_ker = @(h) normpdf(i_arg/h2(h))/h2(h); % changed
         f_arg = phat*ones(1,n)-ones(n,1)*phat'/(std(phat)); f_ker = @(h) normpdf(f_arg/h2(h))/h2(h); % changed
         
    case 1
         obs   = (s*ones(1,n)).*(ones(n,1)*s')             ; h2    = @(h)                                       h*n^(-1/7); 
         i_arg = p   *ones(1,n)-ones(n,1)*p'   /(std(p   )); i_ker = @(h) normpdf(i_arg/h2(h)).*(3/2-1/2*(i_arg/h2(h)).^2)/h2(h); % changed
         f_arg = phat*ones(1,n)-ones(n,1)*phat'/(std(phat)); f_ker = @(h) normpdf(f_arg/h2(h)).*(3/2-1/2*(f_arg/h2(h)).^2)/h2(h); % changed
         
end
        

% moments
uq = @(theta,i)   mean(mean(Domega(theta,i).*Dtau(theta).*obs          )); 
iq = @(theta,h,i) mean(mean(Domega(theta,i).*Dtau(theta).*obs.*i_ker(h)));
fq = @(theta,h,i) mean(mean(Domega(theta,i).*Dtau(theta).*obs.*f_ker(h)));

% Jacobian and derivative functions
% averaged scores
uzeta = @(theta,i)   mean(Domega(theta,i).*Dtau(theta).*obs          ,2); 
izeta = @(theta,h,i) mean(Domega(theta,i).*Dtau(theta).*obs.*i_ker(h),2);
fzeta = @(theta,h,i) mean(Domega(theta,i).*Dtau(theta).*obs.*f_ker(h),2);
% Jacobian
uQ = @(theta,i)   mean(mean(Ddomega(theta,i).*Dtau(theta).*obs          ))+mean(mean(Domega(theta,i).*Ddtau(theta).*obs          ));
iQ = @(theta,h,i) mean(mean(Ddomega(theta,i).*Dtau(theta).*obs.*i_ker(h)))+mean(mean(Domega(theta,i).*Ddtau(theta).*obs.*i_ker(h)));
fQ = @(theta,h,i) mean(mean(Ddomega(theta,i).*Dtau(theta).*obs.*f_ker(h)))+mean(mean(Domega(theta,i).*Ddtau(theta).*obs.*f_ker(h)));

% penalty for feasibility
switch kern
    
    case 0
        H     = @(theta,h,i) mean(mean((Domega(theta,i).*Dtau(theta).*obs).*(-f_ker(h).*f_arg/h2(h)).*(a*ones(1,n)-ones(n,1)*a')/(h2(h)*std(phat))));
        tzeta = @(theta,h,i) fzeta(theta,h,i)+H(theta,h,i)*psi;

         
    case 1
        H     = @(theta,h,i) mean(mean((Domega(theta,i).*Dtau(theta).*obs).*(-f_ker(h).*f_arg/h2(h)).*(5/2+1/2*(f_arg/h2(h)).^2).*(a*ones(1,n)-ones(n,1)*a')/(h2(h)*std(phat))));
        tzeta = @(theta,h,i) fzeta(theta,h,i)+H(theta,h,i)*psi;        
end


%% ONE-STEP ESTIMATION AND INFERENCE

options = optimset('Display', 'off','GradObj','off','LargeScale','off','Algorithm','active-set');

switch naive 
    case 1
         R = @(theta) [uq(theta,1),uq(theta,2)]*[uq(theta,1);uq(theta,2)]; gmm1 = fminsearch(@(e) R(e),0); clear R;
         u_influence = [uzeta(gmm1,1),uzeta(gmm1,2)]; uSigma = 4*cov(u_influence);
         uD = [uQ(gmm1,1),uQ(gmm1,2)]*[uQ(gmm1,1);uQ(gmm1,2)]; %uD = 1/uD;
         uX = [uQ(gmm1,1),uQ(gmm1,2)]*uSigma*[uQ(gmm1,1);uQ(gmm1,2)];
         uvar = inv(uD)*uX*inv(uD); utstat = sqrt(n)*(gmm1-beta)/sqrt(uvar); ttest1 = abs(utstat)>=norminv(.975);  std1 = sqrt(uvar)/sqrt(n);
         uJstat = n*[uq(gmm1,1),uq(gmm1,2)]*inv(uSigma)*[uq(gmm1,1);uq(gmm1,2)]; jtest1 = uJstat>=chi2inv(.95,1);
    case 0
         switch feasible  
             case 0
                 R = @(theta) [iq(theta(1),theta(2)^2,1),iq(theta(1),theta(2)^2,2)]*[iq(theta(1),theta(2)^2,1);iq(theta(1),theta(2)^2,2)]; theta_hat = fmincon(@(e) R(e),[1;1],[],[],[],[],[-5,.1],[5,5],[],options); clear R; gmm1 = theta_hat(1); h = theta_hat(2)^2; %theta_hat = fminsearch(@(e) R(e),[1;1]); clear R; gmm1 = theta_hat(1); h = theta_hat(2);
                 i_influence = [izeta(gmm1,h,1),izeta(gmm1,h,2)]; iSigma = 4*cov(i_influence);
                 iD = [iQ(gmm1,h,1),iQ(gmm1,h,2)]*[iQ(gmm1,h,1);iQ(gmm1,h,2)]; %iD = 1/iD;
                 iX = [iQ(gmm1,h,1),iQ(gmm1,h,2)]*iSigma*[iQ(gmm1,h,1);iQ(gmm1,h,2)]; 
                 ivar = inv(iD)*iX*inv(iD); itstat = sqrt(n)*(gmm1-beta)/sqrt(ivar); ttest1 = abs(itstat)>=norminv(.975); std1 = sqrt(ivar)/sqrt(n);
                 iJstat = n*[iq(gmm1,h,1),iq(gmm1,h,2)]*inv(iSigma)*[iq(gmm1,h,1);iq(gmm1,h,2)]; jtest1 = iJstat>=chi2inv(.95,1);
             case 1
                 R = @(theta) [fq(theta(1),theta(2)^2,1),fq(theta(1),theta(2)^2,2)]*[fq(theta(1),theta(2)^2,1);fq(theta(1),theta(2)^2,2)]; theta_hat = fmincon(@(e) R(e),[1;1],[],[],[],[],[-5,.1],[5,5],[],options); clear R; gmm1 = theta_hat(1); h = theta_hat(2)^2; % theta_hat = fminsearch(@(e) R(e),[1;1]), clear R; gmm1 = theta_hat(1); h = theta_hat(2);
                 f_influence = [tzeta(gmm1,h,1),tzeta(gmm1,h,2)]; fSigma = 4*cov(f_influence);
                 fD = [fQ(gmm1,h,1),fQ(gmm1,h,2)]*[fQ(gmm1,h,1);fQ(gmm1,h,2)]; %fD = 1/fD;
                 fX = [fQ(gmm1,h,1),fQ(gmm1,h,2)]*fSigma*[fQ(gmm1,h,1);fQ(gmm1,h,2)];
                 fvar = inv(fD)*fX*inv(fD); ftstat = sqrt(n)*(gmm1-beta)/sqrt(fvar); ttest1 = abs(ftstat)>=norminv(.975); std1 = sqrt(fvar)/sqrt(n);
                 fJstat = n*[fq(gmm1,h,1),fq(gmm1,h,2)]*inv(fSigma)*[fq(gmm1,h,1);fq(gmm1,h,2)]; jtest1 = fJstat>=chi2inv(.95,1);
        end
end

%% TWO-STEP ESTIMATION AND INFERENCE

switch naive 
    case 1
         R = @(theta) [uq(theta,1),uq(theta,2)]*inv(uSigma)*[uq(theta,1);uq(theta,2)]; gmm2 = fminsearch(@(e) R(e),0); clear R;
         u_influence = [uzeta(gmm2,1),uzeta(gmm2,2)]; uSigma = 4*cov(u_influence);
         uX = [uQ(gmm2,1),uQ(gmm2,2)]*inv(uSigma)*[uQ(gmm2,1);uQ(gmm2,2)];
         uvar = inv(uX); utstat = sqrt(n)*(gmm2-beta)/sqrt(uvar); ttest2 = abs(utstat)>=norminv(.975); std2 = sqrt(uvar)/sqrt(n);
         uJstat = n*[uq(gmm2,1),uq(gmm2,2)]*inv(uSigma)*[uq(gmm2,1);uq(gmm2,2)]; jtest2 = uJstat>=chi2inv(.95,1);
    case 0
         switch feasible  
             case 0
                  R = @(theta) [iq(theta(1),theta(2)^2,1),iq(theta(1),theta(2)^2,2)]*inv(iSigma)*[iq(theta(1),theta(2)^2,1);iq(theta(1),theta(2)^2,2)]; theta_hat = fmincon(@(e) R(e),[1;1],[],[],[],[],[-5,.1],[5,5],[],options); clear R; gmm2 = theta_hat(1); h = theta_hat(2)^2; %theta_hat = fminsearch(@(e) R(e),[1;1]); clear R; gmm2 = theta_hat(1); h = theta_hat(2);
                  i_influence = [izeta(gmm2,h,1),izeta(gmm2,h,2)]; iSigma = 4*cov(i_influence);
                  iX = [iQ(gmm2,h,1),iQ(gmm2,h,2)]*inv(iSigma)*[iQ(gmm2,h,1);iQ(gmm2,h,2)]; 
                  ivar = inv(iX); itstat = sqrt(n)*(gmm2-beta)/sqrt(ivar); ttest2 = abs(itstat)>=norminv(.975); std2 = sqrt(ivar)/sqrt(n);
                  iJstat = n*[iq(gmm2,h,1),iq(gmm2,h,2)]*inv(iSigma)*[iq(gmm2,h,1);iq(gmm2,h,2)]; jtest2 = iJstat>=chi2inv(.95,1); 
             case 1
                  R = @(theta) [fq(theta(1),theta(2)^2,1),fq(theta(1),theta(2)^2,2)]*inv(fSigma)*[fq(theta(1),theta(2)^2,1);fq(theta(1),theta(2)^2,2)]; theta_hat = fmincon(@(e) R(e),[1;1],[],[],[],[],[-5,.1],[5,5],[],options); clear R; gmm2 = theta_hat(1); h = theta_hat(2)^2; % theta_hat = fminsearch(@(e) R(e),[1;1]); clear R; gmm2 = theta_hat(1); h = theta_hat(2);
                  f_influence = [tzeta(gmm2,h,1),tzeta(gmm2,h,2)]; fSigma = 4*cov(f_influence);
                  fX = [fQ(gmm2,h,1),fQ(gmm2,h,2)]*inv(fSigma)*[fQ(gmm2,h,1);fQ(gmm2,h,2)];
                  fvar = inv(fX); ftstat = sqrt(n)*(gmm2-beta)/sqrt(fvar); ttest2 = abs(ftstat)>=norminv(.975); std2 = sqrt(fvar)/sqrt(n);
                  fJstat = n*[fq(gmm2,h,1),fq(gmm2,h,2)]*inv(fSigma)*[fq(gmm2,h,1);fq(gmm2,h,2)]; jtest2 = fJstat>=chi2inv(.95,1);
 
         end
end
