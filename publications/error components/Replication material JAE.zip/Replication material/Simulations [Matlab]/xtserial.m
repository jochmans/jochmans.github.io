function [dec] = xtserial(e)

de = e(:,2:end)-e(:,1:end-1); 
del = de(:,2:end); der = de(:,1:end-1); 
ols = mean(mean(der.*del))/mean(mean(der.*der)); res = del-ols*der; 
num = res.*der; den = der.*der;
se2 = sum((sum(num,2)).^2)./(sum(sum(den))).^2; se = sqrt(se2); 
s = (ols+.5)/se; dec = abs(s)>norminv(.975);
