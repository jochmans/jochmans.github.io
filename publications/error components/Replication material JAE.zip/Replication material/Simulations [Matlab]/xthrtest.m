function [dec] = xthrtest(e)

[N T] = size(e); 

for t=1:T,
    dev = mean(e(:,t:end),2)*T/(T-t+1); ef(:,t) = e(:,t)-dev;
    dev = mean(e(:,1:  t),2)*T/t      ; eb(:,t) = e(:,t)-dev;
end

z = sum(ef(:,3:end-1).*eb(:,2:end-2),2);

s = sum(z)./sqrt(sum(z.*z)-sum(z).^2/N); % limit distribution is std normal

dec = abs(s)>=norminv(.975);