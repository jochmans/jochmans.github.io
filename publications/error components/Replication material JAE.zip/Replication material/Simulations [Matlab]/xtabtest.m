function [dec] = xtabtest(Y,X) % Yamagata joint AB test 
% Y is a G-by-N array on scalar outcomes 
% X is a G-by-N-by K array on K regressors

%% Setup
[G N K] = size(X); % dimensions 
df = N-3;

%% Within-group estimation of regression slopes
dY = zeros(G,N)  ;            dY        = Y       -(sum(Y       ,2)./N)*ones(1,N);      % de-mean outcome
dX = zeros(G,N,K); for k=1:K, dX(:,:,k) = X(:,:,k)-(sum(X(:,:,k),2)./N)*ones(1,N);  end % de-mean regressors

XY = zeros(K,1);
XX = zeros(K,K);
for k1=1:K, 
                XY(k1, 1) = mean(sum((dX(:,:,k1).*dY        ),2));
    for k2=1:K, XX(k1,k2) = mean(sum((dX(:,:,k1).*dX(:,:,k2)),2)); end
end

b = inv(XX)*XY; 
E = dY        ; for k=1:K, E      = E - dX(:,:,k)*b(k)      ; end; ed = E;  
A = zeros(G,K); for k=1:K, A(:,k) = sum((dX(:,:,k).*E),2); end; omega = (inv(XX)*A')'; asyvar = (omega'*omega)/G^2; se = sqrt(diag(asyvar));

%% Construct moments for test statistic
E = Y; for k=1:K, E = E - X(:,:,k)*b(k); end;  % construct residuals in levels
DE = E(:,2:end) - E(:,1:end-1);  % and in differences


DUDU = zeros(G,df);
DUDX = zeros(K,df);
for q=2:N-2,
    DUDU(:,q-1) = sum(DE(:,1:end-q).*DE(:,1+q:end),2);
    for k=1:K,
        DX = X(:,2:end,k)-X(:,1:end-1,k);
        DUDX(k,q-1) = mean(sum(DE(:,1:end-q).*DX(:,1+q:end),2))+mean(sum(DX(:,1:end-q).*DE(:,1+q:end),2));
    end
end


vg = DUDU' - DUDX'*omega';

%% Construct test statistic
v = mean(vg,2); V = (vg*vg')/G;  statistic = G*v'*inv(V)*v;

%% Perform test
criticalvalue = [chi2inv(.90,df), chi2inv(.95,df), chi2inv(.99,df)];  % critical values at 10% 5% and 1%
decision = statistic>=criticalvalue;
pvalue = 1-chi2cdf(statistic,df);

dec = decision(2);



