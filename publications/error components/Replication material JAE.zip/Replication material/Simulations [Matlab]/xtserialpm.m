function [dec ed el] = xtserialpm(Y,X,center)
% Y is a G-by-N array on scalar outcomes 
% X is a G-by-N-by K array on K regressors
% Y and X may have gaps (coded as `missing' in Matlab)

%% Setup
[G N K] = size(X); % dimensions 
df =  N*(N-1)/2-1; % df for test statistic
Dy = double(ismissing(Y)==0); Dx = double(ismissing(sum(X,3))==0); D = Dy.*Dx  ; % non-missingness indicators
Ng= sum(D,2); 

Ig = (Ng>1); % # of obs per group
%Ig = (Ng>0); % # of obs per group


Y(Ig==0,:) = []; X(Ig==0,:,:)=[]; D(Ig==0,:)=[]; Ng(Ig==0)=[]; [G N K] = size(X); % drop non-informative groups and reset dimensions 
Y(D==0) = -999; for k=1:K, temp = X(:,:,k);  temp(D==0)=-999; X(:,:,k)=temp; end % re-code missing observations

%% Within-group estimation of regression slopes
dY = zeros(G,N)  ;            dY        = D.*Y       -(sum(D.*Y       ,2)./Ng)*ones(1,N);      % de-mean outcome
dX = zeros(G,N,K); for k=1:K, dX(:,:,k) = D.*X(:,:,k)-(sum(D.*X(:,:,k),2)./Ng)*ones(1,N);  end % de-mean regressors

dY(D==0) = -999; for k=1:K, temp = dX(:,:,k);  temp(D==0)=-999; dX(:,:,k)=temp; end % re-code missing observations

XY = zeros(K,1);
XX = zeros(K,K);
for k1=1:K, 
                XY(k1, 1) = mean(sum(D.*(dX(:,:,k1).*dY        ),2));
    for k2=1:K, XX(k1,k2) = mean(sum(D.*(dX(:,:,k1).*dX(:,:,k2)),2)); end
end

b = inv(XX)*XY; 
E = dY        ; for k=1:K, E      = E - dX(:,:,k)*b(k)      ; end; ed = E; e(D==0) = 0; 
A = zeros(G,K); for k=1:K, A(:,k) = sum(D.*(dX(:,:,k).*E),2); end; omega = (inv(XX)*A')'; asyvar = (omega'*omega)/G^2; se = sqrt(diag(asyvar));

%% Construct moments for test statistic
E = Y; for k=1:K, E = E - X(:,:,k)*b(k); end; el = E; el(D==0) = 0; % construct residuals in levels
DE = E(:,2:end) - E(:,1:end-1); DD = min(D(:,1:end-1),D(:,2:end));

s =[]; for t=1:N-2 s   =[s 1:t]            ; end
ss=[]; for t=2:N-1 ss  =[ss; t*ones(t-1,1)]; end

ZDE = [(D(:,s).*E(:,s)).*(DD(:,ss).*DE(:,ss)), (D(:,3:N).*E(:,3:N)).*(DD(:,1:end-1).*DE(:,1:end-1))]';
ZDX = zeros(df,K); for k=1:K, DX = X(:,2:end,k)-X(:,1:end-1,k); ZDX(:,k) = mean([(D(:,s).*E(:,s)).*(DD(:,ss).*DX(:,ss)) , (D(:,3:N).*E(:,3:N)).*(DD(:,1:end-1).*DX(:,1:end-1))])'; end
vg = ZDE - ZDX*omega';

%% Construct test statistic
v = mean(vg,2); V1 = (vg*vg')/G; V2 = ((vg-v)*(vg-v)')/G; if center==0, V = V1; else V = V2; end; statistic = G*v'*inv(V)*v;

%% Perform test
criticalvalue = [chi2inv(.90,df), chi2inv(.95,df), chi2inv(.99,df)];  % critical values at 10% 5% and 1%
decision = statistic>=criticalvalue;
pvalue = 1-chi2cdf(statistic,df);

dec = decision(2);

