function [dec] = xtistest(e) % Input is N-by-T matrix of within-group residuals

[N T] = size(e); 
df = (T-1)*(T-2)/2;
sigma2 = mean(mean(e.*e))*(T)/(T-1); M = eye(T)-ones(T,T)/T;


Deltavec    = zeros(df,1);
DeltaVDelta = zeros(df,df);

for g=1:N, 
        vec  = (e(g,:)'*e(g,:))-sigma2*M                ; 
        vec(:,end)=[]; vec(end,:)=[]; Deltavec = Deltavec+vech(vec)/sqrt(N);
              
        vec  = (e(g,:)'*e(g,:))-(e(g,:)*e(g,:)')/(T-1)*M;
        vec(:,end)=[]; vec(end,:)=[];
        
        DeltaVDelta = DeltaVDelta  + (vech(vec)*vech(vec)')/N;

end

statistic= Deltavec'* inv(DeltaVDelta)*Deltavec;

criticalvalue = [chi2inv(.90,df), chi2inv(.95,df), chi2inv(.99,df)];  % critical values at 10% 5% and 1%
decision = statistic>=criticalvalue;
pvalue = 1-chi2cdf(statistic,df);

dec = decision(2);


function vech = vech(matA)
[M,N] = size(matA);
if (M == N)
    vech  = [];
    for i=1:M-1
        vech = [vech; matA(i+1:end,i)];
    end
else
     error('Input must be a symmetric matrix.')
end

