function [reject] = MonteCarlo(rho,N,T)

theta = rho;

R = 5000;

%N = 250; %T = 3;

decision = zeros(R,5);



parfor r=1:R,
    %X1 = ones(N,1)*[1:1:T]   ; b1 = 1.00;
    %X2 = X1.*X1              ; b2 =- .05;
    
    X1 = randn(N,T)   ; b1 = 1.00;
    X2 = randn(N,T)>0 ; b2 = 1.00;
    
    E = zeros(N,T); 
    
    % Non-stationary AR1;
   %E(:,1) = zeros(N,1); for t=2:T, E(:,t) = rho*E(:,t-1)+randn(N,1)*sqrt(1+log(t)); end
    % Non-stationary MA1
    u0 = zeros(N,1); 
    for t=1:T, u1 = randn(N,1)*sqrt(1+log(t)); E(:,t) = u1+theta*u0; u0 = u1; end


    A = randn(N,T); U = A+E; Y = X1.*b1+X2*b2+U; X=zeros(N,T,2); X(:,:,1) = X1; X(:,:,2) = X2;
    
    [decJ0, ed, el] = xtserialpm(Y,X,0);
%    [decJ1, ~,  ~ ] = xtserialpm(Y,X,1);
    [decAB        ] = xtabtest(Y,X);
    [decIS        ] = xtistest(ed);
    [decBB        ] = xthrtest(el);
    [decWD        ] = xtserial(el);
    
    decision(r,:) = [decJ0 decAB decIS decBB decWD];
    

end

reject = mean(decision),
