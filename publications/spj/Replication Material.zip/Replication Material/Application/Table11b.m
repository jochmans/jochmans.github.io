function Table11b, format compact, format short, global model ar dummies
% MARGINAL EFFECTS, with variance correction term
load('lfp_psid_fs.txt','-ascii'); T = 9; N = size(lfp_psid_fs,1)/T; model='Probit'; scale=0; regressors=6; dynamic=1; dummies=0; trend=0; % 0 1
reg = regressors; ar=(dynamic==1); time=(dummies==1); dim=ar+reg+(T-1)*time; ddim=ar+reg; K = dim;
Y=zeros(T,N); X=zeros(dim*T,N); for i=1:N,  Y(:,i) = lfp_psid_fs(1+(i-1)*T:i*T,3); for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,3+k) ; end; end
Z = {Y X}; clear lfp_psid_fs; clear Y X;
m=0; %bandwidth
[z,mover]=subpanel(Z,1:9); [ME  ,c  ]=AE(z,mover,m); 
[z,mover]=subpanel(Z,1:5); [MEa1,ca1]=AE(z,mover,m);
[z,mover]=subpanel(Z,6:9); [MEa2,ca2]=AE(z,mover,m);
[z,mover]=subpanel(Z,1:4); [MEb1,cb1]=AE(z,mover,m);
[z,mover]=subpanel(Z,5:9); [MEb2,cb2]=AE(z,mover,m);
                                      me =squeeze(mean(ME ,2));
MEa(:,1:5,:)=MEa1; MEa(:,6:9,:)=MEa2; mea=squeeze(mean(MEa,2)); 
MEb(:,1:4,:)=MEb1; MEb(:,5:9,:)=MEb2; meb=squeeze(mean(MEb,2)); spj=2*me-(mea+meb)/2;

avar_me =var(me' )'; se_me =sqrt(avar_me /N); me =mean(me' )'; sc_me=sqrt(avar_me /N+c/(N*T));
avar_spj=var(spj')'; se_spj=sqrt(avar_spj/N); spj=mean(spj')';
ca=(5*ca1+4*ca2)/9;
cb=(4*cb1+5*cb2)/9; c_spj=(ca/2+cb/2)/2; sc_spj =sqrt(avar_spj/N+c_spj/(N*T));

disp('marginal effects')
disp('       mle   se(mle)   sc(mle)       spj   se(spj)   sc(spj)')
disp(       [me    se_me     sc_me         spj   se_spj    sc_spj])

function [ME,c]=AE(Z,mover,m),  global model ar % c=sigma2_c (variance correction term)
[T,N]=size(Z{1}); K=7; [mle,fe]=ML(Z,mover,zeros(7,1),zeros(1,N)); nmover=sum(mover);
[variance,~]=Avar(mle,fe,Z,mover); invSIGMA=N*T*variance; SIGMA=inv(invSIGMA); Y=Z{1}(:,mover); X=Z{2}(:,mover); f=fe(mover);
[ME,Index]=effects(Z,mover,mle,fe); Me=squeeze(mean(ME,2)); me=mean(Me')'; 
v1=ME-repmat(reshape(Me,6,1,N),1,T,1); v1=v1(:,:,mover);
    [~,~,~,ff,S_cell]=CONLoglProbit2(mle,f',Y,X); 
    d=1E-4; kappa1=zeros(6,7); d_theta_alpha=zeros(nmover,7);
    for k=1:K
        coef=mle; coef(k)=coef(k)+d;
        [ef,~]=effects(Z,mover,coef,fe);                  kappa1(:,k)=squeeze(mean(mean(ef,3),2)-me)'/d;
        [~,~,~,fff,~]=CONLoglProbit2(coef,f',Y,X); d_theta_alpha(:,k)=(fff-ff)/d; end
    [ef,~]=effects(Z,mover,mle,fe+d); xi=squeeze(mean((ef-ME)/d,2));
    xi=xi(:,mover); kappa2=xi*d_theta_alpha; kappa=(kappa1+kappa2)*invSIGMA;
    KAPPA=repmat(reshape(kappa,6,7,1,1),1,1,T,nmover);
    for k=1:7, s(k,:,:)=S_cell{k}; end, S=repmat(reshape(s,1,7,T,nmover),6,1,1,1);
v3=squeeze(sum(KAPPA.*S,2));
    I=Index(:,mover); F=normcdf(I); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
    logf=-0.5*(log(2*pi)+I.*I); B=exp(logf-logFA); C=-I.*B;  % B=f/(F(1-F)) C=df/(F(1-F)) 
    E=Y-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB; % EB,EC = score,hessian of fixed effects
    psi=-EB./repmat(mean(H,1),T,1);
    XI=repmat(reshape(xi,6,1,nmover),1,T,1);
    PSI=repmat(reshape(psi,1,T,nmover),6,1,1);
v2=XI.*PSI; c=zeros(6,1);
for j=1:6
    v1j=squeeze(v1(j,:,:)); v2j=squeeze(v2(j,:,:)); v3j=squeeze(v3(j,:,:));
    bb=T*sum(  kernel(v1j,    m))/N/T;
    bc=T*sum(cokernel(v1j,v2j,m))/N/T; cc=sum(sum(v2j.*v2j))/N/T;           
    bd=T*sum(cokernel(v1j,v3j,m))/N/T; cd=sum(sum(v2j.*v3j))/N/T; dd=kappa(j,:)*SIGMA*kappa(j,:)'; 
    V=[bb bc bd; bc cc cd; bd cd dd]; c(j)=sum(V(:)); end

function V=kernel(Z,m)
T=size(Z,1); Z=Z-repmat(mean(Z,1),T,1); V=mean(Z.*Z,1);
for j=1:m, w=1-j/(m+1); Vj=(w/T)*sum(Z(j+1:T,:).*Z(1:T-j,:),1); V=V+2*Vj; end

function C=cokernel(A,B,m) % one-sided
T=size(A,1); A=A-repmat(mean(A,1),T,1); B=B-repmat(mean(B,1),T,1); C=mean(A.*B,1);
for j=1:m, w=1-j/(m+1); Cj=(w/T)*sum(A(j+1:T,:).*B(1:T-j,:),1); C=C+Cj; end

function [me,Index]=effects(Z,mover,coef,fe)
K=length(coef); T=size(Z{1},1); X = cell(1,K); for k=1:K, X{k} = Z{2}(1+(k-1)*T:k*T,:); end
Index = ones(T,1)*fe; for k=1:K, Index = Index + X{k}*coef(k); end % actual index based on data
% 1=lagged participation, 2:4=kids, 5=log(husband income), 6=age
me(1,:,:) = normcdf(Index+coef(1)*(X{1}==0))-normcdf(Index-coef(1)*(X{1}==1));                                   
me(2,:,:) = normcdf(Index + coef(2))-normcdf(Index);
me(3,:,:) = normcdf(Index + coef(3))-normcdf(Index);
me(4,:,:) = normcdf(Index + coef(4))-normcdf(Index);
me(5,:,:) = normpdf(Index)*coef(5);                                   
me(6,:,:) = normcdf(Index+.1*coef(6)+coef(7)*((X{6}+.1).^2-X{6}.^2))-normcdf(Index);  
me(:,:,mover==0)=0; me=100*me;

function [mle,fe,flag,iter]=ML(Z,mover,mle,fe),global model ar
[T,N]=size(Z{1}); Logl=strcat('Logl',model); FUN=str2func(Logl); Z{1}=Z{1}(:,mover); Z{2}=Z{2}(:,mover); 
[mle,fe_mover,logl,flag,iter]=NewtonPartitionedMax(FUN,mle,fe(mover)',Z{:});
fe(mover)=fe_mover'; if flag==1, warning('MLE did not converge'); end

function [z,mover]=subpanel(Z,periods)
T1=length(periods); T=size(Z{1},1); K=size(Z{2},1)/size(Z{1},1);
z{1}=Z{1}(periods,:); for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(periods,:); z{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end;
YL=z{1}; mover=mean(YL)>0 & mean(YL)<1;

function [x1,x2,f,condition,it]=NewtonPartitionedMax(FUN,x1,x2,varargin)
% maximises FUN, starting at (x1,x2) by Newton-Raphson method
% while exploiting sparsity of hessian 
tol=1e-6; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x1);
[f g1 g2 H1 H2 H21]=feval(FUN,x1,x2,varargin{:});
while it<=maxit && condition==1 && improvement==1;
    J21=H21./(H2*ones(1,k)); A=inv(H1-H21'*J21);
    d1=-A*(g1-J21'*g2); d2=-g2./H2-J21*d1;
    step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff gg1 gg2 HH1 HH2 HH21]=feval(FUN,x1+step*d1,x2+step*d2,varargin{:});
        if (ff-f)/abs(f)>=-1e-6
            improvement=1; condition=sqrt(step*step*(d1'*d1+d2'*d2))>tol & (ff-f)>tol;
            x1=x1+step*d1; f=ff; g1=gg1; H1=HH1; H21=HH21;
            x2=x2+step*d2;       g2=gg2; H2=HH2;
        else
            step=step/2;
        end
    end
    it=it+1;
end
it=it-1;

function [logl gtheta gfe Htheta Hfe Hfetheta]=LoglProbit(mle,fe,YY,XX)
% computes likelihood (logl), partitioned score (g) and partitioned hessian (H)
[T N]=size(YY); K = length(mle); II=ones(T,1)*fe'; for k=1:K, II = II+mle(k)*XX(1+(k-1)*T:k*T,:); end
F=normcdf(II); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+II.*II); B=exp(logf-logFA); C=-II.*B;  % B=f/(F(1-F)) C=df/(F(1-F)) 
E=YY-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB; for k=1:K, XH{k}=XX(1+(k-1)*T:k*T,:).*H; end
I=II; Y=YY   ; X=XX;
logl=sum(sum(Y.*logF+(1-Y).*logA)); gfe=sum(EB)'; Hfe=sum(H)';
for k=1:K,
    gtheta(k)=sum(sum(X(1+(k-1)*T:k*T,:).*EB)); Hfetheta(:,k)=sum(XH{k})';
    for kk=1:K, Htheta(k,kk)=sum(sum(X(1+(k-1)*T:k*T,:).*XH{kk}))  ; end;    
end
gtheta=gtheta';

function [avar std] = Avar(mle,fe,Z,indicator)
global model
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe=fe(indicator); Y =Z{1}; X=Z{2}; [T N] = size(Y); % clean data
CONLogl=strcat('CONLogl',model,'2'); FUN=str2func(CONLogl); [logl grad Hess fe GRAD_i]=FUN(mle,fe',Y,X);
K=length(mle);
Hinv=inv(Hess);
avar= -1/(N*T)*Hinv; std = sqrt(diag(avar));

function [logl grad Hess fe GRAD_i]=CONLoglProbit2(mle,fe,Y,X)
% computes normalised concentrated likelihood, gradient, Hessian
[T N]=size(Y); K = length(mle); I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end
F=normcdf(I); A=1-F; logF=log(F); logA=log(A);
logFA=logF+logA; logf=-0.5*(log(2*pi)+I.*I); B=exp(logf-logFA); C=-I.*B; D=(I.*I-1).*B;
E=Y-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB;
H(isnan(H)==1)=0; J(isnan(J)==1)=0;  EB(isnan(EB)==1)=0; EC(isnan(EC)==1)=0;
H(isinf(H)==1)=0; J(isinf(J)==1)=0;  EB(isinf(EB)==1)=0; EC(isinf(EC)==1)=0;
DFETHETA=cell(1,K); DFETHETATHETA=cell(K,K);
for k=1:K, DFETHETA{k} = -ones(T,1)*(sum(X(1+(k-1)*T:k*T,:).*H) ./sum(H)); end
for k=1:K, 
    for kk=1:K, 
        DFETHETATHETA{k,kk} = ones(T,1)*((sum(J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*sum(X(1+(k-1)*T:k*T,:).*H)...
                            - sum(X(1+(k-1)*T:k*T,:).*J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*sum(H))./((sum(H)).^2));
    end
end
logl=mean(mean(Y.*logF+(1-Y).*logA));
for k=1:K, grad(k) = mean(mean(EB.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}))); end
for k=1:K, for kk=1:K, Hess(k,kk) = mean(mean(H.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}).*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})+EB.*DFETHETATHETA{k,kk})); end; end
GRAD_i=cell(1,K);
for k=1:K,
    s_it_k = EB.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k});
    GRAD_i{k} = s_it_k;
end


function [logl grad Hess mle]=FELoglProbit(fe,mle,Y,X)
% likelihood function, gradient and Hessian for fixed effects
[T,N]=size(Y); K = length(mle);
I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end 
F=normcdf(I); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA; logf=-0.5*(log(2*pi)+I.*I); 
B=exp(logf-logFA); C=-I.*B; E=Y-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB;
logl=sum(sum(Y.*logF+(1-Y).*logA)); grad=sum(EB)'; Hess=sum(H)';