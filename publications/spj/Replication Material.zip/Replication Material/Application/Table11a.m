function Table11a, format compact, format short, global model whichSPJ whichSPJL ar dummies
% MODEL ESTIMATION AND STATIONARITY TESTS
T = 9; load('lfp_psid_fs.txt','-ascii'); N = size(lfp_psid_fs,1)/T; model = 'Probit'; regressors = 6; dynamic = 1; dummies=0; whichEST=[1 1 0 0 1 1 1 0 0 1 1]; whichSPJ=whichEST(2:4); whichSPJL=whichEST(7:9);
reg = regressors; ar=(dynamic==1); time=(dummies==1); dim=ar+reg+(T-1)*time; ddim=ar+reg;
Y=zeros(T,N); X=zeros(dim*T,N);
for i=1:N,  Y(:,i) = lfp_psid_fs(1+(i-1)*T:i*T,3); 
    if ar==1 && time==0          , for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,3+k) ; end; end % one lag, no time dummies, OK covariates
    if ar==1 && time==1 && reg>0 , for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,3+k) ; end; end % one lag,    time dummies,    covariates
    if ar==1 && time==1 && reg==0,              X(1:T,i)           = lfp_psid_fs(1+(i-1)*T:i*T,4  ) ;
                                   for k=2:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,9+k) ; end; end % one lag,    time dummies, no covariates
    if ar==0 && time==0          , for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,4 +k); end; end % one lag, no time dummies, OK covariates
    if ar==0 && time==1 && reg>0 , for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,4 +k); end; end % one lag,    time dummies,    covariates
    if ar==0 && time==1 && reg==0, for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,10+k); end; end % one lag,    time dummies, no covariates
end
Z = {Y X}; clear lfp_psid_fs;
YL=Z{1}; mover=mean(YL)>0 & mean(YL)<1; 

% POINT ESTIMATION AND STANDARD ERRORS OF INDEX COEFFICIENTS
[ mle,    fe,EX(1) ] = ML   (Z,mover,zeros(dim,1),zeros(1,N),'MLE'); [~,semle] = Avar(mle,  fe,Z,mover); %mle',fe(1:10)
[  hk,  hkfe,EX(5) ] = HK   (Z,mover,mle         ,fe        ,1    ); [~,sehk ] = Avar(hk ,hkfe,Z,mover);
[  fv,  fvfe,EX(6) ] = FV   (Z,mover,mle         ,fe        ,1    ); [~,sefv ] = Avar(fv ,fvfe,Z,mover);
[  ah,  ahfe,EX(10)] = AH   (Z,mover,zeros(dim,1),zeros(1,N),1    ); [~,seah ] = Avar(ah ,ahfe,Z,mover); 
[  ca,  cafe,EX(11)] = CARRO(Z,mover,mle         ,fe              ); [~,seca ] = Avar(ca ,cafe,Z,mover);
[ spj,     ~,EX(2:4), SMLE, SFE,h1,h2,h3,h4] = SPJNEWW (Z,mover,zeros(dim,2),zeros(2,N),mle,fe);           %spj, SMLE
[spjl,     ~,EX(7:9),SLMLE,SLFE            ] = SPJLNEWW(Z,mover,zeros(dim,3),zeros(19,N)      );           %spjl
varspj=-(5/9*inv(h1/5/N)+4/9*inv(h2/4/N)+4/9*inv(h3/4/N)+5/9*inv(h4/5/N))/2/N/T; sespj=sqrt(diag(varspj)); sespjl=sespj;
disp('point estimates'); disp('       mle       spj        hk        fv      spjl        ah        ca'); disp([  mle   spj   hk   fv   spjl   ah   ca])
disp('standard errors'); disp('       mle       spj        hk        fv      spjl        ah        ca'); disp([semle sespj sehk sefv sespjl seah seca])

% STATIONARITY TESTS
[~,hess_sum] = GradHess(mle,fe,Z,mover); avar = -inv(hess_sum/N/T); Sigma = -hess_sum/N/T; 
disp(' '), disp('5-4 split')
    % spj
        DIFF = (5/4)*(SMLE(:,1)-mle)-(4/5)*(SMLE(:,2)-mle);  z = (N*T)*DIFF'*Sigma*DIFF/(2+4/5+5/4); p = 1-chi2cdf(z,dim); 
        disp('validity test statistic and p-value for spj, joint' ); disp([z p]);
        disp('validity test statistic and p-value for spj, by coefficient' )
        for i=1:dim, z = (N*T)*DIFF(i)*Sigma(i,i)*DIFF(i)/(2+4/5+5/4); p = 1-chi2cdf(z,1); disp([z p]); end
    % spjl, profile scores in subpanels at full-panel mle
        TT=1:5; T1=length(TT); subZ{1}=Z{1}(TT,:); for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
            YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [s1,~] = GradHess(mle,fe,subZ,submover); s1=s1/N/T1; clear subZ, % s1
        TT=6:9; T1=length(TT); subZ{1}=Z{1}(TT,:); for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
            YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [s2,~] = GradHess(mle,fe,subZ,submover); s2=s2/N/T1; clear subZ, % s2
        DIFF = (5/4)*s1'-(4/5)*s2'; z = (N*T)*DIFF'*avar*DIFF/(4/5+5/4+2); p = 1-chi2cdf(z,dim); %ds=DIFF'
        disp('validity test statistic and p-value for spjl, joint'); disp([z p]); 
        disp('validity test statistic and p-value for spjl, by coefficient' )
        for i=1:dim, z = (N*T)*DIFF(i)*avar(i,i)*DIFF(i)/(2+4/5+5/4); p = 1-chi2cdf(z,1); disp([z p]); end
disp(' '), disp('4-5 split')
    % spj
        DIFF = (4/5)*(SMLE(:,3)-mle)-(5/4)*(SMLE(:,4)-mle);  z = (N*T)*DIFF'*Sigma*DIFF/(2+4/5+5/4); p = 1-chi2cdf(z,dim); 
        disp('validity test statistic and p-value for spj, joint' ); disp([z p]);
        disp('validity test statistic and p-value for spj, by coefficient' )
        for i=1:dim, z = (N*T)*DIFF(i)*Sigma(i,i)*DIFF(i)/(2+4/5+5/4); p = 1-chi2cdf(z,1); disp([z p]); end
    % spjl, profile scores in subpanels at full-panel mle
        TT=1:4; T1=length(TT); subZ{1}=Z{1}(TT,:); for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
            YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [s1,~] = GradHess(mle,fe,subZ,submover); s1=s1/N/T1; clear subZ, % s1
        TT=5:9; T1=length(TT); subZ{1}=Z{1}(TT,:); for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
            YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [s2,~] = GradHess(mle,fe,subZ,submover); s2=s2/N/T1; clear subZ, % s2
        DIFF = (4/5)*s1'-(5/4)*s2'; z = (N*T)*DIFF'*avar*DIFF/(4/5+5/4+2); p = 1-chi2cdf(z,dim); %ds=DIFF'
        disp('validity test statistic and p-value for spjl, joint'); disp([z p]); 
        disp('validity test statistic and p-value for spjl, by coefficient' )
        for i=1:dim, z = (N*T)*DIFF(i)*avar(i,i)*DIFF(i)/(2+4/5+5/4); p = 1-chi2cdf(z,1); disp([z p]); end

function [grad_sum,hess_sum] = GradHess(mle,fe,Z,indicator), global model
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe=fe(indicator); Y =Z{1}; X=Z{2}; [T,N] = size(Y); % clean data
CONLogl=strcat('CONLogl',model,'2'); FUN=str2func(CONLogl); [~,grad,hess,~,~]=FUN(mle,fe',Y,X); hess_sum=N*T*hess; grad_sum=N*T*grad;

function [mle fe flag iter]=ML(Z,indicator1,mle,fe,parent)
% compute mle for 'model' with data Z
global model ar
[TTT NNN]=size(Z{1}); ZZZ=Z; Logl=strcat('Logl',model); FUN=str2func(Logl); % call Logl for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator1); end; fe_ind1=fe(indicator1); % clean data, step 1
[T,N]=size(Z{1}); [kT,N]=size(Z{2}); k=kT/T;  
switch lower(parent)
    case {'mle'}; 
         [T N]=size(Z{1}); flag=0;
         [mle fe_ind1 logl flag iter]=NewtonPartitionedMax(FUN,mle,fe_ind1',Z{:}); % estimate
         fe(indicator1)=fe_ind1'; % fill in estimated fixed effects
         if flag==1 warning('MLE did not converge');pause;                          end
    case {'spj1','spj2','spj3'}; 
         [T N]=size(Z{1}); ZZ=Z;
         if ar==1 && k==1, YL=Z{1}; YR=Z{2}(1:T,:); indicator2=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
         if ar==1 && k>1,  YL=Z{1};                 indicator2=mean(YL)>0 & mean(YL)<1                          ;  end 
         if ar==0,         YL=Z{1};                 indicator2=mean(YL)>0 & mean(YL)<1                          ;  end
         for k=1:K Z{k}=Z{k}(:,indicator2); end; 
         fe_ind2=fe_ind1(indicator2);
         [mle fe_ind2 logl flag iter]=NewtonPartitionedMax(FUN,mle,fe_ind2',Z{:});
         fe_ind1(indicator2)=fe_ind2'; 
         fe(indicator1) = fe_ind1;
         if flag==1 warning('Subpanel MLE for %s\t did not converge',parent); end
         %dbstop if warning;
end 

function [x1,x2,f,condition,it]=NewtonPartitionedMax(FUN,x1,x2,varargin)
% maximises FUN, starting at (x1,x2) by Newton-Raphson method
% while exploiting sparsity of hessian 
tol=1e-6; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x1);
[f g1 g2 H1 H2 H21]=feval(FUN,x1,x2,varargin{:});
while it<=maxit && condition==1 && improvement==1;
    J21=H21./(H2*ones(1,k)); A=inv(H1-H21'*J21);
    d1=-A*(g1-J21'*g2); d2=-g2./H2-J21*d1;
    step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff gg1 gg2 HH1 HH2 HH21]=feval(FUN,x1+step*d1,x2+step*d2,varargin{:});
        if (ff-f)/abs(f)>=-1e-6
            improvement=1; condition=sqrt(step*step*(d1'*d1+d2'*d2))>tol & (ff-f)>tol;
            x1=x1+step*d1; f=ff; g1=gg1; H1=HH1; H21=HH21;
            x2=x2+step*d2;       g2=gg2; H2=HH2;
        else
            step=step/2;
        end
    end
    it=it+1;
end
it=it-1;

function [logl gtheta gfe Htheta Hfe Hfetheta]=LoglProbit(mle,fe,YY,XX)
% computes likelihood (logl), partitioned score (g) and partitioned hessian (H)
[T N]=size(YY); K = length(mle); II=ones(T,1)*fe'; for k=1:K, II = II+mle(k)*XX(1+(k-1)*T:k*T,:); end
F=normcdf(II); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+II.*II); B=exp(logf-logFA); C=-II.*B;  % B=f/(F(1-F)) C=df/(F(1-F)) 
E=YY-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB; for k=1:K, XH{k}=XX(1+(k-1)*T:k*T,:).*H; end
I=II; Y=YY   ; X=XX;
logl=sum(sum(Y.*logF+(1-Y).*logA)); gfe=sum(EB)'; Hfe=sum(H)';
for k=1:K,
    gtheta(k)=sum(sum(X(1+(k-1)*T:k*T,:).*EB)); Hfetheta(:,k)=sum(XH{k})';
    for kk=1:K, Htheta(k,kk)=sum(sum(X(1+(k-1)*T:k*T,:).*XH{kk}))  ; end;    
end
gtheta=gtheta';


function [avar std] = Avar(mle,fe,Z,indicator)
global model
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe=fe(indicator); Y =Z{1}; X=Z{2}; [T N] = size(Y); % clean data
CONLogl=strcat('CONLogl',model,'2'); FUN=str2func(CONLogl); [logl grad Hess fe GRAD_i]=FUN(mle,fe',Y,X);
K=length(mle);
Hinv=inv(Hess);
avar= -1/(N*T)*Hinv; std = sqrt(diag(avar)); 


function [logl grad Hess fe GRAD_i]=CONLoglProbit2(mle,fe,Y,X)
% computes normalised concentrated likelihood, gradient, Hessian
[T N]=size(Y); K = length(mle); I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end
F=normcdf(I); A=1-F; logF=log(F); logA=log(A);
logFA=logF+logA; logf=-0.5*(log(2*pi)+I.*I); B=exp(logf-logFA); C=-I.*B; D=(I.*I-1).*B;
E=Y-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB;
H(isnan(H)==1)=0; J(isnan(J)==1)=0;  EB(isnan(EB)==1)=0; EC(isnan(EC)==1)=0;
H(isinf(H)==1)=0; J(isinf(J)==1)=0;  EB(isinf(EB)==1)=0; EC(isinf(EC)==1)=0;
DFETHETA=cell(1,K); DFETHETATHETA=cell(K,K);
for k=1:K, DFETHETA{k} = -ones(T,1)*(sum(X(1+(k-1)*T:k*T,:).*H) ./sum(H)); end
for k=1:K, 
    for kk=1:K, 
        DFETHETATHETA{k,kk} = ones(T,1)*((sum(J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*sum(X(1+(k-1)*T:k*T,:).*H)...
                            - sum(X(1+(k-1)*T:k*T,:).*J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*sum(H))./((sum(H)).^2));
    end
end
logl=mean(mean(Y.*logF+(1-Y).*logA));
for k=1:K, grad(k) = mean(mean(EB.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}))); end
for k=1:K, for kk=1:K, Hess(k,kk) = mean(mean(H.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}).*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})+EB.*DFETHETATHETA{k,kk})); end; end
GRAD_i=cell(1,K);
for k=1:K,
    s_it_k = EB.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k});
    GRAD_i{k} = s_it_k;
end

function [spj,spjfe,flag,SMLE,SFE,h1,h2,h3,h4]=SPJNEWW(Z,indicator,SMLE,SFE,mle,fe)
% computes spj1,...,spjK (assigned by whichEST) from data Z,
% according to splits and weights determined in SPLITPANEL
global model whichSPJ dummies
[spj1,spj1fe,flag1,SMLE(:,1:4),SFE(1:4,:),h1,h2,h3,h4]=SPJ1(Z,indicator,mle,fe,SMLE(:,1:2),SFE(1:2,:)); 
if flag1~=0, spj1=mle; spj1fe=fe; end; flag=[flag1]; spj=[spj1]; spjfe=[spj1fe]; % if nonexistence: SPJ1=MLE 

function [spj,spjfe,flag,SMLE,SFE,h1,h2,h3,h4]=SPJ1(Z,indicator,mle,fe,SMLE,SFE)
% computes spj1 from data Z with splits and weights from SPLITPANEL
global model dummies
[aa,bb]=size(SFE) ; SFE =zeros(aa,bb);
[aa,bb]=size(SMLE); SMLE=zeros(aa,bb);
% 5/4 split
[T,N]=size(Z{1}); [S,W]=SPLITPANEL(3,T,1);   SPlength=S(:,2)-S(:,1)+1; K=length(mle)-dummies*(T-1);
Z1{1}=Z{1}(S(1,1):S(1,2),:); T1=SPlength(1); for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(S(1,1):S(1,2),:); Z1{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
    if dummies==1, for t=K+1:K+1+T1-2, D=zeros(T1,N); D(t-K+1,:)=ones(1,N); Z1{2}(1+(t-1)*T1:t*T1,:)=D; end; end
    if dummies==0, [mle1,fe1,flag1]=ML(Z1,indicator,SMLE(:,1)         ,SFE(1,:),'SPJ1'); end
    if dummies==1, [mle1,fe1,flag1]=ML(Z1,indicator,SMLE(1:K+(T1-1),1),SFE(1,:),'SPJ1');  mle1=[mle1; zeros(T-T1,1)]; end, clear Z1              
    %if dummies==1, mle1(K+1:end-T+T1) = mle1(K+1:end-T+T1)+mle(K+1); end % realign dummies relative to initial period
Z2{1}=Z{1}(S(2,1):S(2,2),:); T2=SPlength(2); for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ2= ZZ(S(2,1):S(2,2),:); Z2{2}(1+(k-1)*T2:k*T2,:)=ZZ2; end
    if dummies==1, for t=K+1:K+1+T2-2, D=zeros(T2,N); D(t-K+1,:)=ones(1,N); Z2{2}(1+(t-1)*T2:t*T2,:)=D; end; end
    if dummies==0, [mle2,fe2,flag2]=ML(Z2,indicator,SMLE(:,2)         ,SFE(2,:),'SPJ1');  end
    if dummies==1, [mle2,fe2,flag2]=ML(Z2,indicator,SMLE(1:K+(T2-1),2),SFE(2,:),'SPJ1'); mle2=[mle2(1:K); zeros(T-T2,1);mle2(K+1:end)];  end, clear Z2
    %if dummies==1, mle2(end-T+T1+1:end) = mle2(end-T+T1+1:end)+mle(K+1); end
mle_bar=[mle1 mle2]*SPlength/sum(SPlength); spj54  =(1+W)*mle-W*mle_bar;
fe_bar =[fe1' fe2']*SPlength/sum(SPlength); spjfe54=(1+W)*fe -W*fe_bar';
SMLE=[mle1 mle2]; SFE=[fe1;fe2]; flag54=[flag1 flag2]; if sum(flag54)==0, flag1=0; end, if sum(flag54)~=0, flag1=1; end % flag solution
% 4/5 split
[T,N]=size(Z{1}); [S,W]=SPLITPANEL(3,T,1); S(1,2)=S(1,2)-1; S(2,1)=S(2,1)-1;  SPlength=S(:,2)-S(:,1)+1;
Z1{1}=Z{1}(S(1,1):S(1,2),:); T1=SPlength(1); for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(S(1,1):S(1,2),:); Z1{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
    if dummies==1, for t=K+1:K+1+T1-2, D=zeros(T1,N); D(t-K+1,:)=ones(1,N); Z1{2}(1+(t-1)*T1:t*T1,:)=D; end; end
    if dummies==0, [mle1,fe1,flag1]=ML(Z1,indicator,SMLE(:,1)         ,SFE(1,:),'SPJ1'); end
    if dummies==1, [mle1,fe1,flag1]=ML(Z1,indicator,SMLE(1:K+(T1-1),1),SFE(1,:),'SPJ1'); mle1=[mle1; zeros(T-T1,1)]; end, clear Z1  
Z2{1}=Z{1}(S(2,1):S(2,2),:); T2=SPlength(2);
for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ2= ZZ(S(2,1):S(2,2),:); Z2{2}(1+(k-1)*T2:k*T2,:)=ZZ2; end
    if dummies==1, for t=K+1:K+1+T2-2, D=zeros(T2,N); D(t-K+1,:)=ones(1,N); Z2{2}(1+(t-1)*T2:t*T2,:)=D; end; end
    if dummies==0, [mle2,fe2,flag2]=ML(Z2,indicator,SMLE(:,1)         ,SFE(1,:),'SPJ1');  end
    if dummies==1, [mle2,fe2,flag2]=ML(Z2,indicator,SMLE(1:K+(T2-1),1),SFE(2,:),'SPJ1'); mle2=[mle2(1:K); zeros(T-T2,1);mle2(K+1:end)];  end, clear Z2  
mle_bar=[mle1 mle2]*SPlength/sum(SPlength); spj45  =(1+W)*mle-W*mle_bar;
fe_bar =[fe1' fe2']*SPlength/sum(SPlength); spjfe45=(1+W)*fe -W*fe_bar';
SMLE=[SMLE mle1 mle2]; SFE=[SFE; fe1;fe2]; flag45=[flag1 flag2]; if sum(flag45)==0 flag2=0; end, if sum(flag45)~=0 flag2=1; end % flag solution
% average out over splits
spj = (spj54+spj45)/2; spjfe = (spjfe54+spjfe45)/2; if flag1+flag2==0, flag=0; end, if flag1+flag2~=0, flag=1; end
% hessians in subpanels
if dummies==0, dim=7;
    TT=1:5; T1=length(TT); subZ{1}=Z{1}(TT,:); for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
        YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [est,fe,~] = ML(subZ,submover,zeros(dim, 1),zeros( 1,N), 'MLE'); h1 = Hess(est,fe,subZ,submover); clear subZ   
    TT=6:9; T1=length(TT); subZ{1}=Z{1}(TT,:); for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
        YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [est,fe,~] = ML(subZ,submover,zeros(dim, 1),zeros( 1,N), 'MLE'); h2 = Hess(est,fe,subZ,submover); clear subZ
    TT=1:4; T1=length(TT); subZ{1}=Z{1}(TT,:); for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
        YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [est,fe,~] = ML(subZ,submover,zeros(dim, 1),zeros( 1,N), 'MLE'); h3 = Hess(est,fe,subZ,submover); clear subZ
    TT=5:9; T1=length(TT); subZ{1}=Z{1}(TT,:); for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
        YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [est,fe,~] = ML(subZ,submover,zeros(dim, 1),zeros( 1,N), 'MLE'); h4 = Hess(est,fe,subZ,submover); clear subZ, end
if dummies==1, K=7;
    TT=1:5; T1=length(TT); K=7; subZ{1}=Z{1}(TT,:); for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
        for t=K+1:K+1+T1-2, D=zeros(T1,N); D(t-K+1,:)=ones(1,N); subZ{2}(1+(t-1)*T1:t*T1,:)=D; end
        YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [est,fe,~] = ML(subZ,submover,zeros(K+T1-1,1),zeros(1,N),'MLE'); h1 = Hess(est,fe,subZ,submover); clear subZ   
    TT=6:9; T1=length(TT); K=7; subZ{1}=Z{1}(TT,:); for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
        for t=K+1:K+1+T1-2, D=zeros(T1,N); D(t-K+1,:)=ones(1,N); subZ{2}(1+(t-1)*T1:t*T1,:)=D; end;
        YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [est,fe,~] = ML(subZ,submover,zeros(K+T1-1,1),zeros(1,N),'MLE'); h2 = Hess(est,fe,subZ,submover); clear subZ   
    TT=1:4; T1=length(TT); K=7; subZ{1}=Z{1}(TT,:); for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
        for t=K+1:K+1+T1-2, D=zeros(T1,N); D(t-K+1,:)=ones(1,N); subZ{2}(1+(t-1)*T1:t*T1,:)=D; end
        YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [est,fe,~] = ML(subZ,submover,zeros(K+T1-1,1),zeros(1,N),'MLE'); h3 = Hess(est,fe,subZ,submover); clear subZ  
    TT=5:9; T1=length(TT); K=7; subZ{1}=Z{1}(TT,:); for k=1:K, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(TT,:); subZ{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
        for t=K+1:K+1+T1-2, D=zeros(T1,N); D(t-K+1,:)=ones(1,N); subZ{2}(1+(t-1)*T1:t*T1,:)=D; end;
        YL=subZ{1}; submover=mean(YL)>0 & mean(YL)<1; [est,fe,~] = ML(subZ,submover,zeros(K+T1-1,1),zeros(1,N),'MLE'); h4 = Hess(est,fe,subZ,submover); clear subZ, end

function hess_sum = Hess(mle,fe,Z,indicator), global model
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe=fe(indicator); Y =Z{1}; X=Z{2}; [T,N] = size(Y); % clean data
CONLogl=strcat('CONLogl',model,'2'); FUN=str2func(CONLogl); [~,~,hess,~,~]=FUN(mle,fe',Y,X); hess_sum=N*T*hess;

function [splits weights]=SPLITPANEL(Tmin,T,bc_order) % bc_order = 1 2 3 4 ...
% determines panel splits and associated coefficient for linear
% combinations of mle's given Tmin, T and order of bias-correction (bc_order)
if bc_order==1 [splits weights]=SplitsAndWeights1(T,Tmin); end 
if bc_order==2 [splits weights]=SplitsAndWeights2(T,Tmin); end
if bc_order==3 [splits weights]=SplitsAndWeights3(T,Tmin); end

function [S W]=SplitsAndWeights1(T,Tmin)
% splits and weights for first-order bias correction
S=zeros(2,2); W=0;
if T>=Tmin+1
    T1=max(Tmin,ceil(T/2));
    T2=max(Tmin,floor(T/2));
    S =[1 T1;(T-T2+1) T];
    W =(T1+T2)/(2*T-T1-T2);
end

function [S W]=SplitsAndWeights2(T,Tmin)
% splits and weights for second-order bias correction
S=zeros(5,2); W=zeros(2,1);
if T>=Tmin+2
    T1=max(Tmin+1,ceil(T/2));
    T2=max(Tmin+1,floor(T/2));
    S(1:2,:)=[1 T1;(T-T2+1) T]; A=1-2*T/(T1+T2); C=1-(T*T)/(T1+T2)*(1/T1+1/T2);
    T1=max(Tmin,ceil(T/3));
    T2=max(Tmin,floor((T+1)/3)); f=ceil(1+(T-T2)/2);
    T3=max(Tmin,floor(T/3));      
    S(3:5,:)=[1 T1;f (f+T2-1);(T-T3+1) T]; B=1-3*T/(T1+T2+T3); D=1-(T*T)/(T1+T2+T3)*(1/T1+1/T2+1/T3);
    M=[A,B;C,D]; W=inv(M)*[-1;-1];
end

function [S W]=SplitsAndWeights3(T,Tmin)
% splits and weights for second-order bias correction
S=zeros(9,2); W=zeros(3,1);
if T>=Tmin+3
    T1=max(Tmin+2,ceil(T/2));
    T2=max(Tmin+2,floor(T/2));
    S(1:2,:)=[1 T1;(T-T2+1) T];   
    A=1-2*T/(T1+T2); D=1-(1/T1+1/T2)*(T*T)/(T1+T2); G=1-(1/(T1*T1)+1/(T2*T2))*(T*T*T)/(T1+T2);
    T1=max(Tmin+1,ceil(T/3));
    T2=max(Tmin+1,floor((T+1)/3)); f=ceil(1+(T-T2)/2);
    T3=max(Tmin+1,floor(T/3));
    S(3:5,:)=[1 T1;f (f+T2-1);(T-T3+1) T];
    B=1-3*T/(T1+T2+T3); E=1-(1/T1+1/T2+1/T3)*(T*T)/(T1+T2+T3); H=1-(1/(T1*T1)+1/(T2*T2)+1/(T3*T3))*(T*T*T)/(T1+T2+T3);
    T1=max(Tmin,ceil(T/4));
    T2=max(Tmin,floor((T+1)/4)); f2=T1+1; 
    T3=max(Tmin,ceil((T-1)/4));  f3=T1+T2+1; 
    T4=max(Tmin,floor(T/4));     f4=T1+T2+T3+1;
    r=floor((T1+T2+T3+T3-T)/3); f2=f2-r; f3=f3-r; f4=f4-r; % constructing overlap
    r=floor((f4+T4-1-T)/2); f3=f3-r;
    S(6:9,:)=[1 T1;f2 (f2+T2-1);f3 (f3+T3-1);(T-T4+1) T];
    C=1-4*T/(T1+T2+T3+T4); F=1-(1/T1+1/T2+1/T3+1/T4)*(T*T)/(T1+T2+T3+T4); I=1-(1/(T1*T1)+1/(T2*T2)+1/(T3*T3)+1/(T4*T4))*(T*T*T)/(T1+T2+T3+T4);
    M=[A,B,C;D,E,F;G,H,I]; W=inv(M)*[-1;-1;-1];
end

function [spjl FE flag SMLE SFE]=SPJLNEWW(Z,indicator,SMLE,SFE) % spjlfe
% computes spjl1,...,spjlK (assigned by whichEST) from data Z,
% according to splits and weights determined in SPLITPANEL
global model whichSPJL ar % whichEST                         
%whichSPJL=whichEST(6:8);

[T N]=size(Z{1}); FE=zeros(N,3);
if whichSPJL(1)==1 [spjl1 fe_spjl1 flag1 SFE(1:5,:)  ]=SPJL1(Z,indicator,SMLE(:,1),SFE(1:5,:)  ); FE(:,1)=fe_spjl1; end % spjlfe1 % FE(:,1)=fe_spjl1;
if whichSPJL(2)==1 [spjl2 fe_spjl2 flag2 SFE(4:9,:)  ]=SPJL2(Z,indicator,SMLE(:,2),SFE(4:9,:)  ); FE(:,2)=fe_spjl2; end % spjlfe2
if whichSPJL(3)==1 [spjl3          flag3 SFE(10:19,:)]=SPJL3(Z,indicator,SMLE(:,3),SFE(10:19,:));                   end % spjlfe3

if whichSPJL(1)==0 spjl1=zeros(size(SMLE,1),1); flag1=0; end %  spj1fe=zeros(1,N);
if whichSPJL(2)==0 spjl2=zeros(size(SMLE,1),1); flag2=0; end %  spj2fe=zeros(1,N);
if whichSPJL(3)==0 spjl3=zeros(size(SMLE,1),1); flag3=0; end %  spj3fe=zeros(1,N);

if flag1==1 && whichSPJL(1)==1  spjl1=SMLE(:,1); end % spj1fe=fe;
if flag2==1 && whichSPJL(2)==1  spjl2=SMLE(:,1); end % spj1fe=fe;
if flag3==1 && whichSPJL(3)==1  spjl3=SMLE(:,1); end % spj1fe=fe;

if flag2~=0 && whichSPJL(2)==1 && whichSPJL(1)==1 && flag1==0  spjl2=spjl1; end % if nonexistence: SPJ2=SPJ1
if flag3~=0 && whichSPJL(3)==1 && whichSPJL(1)==1 && flag1==0  spjl3=spjl1; end % if nonexistence: SPJ3=SPJ1
if flag3~=0 && whichSPJL(3)==1 && whichSPJL(2)==1 && flag2==0  spjl3=spjl2; end % if nonexistence: SPJ3=SPJ2

%spjl=[spjl1 spjl2 spjl3];  flag=[flag1 flag2 flag3]; %spjlfe=[spjlfe1];
spjl=spjl1; flag=flag1;

function [spjl fe_spjl flag SFE]=SPJL1(Z,indicator,spjl,SFE) % spjlfe
% computes spjl1 from data Z with splits and weights from SPLITPANEL
global model ar
[T,N]=size(Z{1}); [kT,N]=size(Z{2}); kk=kT/T;  
% 5/4 split
[T N]=size(Z{1});  [S W]=SPLITPANEL(2,T,1); SPlength=S(:,2)-S(:,1)+1; K=numel(Z);  dim=length(spjl); S1=S; W1=W; % split panel
for k=1:K        Z{k} =Z{k}(:,indicator)    ; end; fe0=SFE(1,indicator); % clean data
T1=SPlength(1); T2=SPlength(2); Z1{1}=Z{1}(S(1,1):S(1,2),:); Z2{1}=Z{1}(S(2,1):S(2,2),:);
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(S(1,1):S(1,2),:); Z1{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
if ar==1 && kk==1, YL=Z1{1}; YR=Z1{2}(1:T1,:); indicator1=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end, %nmover=sum(indicator1)
       % if ar==1, YL=Z1{1}; YR=Z1{2}(1:T1,:); indicator1=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ2= ZZ(S(2,1):S(2,2),:); Z2{2}(1+(k-1)*T2:k*T2,:)=ZZ2; end
if ar==1 && kk==1, YL=Z2{1}; YR=Z2{2}(1:T2,:); indicator2=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z2{1};                   indicator2=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,         YL=Z2{1};                    indicator2=mean(YL)>0 & mean(YL)<1                          ;  end, %nmover=sum(indicator2)
       % if ar==1, YL=Z2{1}; YR=Z2{2}(1:T2,:); indicator2=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z2{1};                   indicator2=mean(YL)>0 & mean(YL)<1                          ;  end
flag=(mean(indicator1)==0 | mean(indicator2)==0);
for k=1:K        Z1{k}=Z1{k}(:,indicator1)  ; end; fe1=SFE(2,indicator); fe1=fe1(indicator1);
for k=1:K        Z2{k}=Z2{k}(:,indicator2)  ; end; fe2=SFE(3,indicator); fe2=fe2(indicator2);
% 4/5 split
[T N]=size(Z{1});  [S W]=SPLITPANEL(2,T,1); S(1,2)=S(1,2)-1; S(2,1)=S(2,1)-1;  SPlength=S(:,2)-S(:,1)+1; K=numel(Z);  dim=length(spjl); S2=S; W2=W; % split panel
%for k=1:K        Z{k} =Z{k}(:,indicator)    ; end; fe0=SFE(1,indicator); % clean data
T3=SPlength(1); T4=SPlength(2); Z3{1}=Z{1}(S(1,1):S(1,2),:); Z4{1}=Z{1}(S(2,1):S(2,2),:);
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ3= ZZ(S(1,1):S(1,2),:); Z3{2}(1+(k-1)*T3:k*T3,:)=ZZ3; end
if ar==1 && kk==1, YL=Z3{1}; YR=Z3{2}(1:T3,:); indicator3=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end, %nmover=sum(indicator3)
       % if ar==1, YL=Z3{1}; YR=Z3{2}(1:T3,:); indicator3=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ4= ZZ(S(2,1):S(2,2),:); Z4{2}(1+(k-1)*T4:k*T4,:)=ZZ4; end
if ar==1 && kk==1, YL=Z4{1}; YR=Z4{2}(1:T4,:); indicator4=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end, %nmover=sum(indicator4)
       % if ar==1, YL=Z4{1}; YR=Z4{2}(1:T4,:); indicator4=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end
flag=(mean(indicator3)==0 | mean(indicator4)==0);
for k=1:K        Z3{k}=Z3{k}(:,indicator3)  ; end; fe3=SFE(4,indicator); fe3=fe3(indicator3);
for k=1:K        Z4{k}=Z4{k}(:,indicator4)  ; end; fe4=SFE(5,indicator); fe4=fe4(indicator4);
FE=[fe0';fe1';fe2';fe3';fe4']'; L=[length(fe0),length(fe1),length(fe2),length(fe3),length(fe4)]; C =cumsum(L); 
[spjl logl flag iter FE]=NewtonRaphsonMax(@SPJL1Logl,spjl,FE',Z,Z1,Z2,Z3,Z4,S1,W1,S2,W2,C,L);
if flag==1 warning('SPJL1 did not converge'); end
SFE(1,indicator)=FE(1:C(1))';
temp=zeros(1,length(fe0)); temp(indicator1)=FE(C(1)+1:C(2))'; SFE(2,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator2)=FE(C(2)+1:C(3))'; SFE(3,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator3)=FE(C(3)+1:C(4))'; SFE(4,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator4)=FE(C(4)+1:C(5))'; SFE(5,indicator)=temp;
FELogl=strcat('FELogl',model); FUN=str2func(FELogl);
[fe_temp felogl flag it sspjl]=NewtonRaphsonMax(FUN,SFE(1,indicator)',spjl,Z{1},Z{2});
fe_spjl=zeros(1461,1); fe_spjl(indicator==1)=fe_temp;

function [logl grad Hess FE]=SPJL1Logl(spjl,FE,Z,Z1,Z2,Z3,Z4,S1,W1,S2,W2,C,L)
global model
Logl=strcat('CONLogl',model); FUN=str2func(Logl); SPlength=S1(:,2)-S1(:,1)+1; 
[logl0 grad0 Hess0 FE(1:C(1))     ]=FUN(spjl,FE((1:C(1)))   ,Z{:} );
[logl1 grad1 Hess1 FE(C(1)+1:C(2))]=FUN(spjl,FE(C(1)+1:C(2)),Z1{:});
[logl2 grad2 Hess2 FE(C(2)+1:C(3))]=FUN(spjl,FE(C(2)+1:C(3)),Z2{:});
logl_bar=(L(2)/L(1)*SPlength(1)*logl1+L(3)/L(1)*SPlength(2)*logl2)/sum(SPlength);
grad_bar=(L(2)/L(1)*SPlength(1)*grad1+L(3)/L(1)*SPlength(2)*grad2)/sum(SPlength);
Hess_bar=(L(2)/L(1)*SPlength(1)*Hess1+L(3)/L(1)*SPlength(2)*Hess2)/sum(SPlength);
loglA=(1+W1)*logl0-W1*logl_bar;
gradA=(1+W1)*grad0-W1*grad_bar;
HessA=(1+W1)*Hess0-W1*Hess_bar;
Logl=strcat('CONLogl',model); FUN=str2func(Logl); SPlength=S2(:,2)-S2(:,1)+1; 
%[logl0 grad0 Hess0 FE(1:C(1))     ]=FUN(spjl,FE((1:C(1)))   ,Z{:} );
[logl3 grad3 Hess3 FE(C(3)+1:C(4))]=FUN(spjl,FE(C(3)+1:C(4)),Z3{:});
[logl4 grad4 Hess4 FE(C(4)+1:C(5))]=FUN(spjl,FE(C(4)+1:C(5)),Z4{:});
logl_bar=(L(4)/L(1)*SPlength(1)*logl3+L(5)/L(1)*SPlength(2)*logl4)/sum(SPlength);
grad_bar=(L(4)/L(1)*SPlength(1)*grad3+L(5)/L(1)*SPlength(2)*grad4)/sum(SPlength);
Hess_bar=(L(4)/L(1)*SPlength(1)*Hess3+L(5)/L(1)*SPlength(2)*Hess4)/sum(SPlength);
loglB=(1+W2)*logl0-W2*logl_bar;
gradB=(1+W2)*grad0-W2*grad_bar;
HessB=(1+W2)*Hess0-W2*Hess_bar;
logl = (loglA+loglB)/2;
grad = (gradA+gradB)/2;
Hess = (HessA+HessB)/2;

function [spjl fe_spjl flag SFE]=SPJL2(Z,indicator,spjl,SFE) % spjlfe
% computes spjl2 from data Z with splits and weights from SPLITPANEL
global model ar
[T N]=size(Z{1}); [S W]=SPLITPANEL(2,T,2); SPlength=S(:,2)-S(:,1)+1;  dim=length(spjl); K=numel(Z); % split panel
for k=1:K        Z{k} =Z{k}(:,indicator)    ; end; fe0=SFE(1,indicator); % clean data
T1=SPlength(1); T2=SPlength(2); T3=SPlength(3); T4=SPlength(4); T5=SPlength(5); 
Z1{1}=Z{1}(S(1,1):S(1,2),:); Z2{1}=Z{1}(S(2,1):S(2,2),:); 
Z3{1}=Z{1}(S(3,1):S(3,2),:); Z4{1}=Z{1}(S(4,1):S(4,2),:); Z5{1}=Z{1}(S(5,1):S(5,2),:);
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(S(1,1):S(1,2),:); Z1{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
if ar==1 && kk==1, YL=Z1{1}; YR=Z1{2}(1:T1,:); indicator1=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator1)
       % if ar==1, YL=Z1{1}; YR=Z1{2}(1:T1,:); indicator1=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ2= ZZ(S(2,1):S(2,2),:); Z2{2}(1+(k-1)*T2:k*T2,:)=ZZ2; end
if ar==1 && kk==1, YL=Z2{1}; YR=Z2{2}(1:T2,:); indicator2=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z2{1};                   indicator2=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z2{1};                   indicator2=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator2)
       % if ar==1, YL=Z2{1}; YR=Z2{2}(1:T2,:); indicator2=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z2{1};                   indicator2=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ3= ZZ(S(3,1):S(3,2),:); Z3{2}(1+(k-1)*T3:k*T3,:)=ZZ3; end
if ar==1 && kk==1, YL=Z3{1}; YR=Z3{2}(1:T3,:); indicator3=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator3)
       % if ar==1, YL=Z3{1}; YR=Z3{2}(1:T3,:); indicator3=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ4= ZZ(S(4,1):S(4,2),:); Z4{2}(1+(k-1)*T4:k*T4,:)=ZZ4; end
if ar==1 && kk==1, YL=Z4{1}; YR=Z3{2}(1:T4,:); indicator4=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator4)
       % if ar==1, YL=Z4{1}; YR=Z4{2}(1:T4,:); indicator4=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ5= ZZ(S(5,1):S(5,2),:); Z5{2}(1+(k-1)*T5:k*T5,:)=ZZ5; end
if ar==1 && kk==1, YL=Z5{1}; YR=Z3{2}(1:T5,:); indicator5=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z5{1};                   indicator5=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z5{1};                   indicator5=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator5)
       % if ar==1, YL=Z5{1}; YR=Z5{2}(1:T5,:); indicator5=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z5{1};                   indicator5=mean(YL)>0 & mean(YL)<1                          ;  end
flag=(mean(indicator1)==0 | mean(indicator2)==0 | mean(indicator3)==0 | mean(indicator4)==0 | mean(indicator5)==0);               
for k=1:K        Z1{k}=Z1{k}(:,indicator1)  ; end; fe1=SFE(2,indicator); fe1=fe1(indicator1);
for k=1:K        Z2{k}=Z2{k}(:,indicator2)  ; end; fe2=SFE(3,indicator); fe2=fe2(indicator2);
for k=1:K        Z3{k}=Z3{k}(:,indicator3)  ; end; fe3=SFE(4,indicator); fe3=fe3(indicator3);
for k=1:K        Z4{k}=Z4{k}(:,indicator4)  ; end; fe4=SFE(5,indicator); fe4=fe4(indicator4);
for k=1:K        Z5{k}=Z5{k}(:,indicator5)  ; end; fe5=SFE(6,indicator); fe5=fe5(indicator5);
FE=[fe0';fe1';fe2';fe3';fe4';fe5']'; 
L=[length(fe0),length(fe1),length(fe2),length(fe3),length(fe4),length(fe5)]; C =cumsum(L); 
[spjl logl flag iter FE]=NewtonRaphsonMax(@SPJL2Logl,spjl,FE',Z,Z1,Z2,Z3,Z4,Z5,S,W,C,L);
if flag==1 warning('SPJL2 did not converge'); end
SFE(1,indicator)=FE(1:C(1))';
temp=zeros(1,length(fe0)); temp(indicator1)=FE(C(1)+1:C(2))'; SFE(2,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator2)=FE(C(2)+1:C(3))'; SFE(3,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator3)=FE(C(3)+1:C(4))'; SFE(4,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator4)=FE(C(4)+1:C(5))'; SFE(5,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator5)=FE(C(5)+1:C(6))'; SFE(6,indicator)=temp;
FELogl=strcat('FELogl',model); FUN=str2func(FELogl);
[fe_temp felogl flag it sspjl]=NewtonRaphsonMax(FUN,SFE(1,indicator)',spjl,Z{1},Z{2});
fe_spjl=zeros(N,1); fe_spjl(indicator==1)=fe_temp;

function [logl grad Hess FE]=SPJL2Logl(spjl,FE,Z,Z1,Z2,Z3,Z4,Z5,S,W,C,L)
global model
Logl=strcat('CONLogl',model); FUN=str2func(Logl); SPlength=S(:,2)-S(:,1)+1; 
[logl0 grad0 Hess0 FE(1:C(1))     ]=FUN(spjl,FE((1:C(1)))   ,Z{:} );
[logl1 grad1 Hess1 FE(C(1)+1:C(2))]=FUN(spjl,FE(C(1)+1:C(2)),Z1{:});
[logl2 grad2 Hess2 FE(C(2)+1:C(3))]=FUN(spjl,FE(C(2)+1:C(3)),Z2{:});
[logl3 grad3 Hess3 FE(C(3)+1:C(4))]=FUN(spjl,FE(C(3)+1:C(4)),Z3{:});
[logl4 grad4 Hess4 FE(C(4)+1:C(5))]=FUN(spjl,FE(C(4)+1:C(5)),Z4{:});
[logl5 grad5 Hess5 FE(C(5)+1:C(6))]=FUN(spjl,FE(C(5)+1:C(6)),Z5{:});
logl_bar1=(L(2)/L(1)*SPlength(1)*logl1+L(3)/L(1)*SPlength(2)*logl2)/sum(SPlength(1:2));
grad_bar1=(L(2)/L(1)*SPlength(1)*grad1+L(3)/L(1)*SPlength(2)*grad2)/sum(SPlength(1:2));
Hess_bar1=(L(2)/L(1)*SPlength(1)*Hess1+L(3)/L(1)*SPlength(2)*Hess2)/sum(SPlength(1:2));
logl_bar2=(L(4)/L(1)*SPlength(3)*logl3+L(5)/L(1)*SPlength(4)*logl4+L(6)/L(1)*SPlength(5)*logl5)/sum(SPlength(3:5));
grad_bar2=(L(4)/L(1)*SPlength(3)*grad3+L(5)/L(1)*SPlength(4)*grad4+L(6)/L(1)*SPlength(5)*grad5)/sum(SPlength(3:5));
Hess_bar2=(L(4)/L(1)*SPlength(3)*Hess3+L(5)/L(1)*SPlength(4)*Hess4+L(6)/L(1)*SPlength(5)*Hess5)/sum(SPlength(3:5));
logl=(1+sum(W))*logl0-W(1)*logl_bar1-W(2)*logl_bar2;
grad=(1+sum(W))*grad0-W(1)*grad_bar1-W(2)*grad_bar2;
Hess=(1+sum(W))*Hess0-W(1)*Hess_bar1-W(2)*Hess_bar2;

function [spjl flag SFE]=SPJL3(Z,indicator,spjl,SFE) % spjlfe
% computes spjl3 from data Z with splits and weights from SPLITPANEL
global model ar
T=size(Z{1},1); [S W]=SPLITPANEL(2,T,3); SPlength=S(:,2)-S(:,1)+1;  dim=length(spjl); K=numel(Z); % split panel
for k=1:K        Z{k} =Z{k}(:,indicator)    ; end; fe0=SFE(1,indicator); % clean data
T1=SPlength(1); T2=SPlength(2); T3=SPlength(3); T4=SPlength(4); T5=SPlength(5); T6=SPlength(6); T7=SPlength(7); T8=SPlength(8); T9=SPlength(9); 
Z1{1}=Z{1}(S(1,1):S(1,2),:); Z2{1}=Z{1}(S(2,1):S(2,2),:); 
Z3{1}=Z{1}(S(3,1):S(3,2),:); Z4{1}=Z{1}(S(4,1):S(4,2),:); Z5{1}=Z{1}(S(5,1):S(5,2),:);
Z6{1}=Z{1}(S(6,1):S(6,2),:); Z7{1}=Z{1}(S(7,1):S(7,2),:); Z8{1}=Z{1}(S(8,1):S(8,2),:); Z9{1}=Z{1}(S(9,1):S(9,2),:);
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ1= ZZ(S(1,1):S(1,2),:); Z1{2}(1+(k-1)*T1:k*T1,:)=ZZ1; end
if ar==1 && kk==1, YL=Z1{1}; YR=Z1{2}(1:T1,:); indicator1=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator1)
       % if ar==1, YL=Z1{1}; YR=Z1{2}(1:T1,:); indicator1=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z1{1};                   indicator1=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ2= ZZ(S(2,1):S(2,2),:); Z2{2}(1+(k-1)*T2:k*T2,:)=ZZ2; end
if ar==1 && kk==1, YL=Z2{1}; YR=Z2{2}(1:T2,:); indicator2=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z2{1};                   indicator2=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z2{1};                   indicator2=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator2)
       % if ar==1, YL=Z2{1}; YR=Z2{2}(1:T2,:); indicator2=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z2{1};                   indicator2=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ3= ZZ(S(3,1):S(3,2),:); Z3{2}(1+(k-1)*T3:k*T3,:)=ZZ3; end
if ar==1 && kk==1, YL=Z3{1}; YR=Z3{2}(1:T3,:); indicator3=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator3)
       % if ar==1, YL=Z3{1}; YR=Z3{2}(1:T3,:); indicator3=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z3{1};                   indicator3=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ4= ZZ(S(4,1):S(4,2),:); Z4{2}(1+(k-1)*T4:k*T4,:)=ZZ4; end
if ar==1 && kk==1, YL=Z4{1}; YR=Z4{2}(1:T4,:); indicator4=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator4)
       % if ar==1, YL=Z4{1}; YR=Z4{2}(1:T4,:); indicator4=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z4{1};                   indicator4=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ5= ZZ(S(5,1):S(5,2),:); Z5{2}(1+(k-1)*T5:k*T5,:)=ZZ5; end
if ar==1 && kk==1, YL=Z5{1}; YR=Z5{2}(1:T5,:); indicator5=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z5{1};                   indicator5=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z5{1};                   indicator5=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator5)
       % if ar==1, YL=Z5{1}; YR=Z5{2}(1:T5,:); indicator5=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z5{1};                   indicator5=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ6= ZZ(S(6,1):S(6,2),:); Z6{2}(1+(k-1)*T6:k*T6,:)=ZZ6; end
if ar==1 && kk==1, YL=Z6{1}; YR=Z6{2}(1:T6,:); indicator6=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z6{1};                   indicator6=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z6{1};                   indicator6=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator6)
       % if ar==1, YL=Z6{1}; YR=Z6{2}(1:T6,:); indicator6=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z6{1};                   indicator6=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ7= ZZ(S(7,1):S(7,2),:); Z7{2}(1+(k-1)*T7:k*T7,:)=ZZ7; end
if ar==1 && kk==1, YL=Z7{1}; YR=Z7{2}(1:T6,:); indicator7=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z7{1};                   indicator7=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z7{1};                   indicator7=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator8)
       % if ar==1, YL=Z7{1}; YR=Z7{2}(1:T7,:); indicator7=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z7{1};                   indicator7=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ8= ZZ(S(8,1):S(8,2),:); Z8{2}(1+(k-1)*T8:k*T8,:)=ZZ8; end
if ar==1 && kk==1, YL=Z8{1}; YR=Z8{2}(1:T8,:); indicator8=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z8{1};                   indicator8=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z8{1};                   indicator8=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator8)
       % if ar==1, YL=Z8{1}; YR=Z8{2}(1:T8,:); indicator8=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z8{1};                   indicator8=mean(YL)>0 & mean(YL)<1                          ;  end
for k=1:dim, ZZ = Z{2}(1+(k-1)*T:k*T,:); ZZ9= ZZ(S(9,1):S(9,2),:); Z9{2}(1+(k-1)*T9:k*T9,:)=ZZ9; end
if ar==1 && kk==1, YL=Z9{1}; YR=Z9{2}(1:T9,:); indicator9=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
if ar==1 && kk>1,  YL=Z9{1};                   indicator9=mean(YL)>0 & mean(YL)<1                          ;  end     %correction
if ar==0,          YL=Z9{1};                   indicator9=mean(YL)>0 & mean(YL)<1                          ;  end, nmover=sum(indicator9)
       % if ar==1, YL=Z9{1}; YR=Z9{2}(1:T9,:); indicator9=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1;  end
       % if ar==0, YL=Z9{1};                   indicator9=mean(YL)>0 & mean(YL)<1                          ;  end
flag=(mean(indicator1)==0 | mean(indicator2)==0 | mean(indicator3)==0 | mean(indicator4)==0 | mean(indicator5)==0 | mean(indicator6)==0 | mean(indicator7)==0 | mean(indicator8)==0 | mean(indicator9)==0);
for k=1:K        Z1{k}=Z1{k}(:,indicator1)  ; end; fe1=SFE(2,indicator) ; fe1=fe1(indicator1);
for k=1:K        Z2{k}=Z2{k}(:,indicator2)  ; end; fe2=SFE(3,indicator) ; fe2=fe2(indicator2);
for k=1:K        Z3{k}=Z3{k}(:,indicator3)  ; end; fe3=SFE(4,indicator) ; fe3=fe3(indicator3);
for k=1:K        Z4{k}=Z4{k}(:,indicator4)  ; end; fe4=SFE(5,indicator) ; fe4=fe4(indicator4);
for k=1:K        Z5{k}=Z5{k}(:,indicator5)  ; end; fe5=SFE(6,indicator) ; fe5=fe5(indicator5);
for k=1:K        Z6{k}=Z6{k}(:,indicator6)  ; end; fe6=SFE(7,indicator) ; fe6=fe6(indicator6);
for k=1:K        Z7{k}=Z7{k}(:,indicator7)  ; end; fe7=SFE(8,indicator) ; fe7=fe7(indicator7);
for k=1:K        Z8{k}=Z8{k}(:,indicator8)  ; end; fe8=SFE(9,indicator) ; fe8=fe8(indicator8);
for k=1:K        Z9{k}=Z9{k}(:,indicator9)  ; end; fe9=SFE(10,indicator); fe9=fe9(indicator9);
FE=[fe0';fe1';fe2';fe3';fe4';fe5';fe6';fe7';fe8';fe9']'; 
L=[length(fe0),length(fe1),length(fe2),length(fe3),length(fe4),length(fe5),length(fe6),length(fe7),length(fe8),length(fe9)];
C =cumsum(L); 
[spjl logl flag iter FE]=NewtonRaphsonMax(@SPJL3Logl,spjl,FE',Z,Z1,Z2,Z3,Z4,Z5,Z6,Z7,Z8,Z9,S,W,C,L);
if flag==1 warning('SPJL3 did not converge'); end
SFE(1,indicator)=FE(1:C(1))';
temp=zeros(1,length(fe0)); temp(indicator1)=FE(C(1)+1:C(2))' ; SFE(2,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator2)=FE(C(2)+1:C(3))' ; SFE(3,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator3)=FE(C(3)+1:C(4))' ; SFE(4,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator4)=FE(C(4)+1:C(5))' ; SFE(5,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator5)=FE(C(5)+1:C(6))' ; SFE(6,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator6)=FE(C(6)+1:C(7))' ; SFE(7,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator7)=FE(C(7)+1:C(8))' ; SFE(8,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator8)=FE(C(8)+1:C(9))' ; SFE(9,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator9)=FE(C(9)+1:C(10))'; SFE(10,indicator)=temp;

function [logl grad Hess FE]=SPJL3Logl(spjl,FE,Z,Z1,Z2,Z3,Z4,Z5,Z6,Z7,Z8,Z9,S,W,C,L)
global model
Logl=strcat('CONLogl',model); FUN=str2func(Logl); SPlength=S(:,2)-S(:,1)+1; 
[logl0 grad0 Hess0 FE(1:C(1))     ] =FUN(spjl,FE((1:C(1)))   ,Z{:} ) ;
[logl1 grad1 Hess1 FE(C(1)+1:C(2))] =FUN(spjl,FE(C(1)+1:C(2)),Z1{:}) ;
[logl2 grad2 Hess2 FE(C(2)+1:C(3))] =FUN(spjl,FE(C(2)+1:C(3)),Z2{:}) ;
[logl3 grad3 Hess3 FE(C(3)+1:C(4))] =FUN(spjl,FE(C(3)+1:C(4)),Z3{:}) ;
[logl4 grad4 Hess4 FE(C(4)+1:C(5))] =FUN(spjl,FE(C(4)+1:C(5)),Z4{:}) ;
[logl5 grad5 Hess5 FE(C(5)+1:C(6))] =FUN(spjl,FE(C(5)+1:C(6)),Z5{:}) ;
[logl6 grad6 Hess6 FE(C(6)+1:C(7))] =FUN(spjl,FE(C(6)+1:C(7)),Z6{:}) ;
[logl7 grad7 Hess7 FE(C(7)+1:C(8))] =FUN(spjl,FE(C(7)+1:C(8)),Z7{:}) ;
[logl8 grad8 Hess8 FE(C(8)+1:C(9))] =FUN(spjl,FE(C(8)+1:C(9)),Z8{:}) ;
[logl9 grad9 Hess9 FE(C(9)+1:C(10))]=FUN(spjl,FE(C(9)+1:C(10)),Z9{:});
logl_bar1=(L(2)/L(1)*SPlength(1)*logl1+L(3)/L(1)*SPlength(2)*logl2)/sum(SPlength(1:2));
grad_bar1=(L(2)/L(1)*SPlength(1)*grad1+L(3)/L(1)*SPlength(2)*grad2)/sum(SPlength(1:2));
Hess_bar1=(L(2)/L(1)*SPlength(1)*Hess1+L(3)/L(1)*SPlength(2)*Hess2)/sum(SPlength(1:2));
logl_bar2=(L(4)/L(1)*SPlength(3)*logl3+L(5)/L(1)*SPlength(4)*logl4+L(6)/L(1)*SPlength(5)*logl5)/sum(SPlength(3:5));
grad_bar2=(L(4)/L(1)*SPlength(3)*grad3+L(5)/L(1)*SPlength(4)*grad4+L(6)/L(1)*SPlength(5)*grad5)/sum(SPlength(3:5));
Hess_bar2=(L(4)/L(1)*SPlength(3)*Hess3+L(5)/L(1)*SPlength(4)*Hess4+L(6)/L(1)*SPlength(5)*Hess5)/sum(SPlength(3:5));
logl_bar3=(L(7)/L(1)*SPlength(6)*logl6+L(8)/L(1)*SPlength(7)*logl7+L(9)/L(1)*SPlength(8)*logl8+L(10)/L(1)*SPlength(9)*logl9)/sum(SPlength(6:9));
grad_bar3=(L(7)/L(1)*SPlength(6)*grad6+L(8)/L(1)*SPlength(7)*grad7+L(9)/L(1)*SPlength(8)*grad8+L(10)/L(1)*SPlength(9)*grad9)/sum(SPlength(6:9));
Hess_bar3=(L(7)/L(1)*SPlength(6)*Hess6+L(8)/L(1)*SPlength(7)*Hess7+L(9)/L(1)*SPlength(8)*Hess8+L(10)/L(1)*SPlength(9)*Hess9)/sum(SPlength(6:9));
logl=(1+sum(W))*logl0-W(1)*logl_bar1-W(2)*logl_bar2-W(3)*logl_bar3;
grad=(1+sum(W))*grad0-W(1)*grad_bar1-W(2)*grad_bar2-W(3)*grad_bar3;
Hess=(1+sum(W))*Hess0-W(1)*Hess_bar1-W(2)*Hess_bar2-W(3)*Hess_bar3;

function [x f condition it x2]=NewtonRaphsonMax(FUN,x,x2,varargin) % varargout
% maximises FUN, starting at x by Newton-Raphson method
tol=1e-3; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x);
[f g H x2]=feval(FUN,x,x2,varargin{:}); %varargout
while it<=maxit && condition==1 && improvement==1;
    %[s1 s2]=size(H); if s1==s2 && s2>1 d=-inv(H)*g; else d=-g./H; end 
    fun = func2str(FUN);
    if  isempty(strfind(fun,'FE'))==1, d=-inv(H)*g'; else d=-g./H; end 
    step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff gg HH xx2]=feval(FUN,x+step*d,x2,varargin{:}); %varargout
        if (ff-f)/abs(f)>=-1e-6
            improvement=1; condition=sqrt(step*step*(d'*d))>tol & (ff-f)>tol;
            x=x+step*d; x2=xx2; f=ff; g=gg; H=HH;
        else
            step=step/2;
        end
        %if length(x)>length(x2); return; end
    end
    it=it+1;
end
it=it-1;

function [logl grad Hess fe GRAD_i]=CONLoglProbit(mle,fe,Y,X)
% computes normalised concentrated likelihood, gradient, Hessian
[fe felogl flag it mle]=NewtonRaphsonMax(@FELoglProbit,fe,mle,Y,X);
%if flag==1 warning('FE did not converge to a solution'); end
[T N]=size(Y); K = length(mle); I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end
F=normcdf(I); A=1-F; logF=log(F); logA=log(A);
logFA=logF+logA; logf=-0.5*(log(2*pi)+I.*I); B=exp(logf-logFA); C=-I.*B; D=(I.*I-1).*B;
E=Y-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB;
DFETHETA=cell(1,K); DFETHETATHETA=cell(K,K);
for k=1:K, DFETHETA{k} = -ones(T,1)*(sum(X(1+(k-1)*T:k*T,:).*H) ./sum(H)); end
for k=1:K, 
    for kk=1:K, 
        DFETHETATHETA{k,kk} = ones(T,1)*((sum(J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*sum(X(1+(k-1)*T:k*T,:).*H)...
                            - sum(X(1+(k-1)*T:k*T,:).*J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*sum(H))./((sum(H)).^2));
    end
end
logl=mean(mean(Y.*logF+(1-Y).*logA));
for k=1:K, grad(k) = mean(mean(EB.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}))); end
for k=1:K, for kk=1:K, Hess(k,kk) = mean(mean(H.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}).*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})+EB.*DFETHETATHETA{k,kk})); end; end

GRAD_i=cell(1,N); 
for k=1:K,
    s_ik = mean(EB.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}));
    for i=1:N, GRAD_i{i}(k) = s_ik(i); end
end

function [logl grad Hess mle]=FELoglProbit(fe,mle,Y,X)
% likelihood function, gradient and Hessian for fixed effects
[T,N]=size(Y); K = length(mle);
I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end 
F=normcdf(I); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA; logf=-0.5*(log(2*pi)+I.*I); 
B=exp(logf-logFA); C=-I.*B; E=Y-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB;
logl=sum(sum(Y.*logF+(1-Y).*logA)); grad=sum(EB)'; Hess=sum(H)';

function [hk fe_hk flag]=HK(Z,indicator,mle,fe,m) % m is bandwidth parameter
% performs analytical bias correction as in Hahn-Kuersteiner (2004)
global model
DLogl=strcat('DLogl',model); FUN=str2func(DLogl); % call DLogl for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe_ind=fe(indicator); % clean data
hk=mle-FUN(mle,fe_ind',Z{:},m); if isnan(hk)==1, flag=1; else flag=0; end
ff=zeros(1,length(fe_ind));
%K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe_ind=fe(indicator); %clean data
FELogl=strcat('FELogl',model); FUN=str2func(FELogl);
[fe_ind felogl flagFE it mmle]=NewtonRaphsonMax(FUN,ff',hk,Z{1},Z{2});
fe_hk=fe; fe_hk(indicator==1)=fe_ind; % fe_hk=fe_hk';

function bias=DLoglProbit(mle,fe,Y,X,m) % m is bandwidth parameter
% computes bias approximation from Hahn-Kuersteiner (2004)
[T N]=size(Y); K = length(mle);
I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end; 
s=max(std(I)); ss=mean(mean(I)); I=(I-ss)/s;
F=normcdf(I); ind1=F==1; ind0=F==0; ind=ind1+ind0; succes=ind==0; 
A=1-F; logF=log(F);%logF=F; logF(ind0==0)=log(F(ind0==0)); logF(ind0==1)=-realmax; 
       logA=log(A);%logA=A; logA(ind1==0)=log(A(ind1==0)); logA(ind1==1)=-realmax; 
logf=-0.5*(log(2*pi)+I.*I);
logFA=logF+logA;  B=exp(logf-logFA); C=-I.*B; D=(I.*I-1).*B; 
E=Y-F;
E=E.*succes;  E(isnan(E)==1)=0; E(isinf(E)==1)=0;
B=B.*succes;  B(isnan(B)==1)=0; B(isinf(B)==1)=0;
C=C.*succes;  C(isnan(C)==1)=0; C(isinf(C)==1)=0;
EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB;
H=H.*succes;  H(isnan(H)==1)=0; H(isinf(H)==1)=0;
J=J.*succes;  J(isnan(J)==1)=0; J(isinf(J)==1)=0;
HH=sum(H); HH(HH==0)=realmax;
for k=1:K, DFETHETA{k} = -ones(T,1)*(sum(X(1+(k-1)*T:k*T,:).*H) ./HH); end
for k=1:K,    
    for kk=1:K, 
        DFETHETATHETA{k,kk} = ones(T,1)*((sum(J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*sum(X(1+(k-1)*T:k*T,:).*H)...
                            - sum(X(1+(k-1)*T:k*T,:).*J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*HH)./((HH).^2));
    end
end
V=EB; Vfe=H; Vfefe=J;
for k=1:K,        
    Utheta{k}  = EB.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k});
    Uthetafe{k}=  H.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k});
    for kk=1:K, % still assign to matrix/cell array
        Uthetatheta{k,kk} = H.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}).*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})+EB.*DFETHETATHETA{k,kk};
    end
    Uthetafefe{k}=J.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}) ;
end
% compute spectra and cross-spectra
M=(-m:1:m); GVV=zeros(length(M),N); GVUtheta=cell(1,K); for k=1:K, GVUtheta{k}=zeros(length(M),N); end 
for j=1:length(M)
    l=max(1,M(j)+1); u=min(T,T+M(j));
    gVV =V(l:u,:).*V(l-M(j):u-M(j),:);    GVV(j,:) =mean(gVV);
    for k=1:K, gVU=V(l:u,:).*Uthetafe{k}(l-M(j):u-M(j),:); GVUtheta{k}(j,:)=mean(gVU); end
end
fVV=sum(GVV);  fVUtheta=cell(1,K); for k=1:K, fVUtheta{k} = sum(GVUtheta{k}); end
% form bias estimate
DEN=zeros(K,K); NUM=zeros(K,1);
for k=1:K, for kk=1:K, DEN(k,kk) = mean(mean(Uthetatheta{k,kk})); end; 
           NUM(k) = mean(fVUtheta{k}./mean(Vfe)-(mean(Uthetafefe{k}).*fVV)./(2*(mean(Vfe)).^2)); 
end
c = rcond(DEN); 
if isnan(c)==1,  
    disp('non-defined conditioning number')
end
bias=1/T*(inv(DEN)*NUM); %bias=s*bias;

function [fv fe_fv flag]=FV(Z,indicator,mle,fe,m) % m is bandwidth parameter
% performs analytical bias correction as in Fernandez-Val (2009)
global model
FVLogl=strcat('FV',model); FUN=str2func(FVLogl); % call DDLogl for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe_ind=fe(indicator); % clean data
fv=mle-FUN(mle,fe_ind',Z{:},m); if isnan(fv)==1, flag=1; else flag=0; end
ff=zeros(1,length(fe_ind));
%K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe_ind=fe(indicator); %clean data
FELogl=strcat('FELogl',model); FUN=str2func(FELogl);
[fe_ind felogl flagFE it mle]=NewtonRaphsonMax(FUN,ff',fv,Z{1},Z{2});
fe_fv=fe; fe_fv(indicator==1)=fe_ind; 

function [bias]=FVProbit(mle,fe,Y,X,m) % m is bandwidth parameter
% computes bias approximation for Probit from Fernandez-Val (2009)
[T N]=size(Y); K = length(mle);
I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end; 
F=normcdf(I); ind1=F==1; ind0=F==0; ind=ind1+ind0; succes=ind==0;
A=1-F; logF=log(F);%logF=F; logF(ind0==0)=log(F(ind0==0)); logF(ind0==1)=-realmax; 
       logA=log(A);%logA=A; logA(ind1==0)=log(A(ind1==0)); logA(ind1==1)=-realmax; 
logf=-0.5*(log(2*pi)+I.*I);
logFA=logF+logA;  B=exp(logf-logFA); C=-I.*B; D=(I.*I-1).*B; 
E=Y-F;
E=E.*succes;  E(isnan(E)==1)=0; E(isinf(E)==1)=0;
B=B.*succes;  B(isnan(B)==1)=0; B(isinf(B)==1)=0;
C=C.*succes;  C(isnan(C)==1)=0; C(isinf(C)==1)=0;
EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB;
H=H.*succes;  H(isnan(H)==1)=0; H(isinf(H)==1)=0;
J=J.*succes;  J(isnan(J)==1)=0; J(isinf(J)==1)=0;
h=B; f=exp(logf); 
f=f.*succes;  f(isnan(f)==1)=0; f(isinf(f)==1)=0; 
g=C./B.*f;   g(isnan(g)==1)=0; g(isinf(g)==1)=0;
sigma=1./mean(h.*f); sigma(isnan(sigma)==1)=0; sigma(isinf(sigma)==1)=0;  psi = (h.*E).*(ones(T,1)*sigma); 
for k=1:K, 
    for kk=1:K, 
        jj      = mean(h.*f.*X(1+(k-1)*T:k*T,:).*X(1+(kk-1)*T:kk*T,:))- mean(h.*f.*X(1+(k-1)*T:k*T,:)).*mean(h.*f.*X(1+(kk-1)*T:kk*T,:)).*sigma; 
        j(k,kk) = mean(jj);
    end
end
betabeta=zeros(1,N);
for mm=1:m, for t=mm+1:T, betabeta = betabeta+(h(t,:).*f(t,:).*psi(t-mm,:))/((T-mm)); end; end
beta = -mean(h.*g).*sigma.^2/2-betabeta.*sigma;
bb = cell(1,K); 
for k=1:K, 
    bb{k}=zeros(1,N); x=X(1+(k-1)*T:k*T,:); 
    for mm=1:m, for t=mm+1:T, bb{k} = bb{k}+(h(t,:).*f(t,:).*x(t,:).*psi(t-mm,:))/((T-mm)); end; end
    b(k) = mean(-mean(h.*f.*x).*beta-mean(h.*g.*x).*sigma/2-bb{k});
end
bias = 1/T*(inv(j)*b');

function [ahe fe flag]=AH(Z,indicator,ahe,fe,m) % m is bandwidth parameter
% performs analytical bias correction to likelihood as in Arellano-Hahn (2006)
% this version is the efficient counterpart as described in Arellano-Hospido (2007)
global model ar
ZZ=Z; DDELogl=strcat('DDELogl',model); FUN=str2func(DDELogl); % call DDELogl for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe_ind=fe(indicator);
[ahe fe_ind logl flag iter] = NewtonPartitionedMax(FUN,ahe,fe_ind',Z{:},m); 
if flag==1 warning('Efficient AH correction did not converge'); end
fe(indicator)=fe_ind'; 

function [Alogl,Agtheta,Agfe,AHtheta,AHfe,AHfetheta]=DDELoglProbit(mle,fe,Y,X,m)
% sets up efficient version of adjusted likelihood from Arellano-Hahn (2006)
[T N]=size(Y);  dim = length(mle);
I=ones(T,1)*fe'; for k=1:dim, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end
F=normcdf(I); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+I.*I); B=exp(logf-logFA); C=-I.*B; D=(I.*I-1).*B; M=(3-I.*I).*I.*B;  % B=f/(F(1-F)) C=df/(F(1-F))
E=Y-F; EB=E.*B; EC=E.*C; ED=E.*D; EM=E.*M; HH=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 
K=EM-4*EB.*ED+12*EB.*EB.*EC-3*EC.*EC-6*EB.*EB.*EB.*EB;
for k=1:dim, XH{k} =X(1+(k-1)*T:k*T,:).*HH; XJ{k}=X(1+(k-1)*T:k*T,:).*J; XK{k}=X(1+(k-1)*T:k*T,:).*K; end
V   =EB; Va  =HH; Vaa =J; Vaaa=K;
for k=1:dim, Vtheta{k}=XH{k}; Vthetaa{k}=XJ{k}; Vathetaa{k}=XK{k}; end
for k=1:dim, for kk=1:dim, Vthetatheta{k,kk} =X(1+(k-1)*T:k*T,:).*XJ{kk}; Vathetatheta{k,kk}=X(1+(k-1)*T:k*T,:).*XK{kk}; end; end
H=-mean(Va); dH_a  =-mean(Vaa); ddH_a =-mean(Vaaa); 
for k=1:dim, dH_theta{k}  =-mean(Vthetaa{k}); ddH_thetaa{k}=-mean(Vathetaa{k}); end
for k=1:dim, for kk=1:dim, ddH_thetatheta{k,kk}=-mean(Vathetatheta{k,kk}); end; end             
M=(-m:1:m); 
Gamma=zeros(length(M),N); dGamma_a=Gamma; ddGamma_a=Gamma;
                          dGamma_theta=cell(1,dim); for k=1:dim dGamma_theta{k}=Gamma; end; ddGamma_thetaa=dGamma_theta;
                          ddGamma_thetatheta=cell(dim,dim); for k=1:dim, for kk=1:dim, dGamma_theta{k,kk}=Gamma; end; end                         
for j=1:length(M)
    l=max(1,M(j)+1); u=min(T,T+M(j)); w=1-M(j)/(m+1); % w is kernel weight (Bartlett)
    z=(T-M(j))/T;
    Gamma(j,:)     =w*z*mean(V(l:u,:).*V(l-M(j):u-M(j),:));
    dGamma_a(j,:)  =w*z*mean(Va(l:u,:).*V(l-M(j):u-M(j),:)+V(l:u,:).*Va(l-M(j):u-M(j),:));
    ddGamma_a(j,:) =w*z*mean(Vaa(l:u,:).*V(l-M(j):u-M(j),:)+2*Va(l:u,:).*Va(l-M(j):u-M(j),:)+V(l:u,:).*Vaa(l-M(j):u-M(j),:));
    for k=1:dim, dGamma_theta{k}(j,:) = w*z*mean(Vtheta{k}(l:u,:).*V(l-M(j):u-M(j),:)+V(l:u,:).*Vtheta{k}(l-M(j):u-M(j),:)); end
    for k=1:dim, 
        for kk=1:dim, 
            ddGamma_thetatheta{k,kk}(j,:)=w*z*mean(Vthetatheta{k,kk}(l:u,:).*V(l-M(j):u-M(j),:)+Vtheta{k}(l:u,:).*Vtheta{kk}(l-M(j):u-M(j),:)+ Vtheta{kk}(l:u,:).*Vtheta{k}(l-M(j):u-M(j),:)+V(l:u,:).*Vthetatheta{k,kk}(l-M(j):u-M(j),:));
        end
    end
    for k=1:dim, 
        ddGamma_thetaa{k}(j,:)=w*z*mean(Vthetaa{k}(l:u,:).*V(l-M(j):u-M(j),:)+Vtheta{k}(l:u,:).*Va(l-M(j):u-M(j),:)+ Va(l:u,:).*Vtheta{k}(l-M(j):u-M(j),:)+V(l:u,:).*Vthetaa{k}(l-M(j):u-M(j),:));
    end
end
Ups=sum(Gamma); dUps_a=sum(dGamma_a); ddUps_a=sum(ddGamma_a);
for k=1:dim, dUps_theta{k} = sum(dGamma_theta{k});  end % ddUps_theta{k}=sum(ddGamma_theta{k});
for k=1:dim, for kk=1:dim, ddUps_thetatheta{k,kk}=sum(ddGamma_thetatheta{k,kk})   ; end; end
for k=1:dim, ddUps_thetaa{k}=sum(ddGamma_thetaa{k});                                        end
% product correction
Beta     =.5*sum(Ups./H); dBeta_a  =.5*((dUps_a.*H-dH_a.*Ups)./(H.*H)); ddBeta_a =.5*(((ddUps_a.*H-ddH_a.*Ups).*(H.*H)-2*H.*dH_a.*(dUps_a.*H-dH_a.*Ups))./(H.*H.*H.*H));
for k=1:dim,  dBeta_theta(k) =.5*sum((dUps_theta{k}.*H-dH_theta{k}.*Ups)./(H.*H)); end
for k=1:dim, for kk=1:dim,
        ddBeta_thetatheta(k,kk)=.5*sum(((ddUps_thetatheta{k,kk}.*H+dUps_theta{k}.*dH_theta{kk}-ddH_thetatheta{k,kk}.*Ups-dH_theta{k}.*dUps_theta{kk}).*(H.*H)-2*H.*dH_theta{kk}.*(dUps_theta{k}.*H-dH_theta{k}.*Ups))./(H.*H.*H.*H));
    end
end
for k=1:dim, ddBeta_thetaa(k,:)=.5*(((ddUps_thetaa{k}.*H+dUps_theta{k}.*dH_theta{k}-ddH_thetaa{k}.*Ups-dH_theta{k}.*dUps_a)...
        .*(H.*H)-2*H.*dH_a.*(dUps_theta{k}.*H-dH_theta{k}.*Ups))./(H.*H.*H.*H)); end
% normalised logl-likelihood (uncorrected)
logl=sum(sum(Y.*logF+(1-Y).*logA));
for k=1:dim, gtheta(k) = sum(sum(X(1+(k-1)*T:k*T,:).*EB)); end; gfe=sum(EB)';
for k=1:dim, for kk=1:dim, Htheta(k,kk)=sum(sum(X(1+(k-1)*T:k*T,:).*XH{kk})); end; end; Hfe=sum(HH)';
for k=1:dim, Hfetheta(:,k)=sum(XH{k})'; end
% adjusted (normalised) loglikelihood and derivatives
Alogl    =logl-Beta;
Agtheta  =(gtheta-dBeta_theta)';
Agfe     =gfe-dBeta_a';
AHtheta  =Htheta-ddBeta_thetatheta;
AHfe     =Hfe-ddBeta_a';
AHfetheta=Hfetheta-ddBeta_thetaa';

function [mmle mfe flag] = CARRO(Z,indicator,mmle,fe)
global model
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; sfe=fe(indicator); %clean data
CLogl=strcat('C',model); FUN=str2func(CLogl); % call C for 'model' 
[mmle grad flag iter]=NewtonRaphsonMoment(FUN,mmle,sfe,Z{:});
FELogl=strcat('FELogl',model); FUN=str2func(FELogl); % call FELogl for 'model'
[mmle_fe]=NewtonRaphsonMax(FUN,sfe',mmle,Z{:});
mfe=fe; mfe(indicator==1)=mmle_fe;

function [x g condition it]=NewtonRaphsonMoment(FUN,x,x2,varargin) % varargout
% maximises FUN, starting at x by Newton-Raphson method
tol=1e-8; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x);
[g]=feval(FUN,x,x2,varargin{:}); %varargout
[H]=Jacobian(FUN,x,x2,varargin{:});
while it<=maxit && condition==1 && improvement==1;
    d=-inv(H)*g; step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [gg]=feval(FUN,x+step*d,x2,varargin{:}); %varargout
        [HH]=Jacobian(FUN,x+step*d,x2,varargin{:});
        if norm(g)>=1e-8
            improvement=1; condition=sqrt(step*step*(d'*d))>tol & norm(g-gg)>tol;
            x=x+step*d; g=gg; H=HH;
        else
            step=step/2;
        end
    end
    it=it+1;
end
it=it-1;

function [Ascore] = CProbit(mmle,mfe,Y,X)% currently only set up to include AR1 dynamics (and Xs)
% Computes modified profile score for probit as in Carro (2007)
Y0=X(1,:); rho=mmle(1); 
[T N]=size(Y); K = length(mmle); x=zeros(T,N); for k=2:K, x = x+mmle(k)*X(1+(k-1)*T:k*T,:); end; 
[mfe] = NewtonRaphsonMax(@FELoglProbit,mfe',mmle,Y,X); mfe=mfe';
PrS = zeros(T,N); PrF = PrS;
PrS(1,:) = normcdf(mfe+rho*Y0+x(1,:)); PrF(1,:) =  1-PrS(1,:) ;
for t=2:T, 
    PrS(t,:) = normcdf(mfe+rho* 1+x(t,:)).*PrS(t-1,:)+normcdf(mfe+rho* 0+x(t,:)).*PrF(t-1,:); 
    PrF(t,:) =  1-PrS(t,:); 
end
dPrS = zeros(T,N); dPrF = dPrS;
dPrS(1,:) = normpdf(mfe+rho*Y0+x(1,:)); dPrF(1,:) = -dPrS(1,:);
for t=2:T, 
    dPrS(t,:) = normpdf(mfe+rho* 1+x(t,:)).* PrS(t-1,:)+normpdf(mfe+rho* 0+x(t,:)).* PrF(t-1,:)...
              + normcdf(mfe+rho* 1+x(t,:)).*dPrS(t-1,:)+normcdf(mfe+rho* 0+x(t,:)).*dPrF(t-1,:);
    dPrF(t,:) = -dPrS(t,:);      
end
EDfefe = zeros(T,N); EDfetheta=cell(1,K); for k=1:K, EDfetheta{k}=EDfefe; end
EDfefe(1,:)        =          D2(1,Y0,mfe,x(1,:),rho).*PrS(1,:) + D2(0,Y0,mfe,x(1,:),rho).*PrF(1,:) ; 
EDfetheta{1}(1,:)  = Y0    .*(D2(1,Y0,mfe,x(1,:),rho).*PrS(1,:) + D2(0,Y0,mfe,x(1,:),rho).*PrF(1,:)); 
for k=2:K, XX = X(1+(k-1)*T:k*T,:); EDfetheta{k}(1,:) = XX(1,:).*(D2(1,Y0,mfe,x(1,:),rho).*PrS(1,:) + D2(0,Y0,mfe,x(1,:),rho).*PrF(1,:)); end
for t=2:T, 
    EDfefe(t,:)  =          (D2(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).*PrS(t-1,:)...
                 +          (D2(1,0,mfe,x(t,:),rho).*normcdf(mfe+rho*0+x(t,:)) + D2(0,0,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*0+x(t,:)))).*PrF(t-1,:)   ;         
    EDfetheta{1}(t,:) =           (D2(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).*PrS(t-1,:)   ;
    for k=2:K, XX = X(1+(k-1)*T:k*T,:);
        EDfetheta{k}(t,:)= XX(t,:).*((D2(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).*PrS(t-1,:))...
                         + XX(t,:).*((D2(1,0,mfe,x(t,:),rho).*normcdf(mfe+rho*0+x(t,:)) + D2(0,0,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*0+x(t,:)))).*PrF(t-1,:))  ; 
    end
end
EDfefe = mean(EDfefe); for k=1:K, EDfetheta{k} = mean(EDfetheta{k}); end
dEDfefe=zeros(T,N); dEDfetheta=cell(1,K); for k=1:K, dEDfetheta{k}=dEDfefe; end
dEDfefe(1,:)  =                   D3(1,Y0,mfe,x(1,:),rho).*PrS(1,:) + D3(0,Y0,mfe,x(1,:),rho).*PrF(1,:)  + D2(1,Y0,mfe,x(1,:),rho).*dPrS(1,:) + D2(0,Y0,mfe,x(1,:),rho).*dPrF(1,:); 
dEDfetheta{1}(1,:) = Y0    .*((D3(1,Y0,mfe,x(1,:),rho).*PrS(1,:) + D3(0,Y0,mfe,x(1,:),rho).*PrF(1,:)) + D2(1,Y0,mfe,x(1,:),rho).*dPrS(1,:) + D2(0,Y0,mfe,x(1,:),rho).*dPrF(1,:)); 
for k=2:K, XX = X(1+(k-1)*T:k*T,:);
    dEDfetheta{k}(1,:)= XX(1,:).*((D3(1,Y0,mfe,x(1,:),rho).*PrS(1,:) + D3(0,Y0,mfe,x(1,:),rho).*PrF(1,:)) + D2(1,Y0,mfe,x(1,:),rho).*dPrS(1,:) + D2(0,Y0,mfe,x(1,:),rho).*dPrF(1,:));
end
for t=2:T, 
    dEDfefe(t,:)        = (D3(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D3(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).* PrS(t-1,:)...
                        + (D3(1,0,mfe,x(t,:),rho).*normcdf(mfe+rho*0+x(t,:)) + D3(0,0,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*0+x(t,:)))).* PrF(t-1,:)...
                        + (D2(1,1,mfe,x(t,:),rho).*normpdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(0-normpdf(mfe+rho*1+x(t,:)))).* PrS(t-1,:)...
                        + (D2(1,0,mfe,x(t,:),rho).*normpdf(mfe+rho*0+x(t,:)) + D2(0,0,mfe,x(t,:),rho).*(0-normpdf(mfe+rho*0+x(t,:)))).* PrF(t-1,:)...
                        + (D2(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).*dPrS(t-1,:)...
                        + (D2(1,0,mfe,x(t,:),rho).*normcdf(mfe+rho*0+x(t,:)) + D2(0,0,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*0+x(t,:)))).*dPrF(t-1,:)   ;
    dEDfetheta{1}(t,:)  = (D3(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D3(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).* PrS(t-1,:)...
                        + (D2(1,1,mfe,x(t,:),rho).*normpdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(0-normpdf(mfe+rho*1+x(t,:)))).* PrS(t-1,:)...
                        + (D2(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).*dPrS(t-1,:)   ;
    for k=2:K, XX = X(1+(k-1)*T:k*T,:);
        dEDfetheta{k}(t,:)= (D3(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D3(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).* PrS(t-1,:).*XX(t,:)... %.*XX(t,:)...
                          + (D3(1,0,mfe,x(t,:),rho).*normcdf(mfe+rho*0+x(t,:)) + D3(0,0,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*0+x(t,:)))).* PrF(t-1,:).*XX(t,:)... %.*XX(t,:)...
                          + (D2(1,1,mfe,x(t,:),rho).*normpdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(0-normpdf(mfe+rho*1+x(t,:)))).* PrS(t-1,:).*XX(t,:)...
                          + (D2(1,0,mfe,x(t,:),rho).*normpdf(mfe+rho*0+x(t,:)) + D2(0,0,mfe,x(t,:),rho).*(0-normpdf(mfe+rho*0+x(t,:)))).* PrF(t-1,:).*XX(t,:)...
                          + (D2(1,1,mfe,x(t,:),rho).*normcdf(mfe+rho*1+x(t,:)) + D2(0,1,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*1+x(t,:)))).*dPrS(t-1,:).*XX(t,:)...
                          + (D2(1,0,mfe,x(t,:),rho).*normcdf(mfe+rho*0+x(t,:)) + D2(0,0,mfe,x(t,:),rho).*(1-normcdf(mfe+rho*0+x(t,:)))).*dPrF(t-1,:).*XX(t,:)   ;
    end
end
dEDfefe = mean(dEDfefe); for k=1:K, dEDfetheta{k} = mean(dEDfetheta{k}); end
[plogl pscore]=CONLoglProbit(mmle,mfe',Y,X); 
Ebias = zeros(K,1); for k=1:K, e = (dEDfetheta{k}.*EDfefe-EDfetheta{k}.*dEDfefe)./(EDfefe).^2; Ebias(k) = mean(e,2); end
Bbias = zeros(K,1); for k=1:K, XX = X(1+(k-1)*T:k*T,:);
                        b = (mean(XX.*D3(Y,X(1:T,:),mfe,x,rho))+mean(D3(Y,X(1:T,:),mfe,x,rho)).*(-sum(XX.*D2(Y,X(1:T,:),mfe,x,rho))./sum(D2(Y,X(1:T,:),mfe,x,rho))))...
                          ./(mean(D2(Y,X(1:T,:),mfe,x,rho)));
                       Bbias(k) =-.5*mean(b,2);
                    end
Ascore = pscore'+Bbias/T+Ebias/T;
Anorm = Ascore'*Ascore;

function [H] = D2(yl,yr,fe,x,rho)
[T N] = size(yl); R = ones(T,1)*fe+rho*yr+x;
F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B; D=(R.*R-1).*B; 
E=yl-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 

function [J] = D3(yl,yr,fe,x,rho)
[T N] = size(yl); R = ones(T,1)*fe+rho*yr+x;
F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B; D=(R.*R-1).*B; 
E=yl-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 

function [J]=Jacobian(func,x,x2,Y,X) 
% computes the Jacobian of a function 
n=length(x); 
fx=feval(func,x,x2,Y,X); 
eps=1.e-8; 
xperturb=x; 
for i=1:n 
    xperturb(i)=xperturb(i)+eps; 
    J(:,i)=(feval(func,xperturb,x2,Y,X)-fx)/eps; 
    xperturb(i)=x(i); 
end


