function TableS3, format compact, format short g
% DESCRIPTIVE STATISTICS
load('lfp_psid_fs.txt','-ascii'); T = 9; N = size(lfp_psid_fs,1)/T; model='Probit'; scale=0; regressors=6; dynamic=1; dummies=0; trend=0; % 0 1
reg = regressors; ar=(dynamic==1); time=(dummies==1); dim=ar+reg+(T-1)*time; ddim=ar+reg; K = dim;
Y=zeros(T,N); X=zeros(dim*T,N);
for i=1:N,  Y(:,i) = lfp_psid_fs(1+(i-1)*T:i*T,3); 
    if ar==1 && time==0          , for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,3+k) ; end; end % one lag, no time dummies, OK covariates
    if ar==1 && time==1 && reg>0 , for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,3+k) ; end; end % one lag,    time dummies,    covariates
    if ar==1 && time==1 && reg==0,              X(1:T,i)           = lfp_psid_fs(1+(i-1)*T:i*T,4  ) ;
                                   for k=2:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,9+k) ; end; end % one lag,    time dummies, no covariates
                               
    if ar==0 && time==0          , for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,4 +k); end; end % one lag, no time dummies, OK covariates
    if ar==0 && time==1 && reg>0 , for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,4 +k); end; end % one lag,    time dummies,    covariates
    if ar==0 && time==1 && reg==0, for k=1:dim, X(1+(k-1)*T:k*T,i) = lfp_psid_fs(1+(i-1)*T:i*T,20+k); end; end % one lag,    time dummies, no covariates
end
Z = {Y X}; clear lfp_psid_fs; clear Y X; 
X     = cell(1,K)   ; for k=1:K, X{k} = Z{2}(1+(k-1)*T:k*T,:); end
X{5}=exp(X{5})/1000;
X{6}=10*(X{6});
YL=Z{1}; mover=mean(YL)>0 & mean(YL)<1; nmovers=sum(mover)
for t=1:9
    for j=1:6
        means1(j,t)=mean(X{j}(t,:)); means2(j,t)=mean(X{j}(t,mover));
        stdev1(j,t)=std (X{j}(t,:)); stdev2(j,t)=std (X{j}(t,mover));
    end
end

panel1([1:2:11],:)=means1;
panel1([2:2:12],:)=stdev1;
disp('descriptive statistics, all units')
disp(panel1)

panel2([1:2:11],:)=means2;
panel2([2:2:12],:)=stdev2;
disp('descriptive statistics, movers')
disp(panel2)