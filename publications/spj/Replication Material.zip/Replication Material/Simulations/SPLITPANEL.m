function [splits weights]=SPLITPANEL(Tmin,T,bc_order) % bc_order = 1 2 3 4 ...
% determines panel splits and associated coefficient for linear
% combinations of mle's given Tmin, T and order of bias-correction (bc_order)

if bc_order==1 [splits weights]=SplitsAndWeights1(T,Tmin); end 
if bc_order==2 [splits weights]=SplitsAndWeights2(T,Tmin); end
if bc_order==3 [splits weights]=SplitsAndWeights3(T,Tmin); end


function [S W]=SplitsAndWeights1(T,Tmin)
% splits and weights for first-order bias correction
S=zeros(2,2); W=0;
if T>=Tmin+1
    T1=max(Tmin,ceil(T/2));
    T2=max(Tmin,floor(T/2));
    S =[1 T1;(T-T2+1) T];
    W =(T1+T2)/(2*T-T1-T2);
end

function [S W]=SplitsAndWeights2(T,Tmin)
% splits and weights for second-order bias correction
S=zeros(5,2); W=zeros(2,1);
if T>=Tmin+2
    T1=max(Tmin+1,ceil(T/2));
    T2=max(Tmin+1,floor(T/2));
    S(1:2,:)=[1 T1;(T-T2+1) T]; A=1-2*T/(T1+T2); C=1-(T*T)/(T1+T2)*(1/T1+1/T2);
    T1=max(Tmin,ceil(T/3));
    T2=max(Tmin,floor((T+1)/3)); f=ceil(1+(T-T2)/2);
    T3=max(Tmin,floor(T/3));      
    S(3:5,:)=[1 T1;f (f+T2-1);(T-T3+1) T]; B=1-3*T/(T1+T2+T3); D=1-(T*T)/(T1+T2+T3)*(1/T1+1/T2+1/T3);
    M=[A,B;C,D]; W=inv(M)*[-1;-1];
end

function [S W]=SplitsAndWeights3(T,Tmin)
% splits and weights for second-order bias correction
S=zeros(9,2); W=zeros(3,1);
if T>=Tmin+3
    T1=max(Tmin+2,ceil(T/2));
    T2=max(Tmin+2,floor(T/2));
    S(1:2,:)=[1 T1;(T-T2+1) T];   
    A=1-2*T/(T1+T2); D=1-(1/T1+1/T2)*(T*T)/(T1+T2); G=1-(1/(T1*T1)+1/(T2*T2))*(T*T*T)/(T1+T2);
    T1=max(Tmin+1,ceil(T/3));
    T2=max(Tmin+1,floor((T+1)/3)); f=ceil(1+(T-T2)/2);
    T3=max(Tmin+1,floor(T/3));
    S(3:5,:)=[1 T1;f (f+T2-1);(T-T3+1) T];
    B=1-3*T/(T1+T2+T3); E=1-(1/T1+1/T2+1/T3)*(T*T)/(T1+T2+T3); H=1-(1/(T1*T1)+1/(T2*T2)+1/(T3*T3))*(T*T*T)/(T1+T2+T3);
    T1=max(Tmin,ceil(T/4));
    T2=max(Tmin,floor((T+1)/4)); f2=T1+1; 
    T3=max(Tmin,ceil((T-1)/4));  f3=T1+T2+1; 
    T4=max(Tmin,floor(T/4));     f4=T1+T2+T3+1;
    r=floor((T1+T2+T3+T3-T)/3); f2=f2-r; f3=f3-r; f4=f4-r; % constructing overlap
    r=floor((f4+T4-1-T)/2); f3=f3-r;
    S(6:9,:)=[1 T1;f2 (f2+T2-1);f3 (f3+T3-1);(T-T4+1) T];
    C=1-4*T/(T1+T2+T3+T4); F=1-(1/T1+1/T2+1/T3+1/T4)*(T*T)/(T1+T2+T3+T4); I=1-(1/(T1*T1)+1/(T2*T2)+1/(T3*T3)+1/(T4*T4))*(T*T*T)/(T1+T2+T3+T4);
    M=[A,B,C;D,E,F;G,H,I]; W=inv(M)*[-1;-1;-1];
end