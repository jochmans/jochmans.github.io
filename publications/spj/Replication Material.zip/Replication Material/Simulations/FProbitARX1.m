function [bias]=FProbitARX1(mle,fe,YL,YR,X,m) % m is bandwidth parameter
% computes bias approximation from Fernandez-Val (2009) for Probit ARX1

[T N] = size(YL); I = ones(T,1)*fe'+mle(1)*YR+mle(2)*X;
F = normcdf(I); A = 1-F; logF = log(F); logA = log(A); logf = -0.5*(log(2*pi)+I.*I);
logFA = logF+logA;  B = exp(logf-logFA); C = -I.*B; D = (I.*I-1).*B; E=YL-F;
EB = E.*B; EC = E.*C; ED = E.*D; H = EC-EB.*EB; J = ED-3*EB.*EC+2*EB.*EB.*EB;
h = B; f = exp(logf); g = C./B.*f; 

sigma = 1./mean(h.*f); psi = (h.*E).*(ones(T,1)*sigma);

jrho   = mean(mean(h.*f.*YR.*YR)- mean(h.*f.*YR).*mean(h.*f.*YR).*sigma);
jbeta  = mean(mean(h.*f.* X.* X)- mean(h.*f.*X ).*mean(h.*f.* X).*sigma);
jrbeta = mean(mean(h.*f.*YR.* X)- mean(h.*f.*YR).*mean(h.*f.* X).*sigma);

j = [jrho, jrbeta; jrbeta, jbeta];

betabeta = zeros(1,N);
for mm=1:m, for t=mm+1:T, betabeta = betabeta+(h(t,:).*f(t,:).*psi(t-mm,:))/((T-mm))   ; end; end; 
beta = -mean(h.*g).*sigma.^2/2-betabeta.*sigma;
bbrho    = zeros(1,N); bbbeta=bbrho;
for mm=1:m, for t=mm+1:T, bbrho    = bbrho +(h(t,:).*f(t,:).*YR(t,:).*psi(t-mm,:))/((T-mm)); end; end; 
for mm=1:m, for t=mm+1:T, bbbeta   = bbbeta+(h(t,:).*f(t,:).* X(t,:).*psi(t-mm,:))/((T-mm)); end; end; 
brho  = mean(-mean(h.*f.*YR).*beta-mean(h.*g.*YR).*sigma/2-bbrho );
bbeta = mean(-mean(h.*f.* X).*beta-mean(h.*g.* X).*sigma/2-bbbeta);

b= [brho;bbeta];

bias = 1/T*(inv(j)*b);