function [Z FE]=GENProbitARX1(N,T,theta,sigma,design)

%design = 0; % 0 (benchmark) 1 (HK probit with iid X) 2 (HK probit with AR1
%X) % 3 (our old design + intercept in x equation )

%% benchmark design
if design==0, 
   burn=50;
   FE=sigma*randn(1,N); X=zeros(T+1+burn,N); Y=zeros(T+1+burn,N);
   % AR(1) covariate design
   delta=0; gamma=.5; % intercept and slope coefficient for AR(1) X-process
   X(1,:)=1/(sqrt(1-gamma^2))*randn(1,N);
   % AR(1)-trend covariate design
   %X(1,:)=zeros(1,N);
   % iid covariate design
   %X(1,:)=randn(1,N);                 % iid standardnormal covariate
   %X(1,:)=(.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
   Y(1,:)=zeros(1,N);
   for t=2:T+1+burn
       X(t,:) = delta+gamma*X(t-1,:)+randn(1,N); % AR(1) covariate
       %X(t,:) = .1*(t-1)+gamma*X(t-1,:)+randn(1,N); % AR(1)-trend covariate
       %X(t,:) = randn(1,N); % iid standardnormal covariate
       %X(t,:) = (.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
       Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)+randn(1,N))>=0;
   end
   Y(1:burn,:)=[]; X(1:burn,:)=[];
   YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
   Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;
end


%% HK probit design with iid regressor
if design==1,
    X  = randn(T+1,N);
    FE = .75*sum(X(1:4,:));
    Y = zeros(T+1,N); Y(1,:) = (FE +theta(2)*X(1,:)>=randn(1,N)); 
    for t=2:T+1
        Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)>=randn(1,N)); 
    end
    YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
    Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;  
end



%% HK probit design with serial correlation
if design==2,
    % AR(1) covariate design
    X = zeros(T+1,N); delta=0; gamma=.5; X(1,:)=1/(sqrt(1-gamma^2))*randn(1,N);
    for t=2:T+1, X(t,:) = delta+gamma*X(t-1,:)+randn(1,N); end
    FE = .75*sum(X(1:4,:));
    Y = zeros(T+1,N); Y(1,:) = (FE +theta(2)*X(1,:)>=randn(1,N)); 
    for t=2:T+1
        Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)>=randn(1,N)); 
    end
    YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
    Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;  
end

%% benchmark design + dependendence between alpha and x
if design==3, 
   burn=50;
   FE=sigma*randn(1,N); X=zeros(T+1+burn,N); Y=zeros(T+1+burn,N); FE2 = -(sqrt(2/3))*FE;
   % AR(1) covariate design
   delta=FE2; gamma=.5; % intercept and slope coefficient for AR(1) X-process
   X(1,:)=delta./(sqrt(1-gamma^2)).*randn(1,N);
   % AR(1)-trend covariate design
   %X(1,:)=zeros(1,N);
   % iid covariate design
   %X(1,:)=randn(1,N);                 % iid standardnormal covariate
   %X(1,:)=(.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
   Y(1,:)=zeros(1,N);
   for t=2:T+1+burn
       X(t,:) = delta+gamma*X(t-1,:)+randn(1,N); % AR(1) covariate
       %X(t,:) = .1*(t-1)+gamma*X(t-1,:)+randn(1,N); % AR(1)-trend covariate
       %X(t,:) = randn(1,N); % iid standardnormal covariate
       %X(t,:) = (.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
       Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)+randn(1,N))>=0;
   end
   Y(1:burn,:)=[]; X(1:burn,:)=[];
   YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
   Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;
end

if design==4, 
   burn=0;
   FE=sigma*randn(1,N); X=zeros(T+1+burn,N); Y=zeros(T+1+burn,N); FE2 = .5*FE;
   % AR(1) covariate design
   delta=FE2; gamma=.5; % intercept and slope coefficient for AR(1) X-process
   X(1,:)=delta./(sqrt(1-gamma^2)).*randn(1,N);
   % AR(1)-trend covariate design
   %X(1,:)=zeros(1,N);
   % iid covariate design
   %X(1,:)=randn(1,N);                 % iid standardnormal covariate
   %X(1,:)=(.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
   Y(1,:)=zeros(1,N);
   for t=2:T+1+burn
       X(t,:) = delta+gamma*X(t-1,:)+randn(1,N); % AR(1) covariate
       %X(t,:) = .1*(t-1)+gamma*X(t-1,:)+randn(1,N); % AR(1)-trend covariate
       %X(t,:) = randn(1,N); % iid standardnormal covariate
       %X(t,:) = (.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
       Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)+randn(1,N))>=0;
   end
   Y(1:burn,:)=[]; X(1:burn,:)=[];
   YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
   Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;
end