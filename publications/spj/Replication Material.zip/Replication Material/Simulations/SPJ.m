function [spj spjfe flag SMLE SFE]=SPJ(Z,indicator,SMLE,SFE,mle,fe)
% computes spj1,...,spjK (assigned by whichEST) from data Z,
% according to splits and weights determined in SPLITPANEL
global model whichSPJ %whichEST
%whichSPJ=whichEST(2:4);
if whichSPJ(1)==1 [spj1 spj1fe flag1 SMLE(:,1:2)  SFE(1:2,:) ]=SPJ1(Z,indicator,mle,fe,SMLE(:,1:2),SFE(1:2,:))  ; end 
if whichSPJ(2)==1 [spj2 spj2fe flag2 SMLE(:,3:7)  SFE(3:7,:) ]=SPJ2(Z,indicator,mle,fe,SMLE(:,3:7),SFE(3:7,:))  ; end
if whichSPJ(3)==1 [spj3 spj3fe flag3 SMLE(:,8:16) SFE(8:16,:)]=SPJ3(Z,indicator,mle,fe,SMLE(:,8:16),SFE(8:16,:)); end

if whichSPJ(1)==0 spj1=zeros(length(mle),1); spj1fe=zeros(1,length(SFE(1,:))); flag1=0; end
if whichSPJ(2)==0 spj2=zeros(length(mle),1); spj2fe=zeros(1,length(SFE(1,:))); flag2=0; end
if whichSPJ(3)==0 spj3=zeros(length(mle),1); spj3fe=zeros(1,length(SFE(1,:))); flag3=0; end

if flag1~=0 && whichSPJ(1)==1  spj1=mle; spj1fe=fe; end % if nonexistence: SPJ1=MLE 
if flag2~=0 && whichSPJ(2)==1  spj2=mle; spj2fe=fe; end % if nonexistence: SPJ2=MLE
if flag3~=0 && whichSPJ(3)==1  spj3=mle; spj3fe=fe; end % if nonexistence: SPJ3=MLE

if flag2~=0 && whichSPJ(2)==1 && whichSPJ(1)==1 && flag1==0  spj2=spj1; spj2fe=spj1fe; end % if nonexistence: SPJ2=SPJ1
if flag3~=0 && whichSPJ(3)==1 && whichSPJ(1)==1 && flag1==0  spj3=spj1; spj3fe=spj1fe; end % if nonexistence: SPJ3=SPJ1
if flag3~=0 && whichSPJ(3)==1 && whichSPJ(2)==1 && flag2==0  spj3=spj2; spj3fe=spj2fe; end % if nonexistence: SPJ3=SPJ2

spj=[spj1 spj2 spj3]; spjfe=[spj1fe;spj2fe;spj3fe]; flag=[flag1,flag2,flag3]; % flag solution


function [spj spjfe flag SMLE SFE]=SPJ1(Z,indicator,mle,fe,SMLE,SFE)
% computes spj1 from data Z with splits and weights from SPLITPANEL
global model
[T N]=size(Z{1}); [S W]=SPLITPANEL(3,T,1);   SPlength=S(:,2)-S(:,1)+1; 
for k=1:numel(Z) Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [mle1 fe1 flag1]=ML(Z1,indicator,SMLE(:,1),SFE(1,:),'SPJ1');
for k=1:numel(Z) Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [mle2 fe2 flag2]=ML(Z2,indicator,SMLE(:,2),SFE(2,:),'SPJ1'); 

mle_bar=[mle1 mle2]*SPlength/sum(SPlength); spj  =(1+W)*mle-W*mle_bar;
fe_bar =[fe1' fe2']*SPlength/sum(SPlength); spjfe=(1+W)*fe -W*fe_bar';
SMLE=[mle1 mle2]; SFE=[fe1;fe2]; flag=[flag1 flag2]; % flag solution
if sum(flag)==0 flag=0; end
if sum(flag)~=0 flag=1; end

function [spj spjfe flag SMLE SFE]=SPJ2(Z,indicator,mle,fe,SMLE,SFE)
% computes spj2 from data Z with splits and weights from SPLITPANEL
global model
[T N]=size(Z{1}); [S W]=SPLITPANEL(3,T,2);   SPlength=S(:,2)-S(:,1)+1;
for k=1:numel(Z) Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [mle1 fe1 flag1]=ML(Z1,indicator,SMLE(:,1),SFE(1,:),'SPJ2');
for k=1:numel(Z) Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [mle2 fe2 flag2]=ML(Z2,indicator,SMLE(:,2),SFE(2,:),'SPJ2'); 
for k=1:numel(Z) Z3{k}=Z{k}(S(3,1):S(3,2),:); end; [mle3 fe3 flag3]=ML(Z3,indicator,SMLE(:,3),SFE(3,:),'SPJ2');
for k=1:numel(Z) Z4{k}=Z{k}(S(4,1):S(4,2),:); end; [mle4 fe4 flag4]=ML(Z4,indicator,SMLE(:,4),SFE(4,:),'SPJ2');
for k=1:numel(Z) Z5{k}=Z{k}(S(5,1):S(5,2),:); end; [mle5 fe5 flag5]=ML(Z5,indicator,SMLE(:,5),SFE(5,:),'SPJ2');
mle_bar1=[mle1 mle2]     *SPlength(1:2)/sum(SPlength(1:2)); 
mle_bar2=[mle3 mle4 mle5]*SPlength(3:5)/sum(SPlength(3:5)); spj  =(1+sum(W))*mle-[mle_bar1 mle_bar2]*[W(1);W(2)]; 
fe_bar1=[fe1' fe2']      *SPlength(1:2)/sum(SPlength(1:2));
fe_bar2=[fe3' fe4' fe5' ]*SPlength(3:5)/sum(SPlength(3:5)); spjfe=(1+sum(W))*fe- [W(1) W(2)]*[fe_bar1' ; fe_bar2'];
SMLE=[mle1 mle2 mle3 mle4 mle5]; SFE=[fe1;fe2;fe3;fe4;fe5];
flag=[flag1 flag2 flag3 flag4 flag5]; % flag solution
if sum(flag)==0 flag=0; end
if sum(flag)~=0 flag=1; end

%if T==6
%    W=[8;-3]; %[2/9; -1/12];
%    mle_bar1=[mle1 mle2]*[1/2;1/2]; mle_bar2=[mle4 mle5]*[1/2;1/2]; 
%    spj  =(1+sum(W))*mle-[mle_bar1 mle_bar2]*[W(1);W(2)];
%    fe_bar1 =[fe1' fe2']*[1/2;1/2]; fe_bar2=[fe4' fe5']*[1/2;1/2];
%    spjfe=(1+sum(W))*fe- [W(1) W(2)]*[fe_bar1' ; fe_bar2'];
%end




function [spj spjfe flag SMLE SFE]=SPJ3(Z,indicator,mle,fe,SMLE,SFE)
% computes spj3 from data Z with splits and weights from SPLITPANEL
global model
[T N]=size(Z{1}); [S W]=SPLITPANEL(3,T,3);   SPlength=S(:,2)-S(:,1)+1;
for k=1:numel(Z) Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [mle1 fe1 flag1]=ML(Z1,indicator,SMLE(:,1),SFE(1,:),'SPJ3');
for k=1:numel(Z) Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [mle2 fe2 flag2]=ML(Z2,indicator,SMLE(:,2),SFE(2,:),'SPJ3'); 
for k=1:numel(Z) Z3{k}=Z{k}(S(3,1):S(3,2),:); end; [mle3 fe3 flag3]=ML(Z3,indicator,SMLE(:,3),SFE(3,:),'SPJ3');
for k=1:numel(Z) Z4{k}=Z{k}(S(4,1):S(4,2),:); end; [mle4 fe4 flag4]=ML(Z4,indicator,SMLE(:,4),SFE(4,:),'SPJ3'); 
for k=1:numel(Z) Z5{k}=Z{k}(S(5,1):S(5,2),:); end; [mle5 fe5 flag5]=ML(Z5,indicator,SMLE(:,5),SFE(5,:),'SPJ3');
for k=1:numel(Z) Z6{k}=Z{k}(S(6,1):S(6,2),:); end; [mle6 fe6 flag6]=ML(Z6,indicator,SMLE(:,6),SFE(6,:),'SPJ3');
for k=1:numel(Z) Z7{k}=Z{k}(S(7,1):S(7,2),:); end; [mle7 fe7 flag7]=ML(Z7,indicator,SMLE(:,7),SFE(7,:),'SPJ3');
for k=1:numel(Z) Z8{k}=Z{k}(S(8,1):S(8,2),:); end; [mle8 fe8 flag8]=ML(Z8,indicator,SMLE(:,8),SFE(8,:),'SPJ3');
for k=1:numel(Z) Z9{k}=Z{k}(S(9,1):S(9,2),:); end; [mle9 fe9 flag9]=ML(Z9,indicator,SMLE(:,9),SFE(9,:),'SPJ3');
mle_bar1=[mle1 mle2]          *SPlength(1:2)/sum(SPlength(1:2)); 
mle_bar2=[mle3 mle4 mle5]     *SPlength(3:5)/sum(SPlength(3:5));
mle_bar3=[mle6 mle7 mle8 mle9]*SPlength(6:9)/sum(SPlength(6:9)); spj =(1+sum(W))*mle-[mle_bar1 mle_bar2 mle_bar3]*[W(1); W(2); W(3)];
fe_bar1=[fe1' fe2']           *SPlength(1:2)/sum(SPlength(1:2));
fe_bar2=[fe3' fe4' fe5']      *SPlength(3:5)/sum(SPlength(3:5));
fe_bar3=[fe6' fe7' fe8' fe9'] *SPlength(6:9)/sum(SPlength(6:9)); spjfe=(1+sum(W))*fe-[W(1) W(2) W(3)]*[fe_bar1';fe_bar2';fe_bar3'];
SMLE=[mle1 mle2 mle3 mle4 mle5 mle6 mle7 mle8 mle9]; SFE=[fe1;fe2;fe3;fe4;fe5;fe6;fe7;fe8;fe9];
flag=[flag1 flag2 flag3 flag4 flag5 flag6 flag7 flag8 flag9]; % flag solution
if sum(flag)==0 flag=0; end
if sum(flag)~=0 flag=1; end