function [logl gtheta gfe Htheta Hfe Hfetheta]=LoglProbitARX1(mle,fe,YL,YR,X)
% computes likelihood (logl), partitioned score (g) and partitioned hessian (H)
[T N]=size(YL);
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X; 
F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B;  % B=f/(F(1-F)) C=df/(F(1-F)) 
E=YL-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB; YRH=YR.*H; XH=X.*H; 

logl=sum(sum(YL.*logF+(1-YL).*logA));
grho=sum(sum(YR.*EB));     gbeta=sum(sum(X.*EB)); gfe=sum(EB)';    
Hrho=sum(sum(YR.*YRH));    Hbeta=sum(sum(X.*XH)); Hfe=sum(H)';
Hrhobeta=sum(sum(YR.*XH)); Hferho=sum(YRH)';      Hfebeta=sum(XH)'; 
gtheta=[grho;gbeta]; 
Htheta=[Hrho,Hrhobeta;Hrhobeta,Hbeta]; Hfetheta=[Hferho,Hfebeta];