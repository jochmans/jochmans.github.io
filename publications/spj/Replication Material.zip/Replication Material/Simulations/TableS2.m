function TableS2, format compact, format short, global N T rho psi2 sigma alpha R
rng(round(1000*clock*[0 0 0 3600 60 1]'))
sigma = 1; alpha = .05;
disp('                                            --------------------- bias -------------------    ----------------- se/sd ----------------------    ----------------- coverage -------------------    --- validity ---')
disp('      N         T        gamma      psi       mle       hk       spj       spjl       ab        mle       hk       spj       spjl       ab        mle       hk       spj       spjl       ab                      ')

N=100; R = 10000;  

psi2 = 0; rho = .5 ; for T=[4 6 8 12], Go, end
psi2 = 4; rho = .5 ; for T=[4 6 8 12], Go, end
psi2 = 0; rho = .95; for T=[4 6 8 12], Go, end
psi2 = 4; rho = .95; for T=[4 6 8 12], Go, end


function Go, global N T rho alpha R psi2 
Est=zeros(R,5); Ava=Est; Val=zeros(R,2); MLE=zeros(R,3); VMLE=MLE;
for r=1:R
    Y = GenerateData; YY=Y; X=Y; X(end,:)=[]; Y(1,:)=[];
    [gmm,      var] = ArellanoBond(YY)             ;                                 v_gmm  = N*T*var;
    [mle          ] = MaximumLikelihood(Y,X)       ; [~,h] = ProfileScore(Y,X,mle ); v_mle  = -1/h*T/(T-1); %df correction
    [spj,mle1,mle2] = SplitPanelJackknife(Y,X,mle) ; 
    [spjl         ] = SplitPanelLikelihood(Y,X,rho); 
    hk = mle+(1+mle)/T                             ; v_hk = v_mle*(1+1/T)^2; 
    Y1 = Y(1    :T/2,:); X1 = X(1    :T/2,:); [s1,~] = ProfileScore(Y1,X1,mle); [~,h] = ProfileScore(Y1,X1,mle1); v_mle1=-1/h*(T/2)/(T/2-1);
    Y2 = Y(T/2+1:end,:); X2 = X(T/2+1:end,:); [s2,~] = ProfileScore(Y2,X2,mle); [~,h] = ProfileScore(Y2,X2,mle2); v_mle2=-1/h*(T/2)/(T/2-1);
    v_spj =(v_mle1+v_mle2)/2; v_spjl=v_spj;
    Est(r,:) =[  mle   hk   spj   spjl   gmm]; 
    Ava(r,:) =[v_mle v_hk v_spj v_spjl v_gmm]; 
    Val(r,:) =[mle1-mle2 s1-s2];
    MLE(r,:) =[mle mle1 mle2];
    VMLE(r,:)=[v_mle v_mle1 v_mle2];
end
Dev=Est-rho; bias=mean(Dev); sd=std(Dev); se=mean(sqrt(Ava/N/T)); rmse=sqrt(sd.^2+bias.^2); crit=chi2inv(1-alpha,1);
                            z=N*T  *(Dev.*Dev./Ava); z=z<crit; coverage=mean(z);
ava=[Ava(:,3) 1./Ava(:,4)]; z=N*T/4*(Val.*Val./ava); z=z<crit; validity=mean(z); 
disp([N T rho sqrt(psi2) bias se./sd coverage validity])

FILE=strcat('Table1_LinearAR1','.xls'); fid=fopen(FILE,'a+');
fprintf(fid,'%g\t',[R N T rho sqrt(psi2) bias NaN se./sd NaN rmse NaN coverage NaN validity]);
fprintf(fid,'\n');    fclose(fid);

function [spj,mle1,mle2] = SplitPanelJackknife(Y,X,mle), global T
Y1 = Y(1    :T/2,:); X1 = X(1    :T/2,:); mle1 = MaximumLikelihood(Y1,X1); 
Y2 = Y(T/2+1:end,:); X2 = X(T/2+1:end,:); mle2 = MaximumLikelihood(Y2,X2);
spj = 2*mle-(mle1+mle2)/2;

function [spjl] = SplitPanelLikelihood(Y,X,truth), global T
Y1 = Y(1    :T/2,:); X1 = X(1    :T/2,:); 
Y2 = Y(T/2+1:end,:); X2 = X(T/2+1:end,:);
adjusted = @(rho) 2*ProfileScore(Y,X,rho)-(ProfileScore(Y1,X1,rho)+ProfileScore(Y2,X2,rho))/2;
options = optimset('Display','off'); spjl =  fsolve(@(rho) adjusted(rho),truth,options);

function [mle] = MaximumLikelihood(Y,X)
Y = Y-ones(size(Y,1),1)*mean(Y); 
X = X-ones(size(X,1),1)*mean(X); mle = mean(mean(X.*Y))./mean(mean(X.*X)); 

function [s,H] = ProfileScore(Y,X,rho)
Y = Y-ones(size(Y,1),1)*mean(Y); % de-mean   dep. variable
X = X-ones(size(X,1),1)*mean(X); % de-mean indep. variable
U = Y-X*rho                    ;
varU = mean(mean(U.*U)); covUX = mean(mean(U.*X)); s = covUX/varU;
varX = mean(mean(X.*X)); H = -varX/varU+2*s^2;

function [abgmm,var]=ArellanoBond(Y), global T  % one-step Arellano-Bond GMM
DY=Y(2:T+1,:)-Y(1:T,:); DYL=DY; DY(1,:)=[]; DYL(T,:)=[];
s =[]; for t=1:T-1 s =[s 1:t]          ; end
ss=[]; for t=1:T-1 ss=[ss; t*ones(t,1)]; end
Z=Y(s',:); [d,n]=size(Z);
ZDY =Z.*DY(ss,:); ZDY=sum(ZDY,2); ZDYL=Z.*DYL(ss,:); ZDYL=sum(ZDYL,2);
A=Y*Y'; V1=zeros(d,d); V1(1,1)=2*A(1,1);  
for i=2:T-1
    ii=1+sum(1:i-1):sum(1:i); ij=ii(1:i-1)-i+1;
    V1(ii,ii)=2*A(1:i,1:i); V1(ii,ij)=-A(1:i,1:i-1); V1(ij,ii)=V1(ii,ij)';
end
a=V1\ZDYL; M=ZDYL'*a; abgmm=(ZDY'*a)/M;   % Arellano [2003] (6.28) & (6.31)
R=DY-abgmm*DYL; ZR=Z.*R(ss,:); V2=ZR*ZR'; var=(a'*V2*a)/(M*M);  % Arellano (6.33)

function Y = GenerateData, global N T rho sigma psi2
FE = randn(1,N); Y0 =  FE/(1-rho)+ (sqrt(psi2)*sigma/sqrt(1-rho^2))*randn(1,N);
Y=zeros(T+1,N); Y(1,:)=Y0; for t=2:T+1, Y(t,:)=FE+rho*Y(t-1,:)+sigma*randn(1,N); end