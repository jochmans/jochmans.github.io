function [Alogl,Agtheta,Agfe,AHtheta,AHfe,AHfetheta]=DDELoglLogitARX1(mle,fe,YL,YR,X,m)
% sets up efficient version of adjusted likelihood from Arellano-Hahn (2006)
[T N]=size(YL);
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X; expR=exp(R);
A=1./(1+expR); logA=log(A); F=1-A; f=F.*A; df=f.*(A-F); ddf=df.*(A-F)-2.*f.*f; 
E=YL-F; YRf=YR.*f; YRdf=YR.*df; YRddf=YR.*ddf; Xf=X.*f; Xdf=X.*df; Xddf=X.*ddf;
% a=FE, r=rho, b=beta
V   =E;    Va  =-f;         Vr  =-YRf;     Vb  =-Xf;
Vaa =-df;  Vrr =-YR.*YRdf;  Vbb =-X.*Xdf;  Vra =-YRdf;     Vba =-Xdf;   Vrb =-X.*YRdf;
Vaaa=-ddf; Varr=-YR.*YRddf; Vabb=-X.*Xddf; Varb=-X.*YRddf; Vara=-YRddf; Vaba=-Xddf;

H=-mean(Va);  dH_r  =-mean(Vra);  dH_b  =-mean(Vba);  dH_a  =-mean(Vaa);
              ddH_r =-mean(Varr); ddH_b =-mean(Vabb); ddH_a =-mean(Vaaa); 
              ddH_rb=-mean(Varb); ddH_ra=-mean(Vara); ddH_ba=-mean(Vaba);
              
M=(-m:1:m); 
Gamma=zeros(length(M),N); dGamma_r =Gamma; dGamma_b =Gamma; dGamma_a=Gamma;
                          ddGamma_r=Gamma; ddGamma_b=Gamma; ddGamma_rb=Gamma; 
                          ddGamma_a=Gamma; ddGamma_ra=Gamma; ddGamma_ba=Gamma;                         
for j=1:length(M)
    l=max(1,M(j)+1); u=min(T,T+M(j)); w=1-M(j)/(m+1); % w is kernel weight (Bartlett)
    z=(T-M(j))/T;
    Gamma(j,:)     =w*z*mean(V(l:u,:).*V(l-M(j):u-M(j),:));
    dGamma_r(j,:)  =w*z*mean(Vr(l:u,:).*V(l-M(j):u-M(j),:)+V(l:u,:).*Vr(l-M(j):u-M(j),:));
    dGamma_b(j,:)  =w*z*mean(Vb(l:u,:).*V(l-M(j):u-M(j),:)+V(l:u,:).*Vb(l-M(j):u-M(j),:));
    dGamma_a(j,:)  =w*z*mean(Va(l:u,:).*V(l-M(j):u-M(j),:)+V(l:u,:).*Va(l-M(j):u-M(j),:));
    ddGamma_r(j,:) =w*z*mean(Vrr(l:u,:).*V(l-M(j):u-M(j),:)+2*Vr(l:u,:).*Vr(l-M(j):u-M(j),:)+V(l:u,:).*Vrr(l-M(j):u-M(j),:));
    ddGamma_b(j,:) =w*z*mean(Vbb(l:u,:).*V(l-M(j):u-M(j),:)+2*Vb(l:u,:).*Vb(l-M(j):u-M(j),:)+V(l:u,:).*Vbb(l-M(j):u-M(j),:));
    ddGamma_a(j,:) =w*z*mean(Vaa(l:u,:).*V(l-M(j):u-M(j),:)+2*Va(l:u,:).*Va(l-M(j):u-M(j),:)+V(l:u,:).*Vaa(l-M(j):u-M(j),:));
    ddGamma_rb(j,:)=w*z*mean(Vrb(l:u,:).*V(l-M(j):u-M(j),:)+Vr(l:u,:).*Vb(l-M(j):u-M(j),:)+ Vb(l:u,:).*Vr(l-M(j):u-M(j),:)+V(l:u,:).*Vrb(l-M(j):u-M(j),:));
    ddGamma_ra(j,:)=w*z*mean(Vra(l:u,:).*V(l-M(j):u-M(j),:)+Vr(l:u,:).*Va(l-M(j):u-M(j),:)+ Va(l:u,:).*Vr(l-M(j):u-M(j),:)+V(l:u,:).*Vra(l-M(j):u-M(j),:));
    ddGamma_ba(j,:)=w*z*mean(Vba(l:u,:).*V(l-M(j):u-M(j),:)+Vb(l:u,:).*Va(l-M(j):u-M(j),:)+ Va(l:u,:).*Vb(l-M(j):u-M(j),:)+V(l:u,:).*Vba(l-M(j):u-M(j),:));
end
Ups=sum(Gamma); 
dUps_r=sum(dGamma_r);   dUps_b=sum(dGamma_b); dUps_a=sum(dGamma_a);
ddUps_r=sum(ddGamma_r); ddUps_b=sum(ddGamma_b); ddUps_a=sum(ddGamma_a);
ddUps_rb=sum(ddGamma_rb); ddUps_ra=sum(ddGamma_ra); ddUps_ba=sum(ddGamma_ba);

% product correction
Beta     =.5*sum(Ups./H);
dBeta_r  =.5*sum((dUps_r.*H-dH_r.*Ups)./(H.*H));
dBeta_b  =.5*sum((dUps_b.*H-dH_b.*Ups)./(H.*H));
dBeta_a  =.5*((dUps_a.*H-dH_a.*Ups)./(H.*H));
ddBeta_r =.5*sum(((ddUps_r.*H-ddH_r.*Ups).*(H.*H)-2*H.*dH_r.*(dUps_r.*H-dH_r.*Ups))./(H.*H.*H.*H));
ddBeta_b =.5*sum(((ddUps_b.*H-ddH_b.*Ups).*(H.*H)-2*H.*dH_b.*(dUps_b.*H-dH_b.*Ups))./(H.*H.*H.*H));
ddBeta_a =.5*(((ddUps_a.*H-ddH_a.*Ups).*(H.*H)-2*H.*dH_a.*(dUps_a.*H-dH_a.*Ups))./(H.*H.*H.*H));
ddBeta_rb=.5*sum(((ddUps_rb.*H+dUps_r.*dH_b-ddH_rb.*Ups-dH_r.*dUps_b).*(H.*H)-2*H.*dH_b.*(dUps_r.*H-dH_r.*Ups))./(H.*H.*H.*H));
ddBeta_ra=.5*(((ddUps_ra.*H+dUps_r.*dH_a-ddH_ra.*Ups-dH_r.*dUps_a).*(H.*H)-2*H.*dH_a.*(dUps_r.*H-dH_r.*Ups))./(H.*H.*H.*H));
ddBeta_ba=.5*(((ddUps_ba.*H+dUps_b.*dH_b-ddH_ba.*Ups-dH_b.*dUps_a).*(H.*H)-2*H.*dH_a.*(dUps_b.*H-dH_b.*Ups))./(H.*H.*H.*H));

% normalised logl-likelihood (uncorrected)
logl=sum(sum(logA+YL.*R));
grho=sum(sum(E.*YR));       gbeta=sum(sum(E.*X));    gfe=sum(E)'; gtheta=[grho;gbeta];  
Hrho=-sum(sum(YR.*YRf));    Hbeta=-sum(sum(X.*Xf));  Hfe=-sum(f)';
Hrhobeta=-sum(sum(X.*YRf)); Hferho=-sum(YRf)';       Hfebeta=-sum(Xf)';
Htheta=[Hrho,Hrhobeta;Hrhobeta,Hbeta]; Hfetheta=[Hferho,Hfebeta];

% adjusted (normalised) loglikelihood and derivatives
Alogl    =logl-Beta;
Agtheta  =gtheta-[dBeta_r;dBeta_b];
Agfe     =gfe-dBeta_a';
AHtheta  =Htheta-[ddBeta_r,ddBeta_rb;ddBeta_rb,ddBeta_b];
AHfe     =Hfe-ddBeta_a';
AHfetheta=Hfetheta-[ddBeta_ra',ddBeta_ba'];