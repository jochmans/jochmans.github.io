function [spjl spjlfe flag SMLE SFE]=SPJL(Z,indicator,SMLE,SFE) % spjlfe
% computes spjl1,...,spjlK (assigned by whichEST) from data Z,
% according to splits and weights determined in SPLITPANEL
global model whichSPJL %whichSPJL=whichEST(6:8);
[T N] = size(Z{1});
if whichSPJL(1)==1 [spjl1 spjl1fe flag1 SFE(1:3,:)  ]=SPJL1(Z,indicator,SMLE(:,1),SFE(1:3,:));   end % spjlfe1
if whichSPJL(2)==1 [spjl2 spjl2fe flag2 SFE(4:9,:)  ]=SPJL2(Z,indicator,SMLE(:,2),SFE(4:9,:));   end % spjlfe2
if whichSPJL(3)==1 [spjl3 spjl3fe flag3 SFE(10:19,:)]=SPJL3(Z,indicator,SMLE(:,3),SFE(10:19,:)); end % spjlfe3

if whichSPJL(1)==0 spjl1=zeros(size(SMLE,1),1); spjl1fe=zeros(1,N); flag1=0; end %  spj1fe=zeros(1,N);
if whichSPJL(2)==0 spjl2=zeros(size(SMLE,1),1); spjl2fe=zeros(1,N); flag2=0; end %  spj2fe=zeros(1,N);
if whichSPJL(3)==0 spjl3=zeros(size(SMLE,1),1); spjl3fe=zeros(1,N); flag3=0; end %  spj3fe=zeros(1,N);

if flag1==1 && whichSPJL(1)==1  spjl1=SMLE(:,1); spjl1fe=SFE(1,:); end % spj1fe=fe;
if flag2==1 && whichSPJL(2)==1  spjl2=SMLE(:,1); spjl2fe=SFE(1,:); end % spj1fe=fe;
if flag3==1 && whichSPJL(3)==1  spjl3=SMLE(:,1); spjl3fe=SFE(1,:); end % spj1fe=fe;

if flag2~=0 && whichSPJL(2)==1 && whichSPJL(1)==1 && flag1==0  spjl2=spjl1; spjl2fe=spjl1fe; end % if nonexistence: SPJ2=SPJ1
if flag3~=0 && whichSPJL(3)==1 && whichSPJL(1)==1 && flag1==0  spjl3=spjl1; spjl3fe=spjl1fe; end % if nonexistence: SPJ3=SPJ1
if flag3~=0 && whichSPJL(3)==1 && whichSPJL(2)==1 && flag2==0  spjl3=spjl2; spjl3fe=spjl2fe; end % if nonexistence: SPJ3=SPJ2


spjl=[spjl1 spjl2 spjl3];
spjlfe=[spjl1fe; spjl2fe; spjl3fe];  flag=[flag1 flag2 flag3]; %spjlfe=[spjlfe1];
% S,W,C,L CAN BE MADE GLOBAL WITHIN!?
function [spjl spjlfe flag SFE]=SPJL1(Z,indicator,spjl,SFE) % spjlfe
% computes spjl1 from data Z with splits and weights from SPLITPANEL
global model
[T N]=size(Z{1});  [S W]=SPLITPANEL(2,T,1); K=numel(Z); % split panel
for k=1:K        Z{k} =Z{k}(:,indicator)    ; end; fe0=SFE(1,indicator);  % clean data
for k=1:numel(Z) Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [indicator1 sflag(1)]=UNIQUENESS(Z1,'SPJL1');   
for k=1:numel(Z) Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [indicator2 sflag(2)]=UNIQUENESS(Z2,'SPJL1');
if  any(sflag~=0) flag=1;      spjlfe=zeros(1,N);       return   ; end
for k=1:K        Z1{k}=Z1{k}(:,indicator1)  ; end; fe1=SFE(2,indicator); fe1=fe1(indicator1);
for k=1:K        Z2{k}=Z2{k}(:,indicator2)  ; end; fe2=SFE(3,indicator); fe2=fe2(indicator2);
FE=[fe0';fe1';fe2']'; L=[length(fe0),length(fe1),length(fe2)]; C =cumsum(L); 
[spjl logl flag iter FE]=NewtonRaphsonMax(@SPJL1Logl,spjl,FE',Z,Z1,Z2,S,W,C,L);
if flag==1 warning('SPJL1 did not converge'); end
SFE(1,indicator)=FE(1:C(1))';
temp=zeros(1,length(fe0)); temp(indicator1)=FE(C(1)+1:C(2))'; SFE(2,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator2)=FE(C(2)+1:C(3))'; SFE(3,indicator)=temp;
FELogl=strcat('FELogl',model); FUN=str2func(FELogl);
[fe_temp felogl flag it sspjl]=NewtonRaphsonMax(FUN,SFE(1,indicator)',spjl,Z{:});
spjlfe=zeros(1,N); spjlfe(indicator==1)=fe_temp;

function [logl grad Hess FE]=SPJL1Logl(spjl,FE,Z,Z1,Z2,S,W,C,L)
global model
Logl=strcat('CONLogl',model); FUN=str2func(Logl); SPlength=S(:,2)-S(:,1)+1; 
[logl0 grad0 Hess0 FE(1:C(1))     ]=FUN(spjl,FE((1:C(1)))   ,Z{:} );
[logl1 grad1 Hess1 FE(C(1)+1:C(2))]=FUN(spjl,FE(C(1)+1:C(2)),Z1{:});
[logl2 grad2 Hess2 FE(C(2)+1:C(3))]=FUN(spjl,FE(C(2)+1:C(3)),Z2{:});
logl_bar=(L(2)/L(1)*SPlength(1)*logl1+L(3)/L(1)*SPlength(2)*logl2)/sum(SPlength);
grad_bar=(L(2)/L(1)*SPlength(1)*grad1+L(3)/L(1)*SPlength(2)*grad2)/sum(SPlength);
Hess_bar=(L(2)/L(1)*SPlength(1)*Hess1+L(3)/L(1)*SPlength(2)*Hess2)/sum(SPlength);
logl=(1+W)*logl0-W*logl_bar;
grad=(1+W)*grad0-W*grad_bar;
Hess=(1+W)*Hess0-W*Hess_bar;


function [spjl spjlfe flag SFE]=SPJL2(Z,indicator,spjl,SFE) % spjlfe
% computes spjl2 from data Z with splits and weights from SPLITPANEL
global model
[T N]=size(Z{1}); [S W]=SPLITPANEL(2,T,2); K=numel(Z); % split panel
for k=1:K        Z{k} =Z{k}(:,indicator)    ; end; fe0=SFE(1,indicator);  % clean data
for k=1:numel(Z) Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [indicator1 sflag(1)]=UNIQUENESS(Z1,'SPJL2');
for k=1:numel(Z) Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [indicator2 sflag(2)]=UNIQUENESS(Z2,'SPJL2');
for k=1:numel(Z) Z3{k}=Z{k}(S(3,1):S(3,2),:); end; [indicator3 sflag(3)]=UNIQUENESS(Z3,'SPJL2');
for k=1:numel(Z) Z4{k}=Z{k}(S(4,1):S(4,2),:); end; [indicator4 sflag(4)]=UNIQUENESS(Z4,'SPJL2');
for k=1:numel(Z) Z5{k}=Z{k}(S(5,1):S(5,2),:); end; [indicator5 sflag(5)]=UNIQUENESS(Z5,'SPJL2');
if  any(sflag~=0) flag=1;          return   ; end                 
for k=1:K        Z1{k}=Z1{k}(:,indicator1)  ; end; fe1=SFE(2,indicator); fe1=fe1(indicator1);
for k=1:K        Z2{k}=Z2{k}(:,indicator2)  ; end; fe2=SFE(3,indicator); fe2=fe2(indicator2);
for k=1:K        Z3{k}=Z3{k}(:,indicator3)  ; end; fe3=SFE(4,indicator); fe3=fe3(indicator3);
for k=1:K        Z4{k}=Z4{k}(:,indicator4)  ; end; fe4=SFE(5,indicator); fe4=fe4(indicator4);
for k=1:K        Z5{k}=Z5{k}(:,indicator5)  ; end; fe5=SFE(6,indicator); fe5=fe5(indicator5);
FE=[fe0';fe1';fe2';fe3';fe4';fe5']'; 
L=[length(fe0),length(fe1),length(fe2),length(fe3),length(fe4),length(fe5)]; C =cumsum(L); 
[spjl logl flag iter FE]=NewtonRaphsonMax(@SPJL2Logl,spjl,FE',Z,Z1,Z2,Z3,Z4,Z5,S,W,C,L);
if flag==1 warning('SPJL2 did not converge'); end
SFE(1,indicator)=FE(1:C(1))';
temp=zeros(1,length(fe0)); temp(indicator1)=FE(C(1)+1:C(2))'; SFE(2,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator2)=FE(C(2)+1:C(3))'; SFE(3,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator3)=FE(C(3)+1:C(4))'; SFE(4,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator4)=FE(C(4)+1:C(5))'; SFE(5,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator5)=FE(C(5)+1:C(6))'; SFE(6,indicator)=temp;
FELogl=strcat('FELogl',model); FUN=str2func(FELogl);
[fe_temp felogl flag it sspjl]=NewtonRaphsonMax(FUN,SFE(1,indicator)',spjl,Z{:});
spjlfe=zeros(1,N); spjlfe(indicator==1)=fe_temp;

function [logl grad Hess FE]=SPJL2Logl(spjl,FE,Z,Z1,Z2,Z3,Z4,Z5,S,W,C,L)
global model
Logl=strcat('CONLogl',model); FUN=str2func(Logl); SPlength=S(:,2)-S(:,1)+1; 
[logl0 grad0 Hess0 FE(1:C(1))     ]=FUN(spjl,FE((1:C(1)))   ,Z{:} );
[logl1 grad1 Hess1 FE(C(1)+1:C(2))]=FUN(spjl,FE(C(1)+1:C(2)),Z1{:});
[logl2 grad2 Hess2 FE(C(2)+1:C(3))]=FUN(spjl,FE(C(2)+1:C(3)),Z2{:});
[logl3 grad3 Hess3 FE(C(3)+1:C(4))]=FUN(spjl,FE(C(3)+1:C(4)),Z3{:});
[logl4 grad4 Hess4 FE(C(4)+1:C(5))]=FUN(spjl,FE(C(4)+1:C(5)),Z4{:});
[logl5 grad5 Hess5 FE(C(5)+1:C(6))]=FUN(spjl,FE(C(5)+1:C(6)),Z5{:});
logl_bar1=(L(2)/L(1)*SPlength(1)*logl1+L(3)/L(1)*SPlength(2)*logl2)/sum(SPlength(1:2));
grad_bar1=(L(2)/L(1)*SPlength(1)*grad1+L(3)/L(1)*SPlength(2)*grad2)/sum(SPlength(1:2));
Hess_bar1=(L(2)/L(1)*SPlength(1)*Hess1+L(3)/L(1)*SPlength(2)*Hess2)/sum(SPlength(1:2));
logl_bar2=(L(4)/L(1)*SPlength(3)*logl3+L(5)/L(1)*SPlength(4)*logl4+L(6)/L(1)*SPlength(5)*logl5)/sum(SPlength(3:5));
grad_bar2=(L(4)/L(1)*SPlength(3)*grad3+L(5)/L(1)*SPlength(4)*grad4+L(6)/L(1)*SPlength(5)*grad5)/sum(SPlength(3:5));
Hess_bar2=(L(4)/L(1)*SPlength(3)*Hess3+L(5)/L(1)*SPlength(4)*Hess4+L(6)/L(1)*SPlength(5)*Hess5)/sum(SPlength(3:5));
logl=(1+sum(W))*logl0-W(1)*logl_bar1-W(2)*logl_bar2;
grad=(1+sum(W))*grad0-W(1)*grad_bar1-W(2)*grad_bar2;
Hess=(1+sum(W))*Hess0-W(1)*Hess_bar1-W(2)*Hess_bar2;

function [spjl spjlfe flag SFE]=SPJL3(Z,indicator,spjl,SFE) % spjlfe
% computes spjl3 from data Z with splits and weights from SPLITPANEL
global model
[T N]=size(Z{1}); [S W]=SPLITPANEL(2,T,3); K=numel(Z); % split panel
for k=1:K        Z{k} =Z{k}(:,indicator)    ; end; fe0=SFE(1,indicator);  % clean data
for k=1:numel(Z) Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [indicator1 sflag(1)]=UNIQUENESS(Z1,'SPJL3');
for k=1:numel(Z) Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [indicator2 sflag(2)]=UNIQUENESS(Z2,'SPJL3');
for k=1:numel(Z) Z3{k}=Z{k}(S(3,1):S(3,2),:); end; [indicator3 sflag(3)]=UNIQUENESS(Z3,'SPJL3');
for k=1:numel(Z) Z4{k}=Z{k}(S(4,1):S(4,2),:); end; [indicator4 sflag(4)]=UNIQUENESS(Z4,'SPJL3');
for k=1:numel(Z) Z5{k}=Z{k}(S(5,1):S(5,2),:); end; [indicator5 sflag(5)]=UNIQUENESS(Z5,'SPJL3');
for k=1:numel(Z) Z6{k}=Z{k}(S(6,1):S(6,2),:); end; [indicator6 sflag(6)]=UNIQUENESS(Z6,'SPJL3');
for k=1:numel(Z) Z7{k}=Z{k}(S(7,1):S(7,2),:); end; [indicator7 sflag(7)]=UNIQUENESS(Z7,'SPJL3');
for k=1:numel(Z) Z8{k}=Z{k}(S(8,1):S(8,2),:); end; [indicator8 sflag(8)]=UNIQUENESS(Z8,'SPJL3');
for k=1:numel(Z) Z9{k}=Z{k}(S(9,1):S(9,2),:); end; [indicator9 sflag(9)]=UNIQUENESS(Z9,'SPJL3');
if  any(sflag~=0) flag=1;          return   ; end
for k=1:K        Z1{k}=Z1{k}(:,indicator1)  ; end; fe1=SFE(2,indicator) ; fe1=fe1(indicator1);
for k=1:K        Z2{k}=Z2{k}(:,indicator2)  ; end; fe2=SFE(3,indicator) ; fe2=fe2(indicator2);
for k=1:K        Z3{k}=Z3{k}(:,indicator3)  ; end; fe3=SFE(4,indicator) ; fe3=fe3(indicator3);
for k=1:K        Z4{k}=Z4{k}(:,indicator4)  ; end; fe4=SFE(5,indicator) ; fe4=fe4(indicator4);
for k=1:K        Z5{k}=Z5{k}(:,indicator5)  ; end; fe5=SFE(6,indicator) ; fe5=fe5(indicator5);
for k=1:K        Z6{k}=Z6{k}(:,indicator6)  ; end; fe6=SFE(7,indicator) ; fe6=fe6(indicator6);
for k=1:K        Z7{k}=Z7{k}(:,indicator7)  ; end; fe7=SFE(8,indicator) ; fe7=fe7(indicator7);
for k=1:K        Z8{k}=Z8{k}(:,indicator8)  ; end; fe8=SFE(9,indicator) ; fe8=fe8(indicator8);
for k=1:K        Z9{k}=Z9{k}(:,indicator9)  ; end; fe9=SFE(10,indicator); fe9=fe9(indicator9);
FE=[fe0';fe1';fe2';fe3';fe4';fe5';fe6';fe7';fe8';fe9']'; 
L=[length(fe0),length(fe1),length(fe2),length(fe3),length(fe4),length(fe5),length(fe6),length(fe7),length(fe8),length(fe9)];
C =cumsum(L); 
[spjl logl flag iter FE]=NewtonRaphsonMax(@SPJL3Logl,spjl,FE',Z,Z1,Z2,Z3,Z4,Z5,Z6,Z7,Z8,Z9,S,W,C,L);
if flag==1 warning('SPJL3 did not converge'); end
SFE(1,indicator)=FE(1:C(1))';
temp=zeros(1,length(fe0)); temp(indicator1)=FE(C(1)+1:C(2))' ; SFE(2,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator2)=FE(C(2)+1:C(3))' ; SFE(3,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator3)=FE(C(3)+1:C(4))' ; SFE(4,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator4)=FE(C(4)+1:C(5))' ; SFE(5,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator5)=FE(C(5)+1:C(6))' ; SFE(6,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator6)=FE(C(6)+1:C(7))' ; SFE(7,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator7)=FE(C(7)+1:C(8))' ; SFE(8,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator8)=FE(C(8)+1:C(9))' ; SFE(9,indicator) =temp;
temp=zeros(1,length(fe0)); temp(indicator9)=FE(C(9)+1:C(10))'; SFE(10,indicator)=temp;
FELogl=strcat('FELogl',model); FUN=str2func(FELogl);
[fe_temp felogl flag it sspjl]=NewtonRaphsonMax(FUN,SFE(1,indicator)',spjl,Z{:});
spjlfe=zeros(1,N); spjlfe(indicator==1)=fe_temp;

function [logl grad Hess FE]=SPJL3Logl(spjl,FE,Z,Z1,Z2,Z3,Z4,Z5,Z6,Z7,Z8,Z9,S,W,C,L)
global model
Logl=strcat('CONLogl',model); FUN=str2func(Logl); SPlength=S(:,2)-S(:,1)+1; 
[logl0 grad0 Hess0 FE(1:C(1))     ] =FUN(spjl,FE((1:C(1)))   ,Z{:} ) ;
[logl1 grad1 Hess1 FE(C(1)+1:C(2))] =FUN(spjl,FE(C(1)+1:C(2)),Z1{:}) ;
[logl2 grad2 Hess2 FE(C(2)+1:C(3))] =FUN(spjl,FE(C(2)+1:C(3)),Z2{:}) ;
[logl3 grad3 Hess3 FE(C(3)+1:C(4))] =FUN(spjl,FE(C(3)+1:C(4)),Z3{:}) ;
[logl4 grad4 Hess4 FE(C(4)+1:C(5))] =FUN(spjl,FE(C(4)+1:C(5)),Z4{:}) ;
[logl5 grad5 Hess5 FE(C(5)+1:C(6))] =FUN(spjl,FE(C(5)+1:C(6)),Z5{:}) ;
[logl6 grad6 Hess6 FE(C(6)+1:C(7))] =FUN(spjl,FE(C(6)+1:C(7)),Z6{:}) ;
[logl7 grad7 Hess7 FE(C(7)+1:C(8))] =FUN(spjl,FE(C(7)+1:C(8)),Z7{:}) ;
[logl8 grad8 Hess8 FE(C(8)+1:C(9))] =FUN(spjl,FE(C(8)+1:C(9)),Z8{:}) ;
[logl9 grad9 Hess9 FE(C(9)+1:C(10))]=FUN(spjl,FE(C(9)+1:C(10)),Z9{:});
logl_bar1=(L(2)/L(1)*SPlength(1)*logl1+L(3)/L(1)*SPlength(2)*logl2)/sum(SPlength(1:2));
grad_bar1=(L(2)/L(1)*SPlength(1)*grad1+L(3)/L(1)*SPlength(2)*grad2)/sum(SPlength(1:2));
Hess_bar1=(L(2)/L(1)*SPlength(1)*Hess1+L(3)/L(1)*SPlength(2)*Hess2)/sum(SPlength(1:2));
logl_bar2=(L(4)/L(1)*SPlength(3)*logl3+L(5)/L(1)*SPlength(4)*logl4+L(6)/L(1)*SPlength(5)*logl5)/sum(SPlength(3:5));
grad_bar2=(L(4)/L(1)*SPlength(3)*grad3+L(5)/L(1)*SPlength(4)*grad4+L(6)/L(1)*SPlength(5)*grad5)/sum(SPlength(3:5));
Hess_bar2=(L(4)/L(1)*SPlength(3)*Hess3+L(5)/L(1)*SPlength(4)*Hess4+L(6)/L(1)*SPlength(5)*Hess5)/sum(SPlength(3:5));
logl_bar3=(L(7)/L(1)*SPlength(6)*logl6+L(8)/L(1)*SPlength(7)*logl7+L(9)/L(1)*SPlength(8)*logl8+L(10)/L(1)*SPlength(9)*logl9)/sum(SPlength(6:9));
grad_bar3=(L(7)/L(1)*SPlength(6)*grad6+L(8)/L(1)*SPlength(7)*grad7+L(9)/L(1)*SPlength(8)*grad8+L(10)/L(1)*SPlength(9)*grad9)/sum(SPlength(6:9));
Hess_bar3=(L(7)/L(1)*SPlength(6)*Hess6+L(8)/L(1)*SPlength(7)*Hess7+L(9)/L(1)*SPlength(8)*Hess8+L(10)/L(1)*SPlength(9)*Hess9)/sum(SPlength(6:9));
logl=(1+sum(W))*logl0-W(1)*logl_bar1-W(2)*logl_bar2-W(3)*logl_bar3;
grad=(1+sum(W))*grad0-W(1)*grad_bar1-W(2)*grad_bar2-W(3)*grad_bar3;
Hess=(1+sum(W))*Hess0-W(1)*Hess_bar1-W(2)*Hess_bar2-W(3)*Hess_bar3;