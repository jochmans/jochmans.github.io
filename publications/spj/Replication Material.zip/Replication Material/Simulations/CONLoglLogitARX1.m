function [logl grad Hess fe GRAD_i]=CONLoglLogitARX1(mle,fe,YL,YR,X)
% computes normalised concentrated likelihood, gradient, Hessian
[fe felogl flag it mle]=NewtonRaphsonMax(@FELoglLogitARX1,fe,mle,YL,YR,X);
%if flag==1 warning('FE did not converge to a solution'); end
[T,N]=size(YL);
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X;
expR=exp(R); A=1./(1+expR); F=1-A; f=F.*A; df=f.*(A-F); logA=log(A); logF=log(F); 
E=YL-F; YRf=YR.*f; Xf=X.*f; YRdf=YR.*df; Xdf=X.*df;

DFERHO     =-ones(T,1)*(sum(YRf)./sum(f));
DFEBETA    =-ones(T,1)*(sum(Xf)./sum(f));
DFERHORHO  = ones(T,1)*((sum(df.*(YR+DFERHO)).*sum(YRf)-sum(YRdf.*(YR+DFERHO)).*sum(f))./((sum(f)).^2));
DFEBETABETA= ones(T,1)*((sum(df.*(X+DFEBETA)).*sum(Xf) -sum(Xdf.* (X+DFEBETA)).*sum(f))./((sum(f)).^2));
DFERHOBETA = ones(T,1)*((sum(df.*(X+DFEBETA)).*sum(YRf)-sum(YRdf.*(X+DFEBETA)).*sum(f))./((sum(f)).^2));

logl= mean(mean(YL.*logF+(1-YL).*logA));
grad= [mean(mean(E.*(YR+DFERHO))) ; mean(mean(E.*(X+DFEBETA)))];
Hess= [mean(mean(E.*DFERHORHO-f.*(YR+DFERHO).^2))           , mean(mean(E.*DFERHOBETA-f.*(YR+DFERHO).*(X+DFEBETA)));
       mean(mean(E.*DFERHOBETA-f.*(YR+DFERHO).*(X+DFEBETA))), mean(mean(E.*DFEBETABETA-f.*(X+DFEBETA).^2))        ];
  
GRAD_i=cell(1,N); 
s_ikrho = mean(E.*(YR+DFERHO)); s_ikbeta = mean(E.*(X+DFEBETA));
for i=1:N, GRAD_i{i} = [s_ikrho(i); s_ikbeta(i)]; end

function [logl grad Hess mle]=FELoglLogitARX1(fe,mle,YL,YR,X)
% likelihood function, gradient and Hessian for fixed effects
[T,N]=size(YL); 
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X;  
expR=exp(R); A=1./(1+expR); F=1-A; f=F.*A; logA=log(A); logF=log(F); E=YL-F;

logl= sum(sum(YL.*logF+(1-YL).*logA));
grad= sum(E)';
Hess=-sum(f)';