function [x1,x2,f,condition,it]=NewtonPartitionedMax(FUN,x1,x2,varargin)
% maximises FUN, starting at (x1,x2) by Newton-Raphson method
% while exploiting sparsity of hessian 
tol=1e-4; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x1);
[f g1 g2 H1 H2 H21]=feval(FUN,x1,x2,varargin{:});
while it<=maxit && condition==1 && improvement==1;
    J21=H21./(H2*ones(1,k)); A=inv(H1-H21'*J21); % pinv
    d1=-A*(g1-J21'*g2); d2=-g2./H2-J21*d1;
    step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff gg1 gg2 HH1 HH2 HH21]=feval(FUN,x1+step*d1,x2+step*d2,varargin{:});
        if (ff-f)/abs(f)>=-1e-6
            improvement=1; condition=sqrt(step*step*(d1'*d1+d2'*d2))>tol & (ff-f)>tol;
            x1=x1+step*d1; f=ff; g1=gg1; H1=HH1; H21=HH21;
            x2=x2+step*d2;       g2=gg2; H2=HH2;
        else
            step=step/2;
        end
    end
    it=it+1;
end
it=it-1;