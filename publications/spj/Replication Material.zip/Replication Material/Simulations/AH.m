function [ahe fe flag]=AH(Z,indicator,ahe,fe,m) % m is bandwidth parameter
% performs analytical bias correction to likelihood as in Arellano-Hahn (2006)
% this version is the efficient counterpart as described in Arellano-Hospido (2007)
global model
DDELogl=strcat('DDELogl',model); FUN=str2func(DDELogl); % call DDELogl for 'model'


% with m being a scalar bandwidth value
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; fe_ind=fe(indicator);
[ahe fe_ind logl flag iter] = NewtonPartitionedMax(FUN,ahe,fe_ind',Z{:},m); 
if flag==1 warning('AH correction did not converge'); end
fe(indicator)=fe_ind';

% with m being a vector of bandwidth values
%K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; 
%for b=1:length(m),
%    fe_indb=fe(b,indicator);
%    [ahe(:,b) fe_indb logl(b) flag(b) iter(b)] = NewtonPartitionedMax(FUN,ahe(:,b),fe_indb',Z{:},m(b)); % starting values must get higher dimension too
%    fe(b,indicator)=fe_indb'; if flag(b)==1 warning('AH correction for bandwidth %g\t did not converge',m(b)); end
%end
    
