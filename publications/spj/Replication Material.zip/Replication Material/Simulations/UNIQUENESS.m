function [indicator flag]=UNIQUENESS(Z,parent)
global model

if     isempty(strfind(lower(model),'probit'))==0  type='binary'; 
elseif isempty(strfind(lower(model),'logit' ))==0  type='binary'; 
elseif isempty(strfind(lower(model),'linear'))==0  type='linear'; 
else                                               type='other' ;   
end

switch type
    case 'linear'
        [indicator flag]=FULLRANK(Z,parent);
    case 'binary'
        [indicator flag]=SEPARABILITY(Z,parent);
    case 'other'
        warning('Uniqueness check for %s\t is not supported\n',model);
end
% if flag~=0 flag=1 end

function [indicator flag]=FULLRANK(Z,parent)
switch lower(parent)
    case {'mle'}
        indicator=ones(1,size(Z{1},2)); flag=0;
    case {'initial','spj1','spj2','spj3','spjl1','spjl2','spjl3'}
        K=numel(Z)-1;   [T N]=size(Z{1}); 
        X=zeros(T,K,N); XX=zeros(K,K,N); 
        for k=1:K  Z{k+1}=Z{k+1}-ones(T,1)*mean(Z{k+1},1); end
        for k=1:K  X(:,k,:)=Z{k+1};                        end
        for i=1:N  XX(:,:,i)=X(:,:,i)'*X(:,:,i);           end
        invertible=(rank(mean(XX,3))==K); flag=1-invertible;
        indicator=ones(1,N);
end
%if flag==1 warning('%s\t suffers from multicollinearity',parent); end

function [indicator flag]=SEPARABILITY(Z,parent)
global model
switch lower(parent)
    case {'mle'}
        indicator=ones(1,size(Z{1},2)); flag=0;
    case {'initial','spj1','spj2','spj3'}
        if  isempty(strfind(model,'X'))==1 [indicator flag]=SELECT(Z) ;
        else                               [indicator flag]=SELECTX(Z);
        end        
    case {'spjl1','spjl2','spjl3'}
        if  isempty(strfind(model,'X'))==1 [indicator flag]=SUBSELECT(Z) ;
        else                               [indicator flag]=SUBSELECTX(Z);
        end    
end
%if flag==2 warning('%s\t has empty data array',parent); end
%if flag==3 warning('%s\t is +/- infinity',parent);      end
%if flag==4 warning('%s\t is +   infinity',parent);      end
%if flag==4 warning('%s\t is -   infinity',parent);      end

function [indicator flag]=SELECT(Z) % AR1 case
YL=Z{1}; YR=Z{2};
indicator=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1; % informative units
YL=YL(:,indicator); YR=YR(:,indicator);
[T N]=size(YR); 
A=sum(YL.*YR)==sum(YR);             B=sum((1-YL).*YR)==sum(YR); B=-B; 
C=sum(YL.*(1-YR))==sum(1-YR); C=-C; D=sum((1-YL).*(1-YR))==sum(1-YR); 
infinities=A+B+(C+D).*((A+B)==0);
if N==0 flag=2; return; %disp('MLE is indeterminate due to collinearity');
elseif abs(mean(infinities))==1 flag=3; return; %disp('MLE is +/- infinity');
else flag=0;
end

function [indicator flag]=SELECTX(Z) % ARX1 case
YL=Z{1}; YR=Z{2}; X=Z{3};
indicator=mean(YL)>0 & mean(YL)<1;     % informative units
YL=YL(:,indicator); YR=YR(:,indicator); X=X(:,indicator);
[T N]=size(YR);
s=mean(YR)>0 & mean(YR)<1;     % informative units w.r.t. rho
yl=YL(:,s); yr=YR(:,s); [T n]=size(yr);
flag=0;
if     n==0                   flag=2; end; %disp('rho is indeterminate'); end %return;                          
if separability1(yl,yr)   ==1 flag=3; end; %disp('rho = +/- infinity');   end %return;  elseif...
if separability2(YL,YR,X) ==1 flag=4; end; %disp('beta = + infinity');    end  %return;    
if separability2(YL,YR,-X)==1 flag=5; end; %disp('beta = - infinity');    end %return; end

function condition=separability1(yl,yr)
% check (quasi-)separability with beta=0 ; condition=1/0 if yes/no
a=sum(yl.*(1-yr))==sum(1-yr);     % 1 if sequence is semi-alternating: 0 -> 1
b=sum((1-yl).*(1-yr))==sum(1-yr); % 1 if sequence is monotonically decreasing
c=sum(yl.*yr)==sum(yr);           % 1 if sequence is monotonically increasing
d=sum((1-yl).*yr)==sum(yr);       % 1 if sequence is semi-alternating: 1 -> 0
infinities=sign(-a+b+c-d);
if abs(mean(infinities))==1 condition=1; else condition=0; end

function condition=separability2(YL,YR,X)
% check separability with beta=1 ; condition=1/0 if yes/no
condition=0; [T N]=size(YR); tt=1:T;
max00=zeros(N,1); min01=zeros(N,1); E00=zeros(N,1); E01=zeros(N,1);
max10=zeros(N,1); min11=zeros(N,1); E10=zeros(N,1); E11=zeros(N,1);
for i=1:N
    T00=tt(YR(:,i)==0 & YL(:,i)==0);  T01=tt(YR(:,i)==0 & YL(:,i)==1); 
    T10=tt(YR(:,i)==1 & YL(:,i)==0);  T11=tt(YR(:,i)==1 & YL(:,i)==1);
    if size(T00,2)>0 max00(i)=max(X(T00,i)); E00(i)=1; end
    if size(T01,2)>0 min01(i)=min(X(T01,i)); E01(i)=1; end
    if size(T10,2)>0 max10(i)=max(X(T10,i)); E10(i)=1; end
    if size(T11,2)>0 min11(i)=min(X(T11,i)); E11(i)=1; end
    if E01(i)==1 & E00(i)==1 & min01(i)<max00(i);   end  % X01 >= X00 violated return;
    if E11(i)==1 & E10(i)==1 & min11(i)<max10(i);   end  % X11 >= X10 violated return;
end
z=min01-max10; z=z(E01.*E10>0); rhomax=min(z);
z=max00-min11; z=z(E00.*E11>0); rhomin=max(z);
if rhomax<rhomin return; end                             % condition on rho violated 
condition=1;

function [indicator flag]=SUBSELECT(Z); % AR1 case
% select informative units for SPJL subpanels
% flag: 0 if informative units present, 2 if subpanel is empty
YL=Z{1}; YR=Z{2};
indicator=mean(YL)>0 & mean(YL)<1 & mean(YR)>0 & mean(YR)<1; % informative units
YR=YR(:,indicator); [T N]=size(YR); if N==0 flag=2; else flag=0; end

function [indicator flag]=SUBSELECTX(Z); % ARX1 case
% select informative units for SPJL subpanels
% flag: 0 if informative units present, 2 if subpanel is empty
YL=Z{1}; YR=Z{2}; X=Z{3};
indicator=mean(YL)>0 & mean(YL)<1;     % informative units
YR=YR(:,indicator); [T N]=size(YR); if N==0 flag=2; else flag=0; end