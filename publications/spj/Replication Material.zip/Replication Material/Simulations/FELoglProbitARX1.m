function [logl grad Hess mle G]=FELoglProbitARX1(fe,mle,YL,YR,X)
% likelihood function, gradient and Hessian for fixed effects
[T,N]=size(YL); 
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X; F=normcdf(R); A=1-F; logF=log(F); logA=log(A); 
logFA=logF+logA; logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B;
E=YL-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB;

logl=sum(sum(YL.*logF+(1-YL).*logA)); 
grad=sum(EB)';
Hess=sum(H)';

G = EB;
