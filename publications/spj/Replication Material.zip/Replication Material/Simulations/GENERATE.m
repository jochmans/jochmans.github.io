function [Z FE]=GENERATE
% generates data for 'model' according to parameters from design
global model N T theta sigma design
GEN=strcat('GEN',model); FUN=str2func(GEN); [Z FE]=FUN(N,T,theta,sigma,design);