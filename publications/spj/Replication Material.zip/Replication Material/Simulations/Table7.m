function Table7, format short % effect = survival derivative at 0
disp('                                 -------------- bias -----------------    ---------------- sd ----------------    --------------- se/sd --------------    ---------- se/sd corrected ---------    ---------- confidence --------------    -------- confidence corrected ------')
disp('         N         T         m       mle       spj      inf1      inf2       mle       spj      inf1      inf2       mle       spj      inf1      inf2       mle       spj      inf1      inf2       mle       spj      inf1      inf2       mle       spj      inf1      inf2')

m=0; R=10000;
for T=[4 8 12 16 24], N=100; run(N,T,m,R), end
for T=[50 100 250],   N=T;   run(N,T,m,R), end

function run(N,T,m,R)
Gamma=.5; Sigma=1; mu0_true=sqrt(3)/8/sqrt(2*pi); %mu0_true=0.086373537367834; 
z=zeros(R,1); mu0=z; mu1=z; mu2=z; mu3=z; mu4=z; se0=z; se1=z; se2=z; se3=z; se4=z; sc0=z; sc1=z; sc2=z; sc3=z; sc4=z; w0=z; w1=z; w2=z; w3=z; z=zeros(R,4,4); V0=z; V1=z; V2=z; V3=z; V4=z;
for r=1:R
    FE=randn(1,N);
    [YL,YR,DL,DR]=generate(N,T,Gamma,Sigma,FE); [gamma,sigma,fe]=ML(YL,YR,DL,DR); Fe=mean(YL-Gamma*YR,1); EMU=E_mu(FE,Gamma,Sigma);
    % suffixes indicate estimators: 0=inf0 1=inf1 2=inf2 3=mle 4=spj
    MU0=repmat(EMU,T,1);       mu0(r)=mean(MU0(:)); W0=MU0-mu0_true; w0(r)=mean(W0(:)); V=cov_W(YL,YR,DL,DR,Gamma,Sigma,FE,MU0,m); V0(r,:,:)=V; se0(r)=sqrt(V(1,1)); s=[1 0 0 0]; sc0(r)=sqrt(s*V*s');             
    MU1=MU(YR,Gamma,Sigma,FE); mu1(r)=mean(MU1(:)); W1=MU1-MU0;      w1(r)=mean(W1(:)); V=cov_W(YL,YR,DL,DR,Gamma,Sigma,FE,MU1,m); V1(r,:,:)=V; se1(r)=sqrt(V(1,1)); s=[1 1 0 0]; sc1(r)=sqrt(s*V*s');             
    MU2=MU(YR,Gamma,Sigma,Fe); mu2(r)=mean(MU2(:)); W2=MU2-MU1;      w2(r)=mean(W2(:)); V=cov_W(YL,YR,DL,DR,Gamma,Sigma,Fe,MU2,m); V2(r,:,:)=V; se2(r)=sqrt(V(1,1)); s=[1 1 1 0]; sc2(r)=sqrt(s*V*s');
    MU3=MU(YR,gamma,sigma,fe); mu3(r)=mean(MU3(:)); W3=MU3-MU2;      w3(r)=mean(W3(:)); V=cov_W(YL,YR,DL,DR,gamma,sigma,fe,MU3,m); V3(r,:,:)=V; se3(r)=sqrt(V(1,1)); s=[1 1 1 1]; sc3(r)=sqrt(s*V*s');
    %jackknife                
    tt=1:T/2;   YL1=YL(tt,:); YR1=YR(tt,:); DL1=YL1-repmat(mean(YL1),T/2,1); DR1=YR1-repmat(mean(YR1),T/2,1); 
    tt=T/2+1:T; YL2=YL(tt,:); YR2=YR(tt,:); DL2=YL2-repmat(mean(YL2),T/2,1); DR2=YR2-repmat(mean(YR2),T/2,1); 
    [gamma1,sigma1,fe1]=ML(YL1,YR1,DL1,DR1); MU31=MU(YR1,gamma1,sigma1,fe1); 
    [gamma2,sigma2,fe2]=ML(YL2,YR2,DL2,DR2); MU32=MU(YR2,gamma2,sigma2,fe2); 
    V31=cov_W(YL1,YR1,DL1,DR1,gamma1,sigma1,fe1,MU31,m); 
    V32=cov_W(YL2,YR2,DL2,DR2,gamma2,sigma2,fe2,MU32,m); V=(V31/2+V32/2)/2;
    MU4=2*MU3-[MU31;MU32]; mu4(r)=mean(MU4(:)); V(1,1)=var(mean(MU4))/N; V4(r,:,:)=V; se4(r)=sqrt(V(1,1)); s=[1 1 1 1]; sc4(r)=sqrt(s*V*s');
end
mu=[mu3 mu4 mu1 mu2];
se=[se3 se4 se1 se2];
sc=[sc3 sc4 sc1 sc2];
bias=mean(mu-mu0_true); sd=std(mu); sesd=mean(se)./sd; scsd=mean(sc)./sd;
ci=abs(mu-mu0_true)./se<1.96; ci=mean(ci);
cc=abs(mu-mu0_true)./sc<1.96; cc=mean(cc);
disp([N T m bias sd sesd scsd ci cc])

function V=cov_W(YL,YR,DL,DR,gamma,sigma,fe,MU,m)
[T,N]=size(YR); NT=N*T;
[d_mu_alpha,d_mu_gamma,d_mu_sigma]=d_MU(YR,gamma,sigma,fe);
[IF_alpha,IF_gamma,IF_sigma,SIGMA,s_gamma,s_sigma]=IF(YL,YR,DL,DR,gamma,sigma,fe); d_alpha_gamma=-mean(YR); 
C=mean(d_mu_alpha); Cpsi=repmat(C,T,1).*IF_alpha;
a=d_mu_gamma+d_mu_alpha.*repmat(d_alpha_gamma,T,1); b=d_mu_sigma; 
a=mean(mean(a)); b=mean(mean(b)); D=[a b]/SIGMA; Ds=D(1)*s_gamma+D(2)*s_sigma;
aa=var(mean(MU))/N;
bb=mean(kernel(MU,m))/NT;
cc=mean(mean(Cpsi.^2))/NT; bc=mean(cokernel(MU,Cpsi,m))/NT; 
dd=D*SIGMA*D'/NT;          bd=mean(cokernel(MU,Ds  ,m))/NT; cd=mean(mean(Cpsi.*Ds))/NT; 
V=[aa 0  0  0 ; 0  bb bc bd; 0  bc cc cd; 0  bd cd dd];

function mu=MU(YR,gamma,sigma,fe)
[T,~]=size(YR); Q=(repmat(fe,T,1)+gamma*YR)/sigma; mu=(gamma/sigma)*normpdf(Q);

function [d_mu_alpha,d_mu_gamma,d_mu_sigma]=d_MU(YR,gamma,sigma,fe)
[T,~]=size(YR); Q=(repmat(fe,T,1)+gamma*YR)/sigma; mu=(gamma/sigma)*normpdf(Q);
d_mu_alpha=-Q.*mu/sigma;
d_mu_gamma=mu.*(1-(gamma/sigma)*Q.*YR)/gamma;
d_mu_sigma=mu.*(Q.*Q-1)/sigma;

function [IF_alpha,IF_gamma,IF_sigma,SIGMA,s_gamma,s_sigma]=IF(YL,YR,DL,DR,gamma,sigma,fe) % influence functions, scores
[T,~]=size(YR); R=(DL-gamma*DR)/sigma;
IF_alpha=YL-repmat(fe,T,1)-gamma*YR; 
s_gamma=R.*DR/sigma;
s_sigma=(-1+R.*R)/sigma;
SIGMA=[mean(mean(DR.*DR)) 0; 0 3*mean(mean(R.*R))-1]/sigma^2; SIGMA=SIGMA*(T-1)/T; iSIGMA=inv(SIGMA);
IF_gamma=iSIGMA(1,1)*s_gamma+iSIGMA(1,2)*s_sigma;
IF_sigma=iSIGMA(2,1)*s_gamma+iSIGMA(2,2)*s_sigma;

function [gamma,sigma,fe]=ML(YL,YR,DL,DR)
[T,N]=size(YR); xy=DR(:)'*DL(:); xx=DR(:)'*DR(:); gamma=xy/xx; fe=mean(YL-gamma*YR,1);
res=DL-gamma*DR; ssr=res(:)'*res(:); sigma=sqrt(ssr/N/T);

function mu=E_mu(FE,gamma,sigma) % finite-N expectation for given FE
mu=gamma*sqrt(1-gamma^2)/sigma/sqrt(2*pi)*exp(-1/2/sigma^2*(1+gamma)/(1-gamma)*(FE.*FE));

function V=kernel(Z,m)
T=size(Z,1); Z=Z-repmat(mean(Z,1),T,1); V=mean(Z.*Z,1);
for j=1:m, w=1-j/(m+1); Vj=(w/T)*sum(Z(j+1:T,:).*Z(1:T-j,:),1); V=V+2*Vj; end

function C=cokernel(A,B,m) % one-sided
T=size(A,1); A=A-repmat(mean(A,1),T,1); B=B-repmat(mean(B,1),T,1); C=mean(A.*B,1);
for j=1:m, w=1-j/(m+1); Cj=(w/T)*sum(A(j+1:T,:).*B(1:T-j,:),1); C=C+Cj; end

function [YL,YR,DL,DR]=generate(N,T,Gamma,Sigma,FE) %for given FE
Y=zeros(T+1,N); Y(1,:)= FE/(1-Gamma)+(Sigma/sqrt(1-Gamma^2))*randn(1,N);
for t=2:T, Y(t,:)=FE+Gamma*Y(t-1,:)+Sigma.*randn(1,N); end;
YL=Y(2:end  ,:); DL=YL-repmat(mean(YL),T,1); 
YR=Y(1:end-1,:); DR=YR-repmat(mean(YR),T,1); 