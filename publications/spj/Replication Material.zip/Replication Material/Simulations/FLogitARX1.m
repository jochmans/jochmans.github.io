function [bias]=FLogitARX1(mle,fe,YL,YR,X,m) % m is bandwidth parameter
% computes bias approximation from Fernandez-Val (2009) for Logit ARX1

[T N] = size(YL); I = ones(T,1)*fe'+mle(1)*YR+mle(2)*X;
expI=exp(I); A=1./(1+expI); F=1-A; f=F.*A; E=YL-F;
h=ones(T,N); f=F.*A; g=f.*(1-2*F);

sigma = 1./mean(h.*f); psi = (h.*E).*(ones(T,1)*sigma);

jrho   = mean(mean(h.*f.*YR.*YR)- mean(h.*f.*YR).*mean(h.*f.*YR).*sigma);
jbeta  = mean(mean(h.*f.* X.* X)- mean(h.*f.*X ).*mean(h.*f.* X).*sigma);
jrbeta = mean(mean(h.*f.*YR.* X)- mean(h.*f.*YR).*mean(h.*f.* X).*sigma);

j = [jrho, jrbeta; jrbeta, jbeta];

betabeta = zeros(1,N);
for mm=1:m, for t=mm+1:T, betabeta = betabeta+(h(t,:).*f(t,:).*psi(t-mm,:))/((T-mm))   ; end; end; 
beta = -mean(h.*g).*sigma.^2/2-betabeta.*sigma;
bbrho    = zeros(1,N); bbbeta=bbrho;
for mm=1:m, for t=mm+1:T, bbrho    = bbrho +(h(t,:).*f(t,:).*YR(t,:).*psi(t-mm,:))/((T-mm)); end; end; 
for mm=1:m, for t=mm+1:T, bbbeta   = bbbeta+(h(t,:).*f(t,:).* X(t,:).*psi(t-mm,:))/((T-mm)); end; end; 
brho  = mean(-mean(h.*f.*YR).*beta-mean(h.*g.*YR).*sigma/2-bbrho );
bbeta = mean(-mean(h.*f.* X).*beta-mean(h.*g.* X).*sigma/2-bbbeta);

b= [brho;bbeta];

bias = 1/T*(inv(j)*b);