function [logl grad Hess mle]=FELoglLogitARX1(fe,mle,YL,YR,X)
% likelihood function, gradient and Hessian for fixed effects
[T,N]=size(YL); 
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X;  
expR=exp(R); A=1./(1+expR); F=1-A; f=F.*A; logA=log(A); logF=log(F); E=YL-F;

logl= sum(sum(YL.*logF+(1-YL).*logA));
grad= sum(E)';
Hess=-sum(f)';