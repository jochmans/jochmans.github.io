function bias=DLoglLogitARX1(mle,fe,YL,YR,X,m) % m is bandwidth parameter
% computes bias approximation from Hahn-Kuersteiner (2004)
[T,N]=size(YL);
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X;
expR=exp(R); A=1./(1+expR); F=1-A; f=F.*A; df=f.*(A-F); E=YL-F; 
YRf=YR.*f; Xf=X.*f; YRdf=YR.*df; Xdf=X.*df;

DFERHO     =-ones(T,1)*(sum(YRf)./sum(f));
DFEBETA    =-ones(T,1)*(sum(Xf) ./sum(f));
DFERHORHO  = ones(T,1)*((sum(df.*(YR+DFERHO)).*sum(YRf)-sum(YRdf.*(YR+DFERHO)).*sum(f))./((sum(f)).^2));
DFEBETABETA= ones(T,1)*((sum(df.*(X+DFEBETA)).*sum(Xf) -sum(Xdf.* (X+DFEBETA)).*sum(f))./((sum(f)).^2));
DFERHOBETA = ones(T,1)*((sum(df.*(X+DFEBETA)).*sum(YRf)-sum(YRdf.*(X+DFEBETA)).*sum(f))./((sum(f)).^2));
% compute likelihood-based quantities 
Ur    =  E.*(YR+DFERHO); Ub    =  E.*(X+DFEBETA); V    =  E;
Urfe  =- f.*(YR+DFERHO); Ubfe  =- f.*(X+DFEBETA); Vfe  =- f;
Urfefe=-df.*(YR+DFERHO); Ubfefe=-df.*(X+DFEBETA); Vfefe=-df;
Urr   =  E.*DFERHORHO-f.*(YR+DFERHO).^2;
Ubb   =  E.*DFEBETABETA-f.*(X+DFEBETA).^2;
Urb   =  E.*DFERHOBETA-f.*(YR+DFERHO).*(X+DFEBETA);
% compute spectra and cross-spectra
M=(-m:1:m); GVV=zeros(length(M),N); GVUr=GVV; GVUb=GVV;
for j=1:length(M)
    l=max(1,M(j)+1); u=min(T,T+M(j));
    gVV =V(l:u,:).*V(l-M(j):u-M(j),:);    GVV(j,:) =mean(gVV);
    gVUr=V(l:u,:).*Urfe(l-M(j):u-M(j),:); GVUr(j,:)=mean(gVUr);
    gVUb=V(l:u,:).*Ubfe(l-M(j):u-M(j),:); GVUb(j,:)=mean(gVUb);
end
fVV=sum(GVV); fVUr=sum(GVUr); fVUb=sum(GVUb);
% form bias estimate
NUM=[mean(fVUr./mean(Vfe)-(mean(Urfefe).*fVV)./(2*(mean(Vfe)).^2));
     mean(fVUb./mean(Vfe)-(mean(Ubfefe).*fVV)./(2*(mean(Vfe)).^2))];
DEN=[mean(mean(Urr)),mean(mean(Urb));mean(mean(Urb)),mean(mean(Ubb))];
bias=1/T*(inv(DEN)*NUM);