function [hk hkfe flag]=HK(Z,indicator,mle,fe,m) % m is bandwidth parameter
% performs analytical bias correction as in Hahn-Kuersteiner (2004)
global model
DLogl=strcat('DLogl',model); FUN=str2func(DLogl); % call DLogl for 'model'
hk=mle-FUN(mle,fe',Z{:},m); flag=0;

FELogl=strcat('FELogl',model); FUN=str2func(FELogl); % call FELogl for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; sfe=fe(indicator); %clean data
[hk_fe]=NewtonRaphsonMax(FUN,sfe',hk,Z{:});
hkfe=fe; hkfe(indicator==1)=hk_fe;