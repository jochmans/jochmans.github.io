function [logl grho gfe Hrho Hfe Hferho]=LoglProbitAR1(mle,fe,YL,YR)
% computes likelihood (logl), partitioned score (g) and partitioned hessian (H)
[T N]=size(YL);
R=ones(T,1)*fe'+mle*YR; 
F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B;  % B=f/(F(1-F)) C=df/(F(1-F))
E=YL-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB; YRH=YR.*H;

logl=sum(sum(YL.*logF+(1-YL).*logA)); 
grho=sum(sum(YR.*EB));  gfe=sum(EB)';
Hrho=sum(sum(YR.*YRH)); Hfe=sum(H)'; Hferho=sum(YRH)';