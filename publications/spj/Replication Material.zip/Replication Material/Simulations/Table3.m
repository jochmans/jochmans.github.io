function Table3, format compact, format short, global model N T theta sigma whichEST R B alpha bandHK bandAH bandFV design
rng(round(1000*clock*[0 0 0 3600 60 1]')), model = 'ProbitARX1';
design=3; B=39; alpha=.05; sigma=1; bandHK=1; bandAH=1; bandFV=1;
whichEST=[1 1 0 0 1 1 1 0 0 1 1]; % estimators: MLE SPJ1-3 HK FV SPJL1-3 AH CA
N=500; beta=.5; 
R=10000;

rho=.5; T=6;   theta=[rho beta]; tic, RUNSPJ;
rho=.5; T=8;   theta=[rho beta]; tic, RUNSPJ;
rho=.5; T=12;  theta=[rho beta]; tic, RUNSPJ;
rho=.5; T=18;  theta=[rho beta]; tic, RUNSPJ;

rho=1; T=6;   theta=[rho beta]; tic, RUNSPJ;
rho=1; T=8;   theta=[rho beta]; tic, RUNSPJ;
rho=1; T=12;  theta=[rho beta]; tic, RUNSPJ;
rho=1; T=18;  theta=[rho beta]; tic, RUNSPJ;

rho=1.5; T=6;   theta=[rho beta]; tic, RUNSPJ;
rho=1.5; T=8;   theta=[rho beta]; tic, RUNSPJ;
rho=1.5; T=12;  theta=[rho beta]; tic, RUNSPJ;
rho=1.5; T=18;  theta=[rho beta]; tic, RUNSPJ;


function RUNSPJ, global model N T theta sigma whichEST R B alpha bandHK bandAH bandFV design
EX=zeros(R,7); Est=zeros(R,2,7); Ava=zeros(R,2,7); STARTMLE=zeros(2,22); STARTFE =zeros(38,N);  r=1; rr=1; rho=theta(1); beta=theta(2); 
while r<=R, if r==100*floor(r/100), disp([r,toc]), end
    [Z,~]=GENERATE; [flag,est,~,avar]=ESTIMATE(Z,STARTMLE,STARTFE);
    if flag~=0, rr=rr+1; continue, else Est(r,:,:)=est; Ava(r,:,:)=avar; end
    r=r+1; rr=rr+1;       
end, rr=rr-1; crit=chi2inv(1-alpha,1); 
disp('                        --------------------------- bias ---------------------------------    --------------------------- rmse ---------------------------------    --------------------------- se/sd --------------------------------    --------------------------- coverage -----------------------------   ')
disp('      T    gamma/delta    mle      spj        hk        fv       spjl        ah       ca        mle      spj        hk        fv       spjl        ah       ca        mle      spj        hk        fv       spjl        ah       ca        mle      spj        hk        fv       spjl        ah       ca     ')

D=squeeze(Est(:,1,:)-theta(1)); v=squeeze(Ava(:,1,:)); bias1=mean(D); sd1=std(D); se1=mean(sqrt(v/N/T)); rmse1=sqrt(sd1.^2+bias1.^2); z=N*T*(D.*D./v); coverage1=mean(z<crit); disp([T rho  bias1 rmse1 se1./sd1 coverage1])
D=squeeze(Est(:,2,:)-theta(2)); v=squeeze(Ava(:,2,:)); bias2=mean(D); sd2=std(D); se2=mean(sqrt(v/N/T)); rmse2=sqrt(sd2.^2+bias2.^2); z=N*T*(D.*D./v); coverage2=mean(z<crit); disp([T beta bias2 rmse2 se2./sd2 coverage2])
FILE=strcat('Table3_ProbitARX1','.xls'); fid=fopen(FILE,'a+');
fprintf(fid,'%g\t',[R rr N T rho bias1 NaN se1./sd1 NaN rmse1 NaN coverage1 NaN NaN NaN bias2 NaN se2./sd2 NaN rmse2 NaN coverage2]);
fprintf(fid,'\n'); fclose(fid);

function [flag,est,ex,avar]=ESTIMATE(Z,STARTMLE,STARTFE), global model N T bandHK bandAH bandFV whichSPJ whichSPJL
est=zeros(2,7); ex=zeros(1,11); avar=zeros(4,7); whichSPJ =[1 0 0]; whichSPJL=[1 0 0]; K=numel(Z);
[ind,flag]=UNIQUENESS(Z,'INITIAL'); if flag~=0, disp('mle: non-existence'), est=0; ex=0; avar=0; return;  end;
[mle,    fe,ex(1)      ]=ML   (Z,ind,STARTMLE(:,1)    ,STARTFE(1,:)   ,'MLE') ; 
[spj,     ~,ex(2:4),~,~]=SPJ  (Z,ind,STARTMLE(:,2:17) ,STARTFE(2:17,:),mle,fe); spj=spj(:,1);   flagspj =ex(2); if flagspj ==1, disp('spj:  non-existence  '), ex(2)=0; end %spj = mle;  
[hk,   hkfe,ex(5)      ]=HK   (Z,ind,mle              ,fe             ,bandHK); 
[fv,   fvfe,ex(6)      ]=FV   (Z,ind,mle              ,fe             ,bandFV);
[spjl,    ~,ex(7:9),~,~]=SPJL (Z,ind,STARTMLE(:,18:20),STARTFE(18:36,:)      ); spjl=spjl(:,1); flagspjl=ex(7); if flagspjl==1, disp('spjl: non-convergence'), ex(7)=0; end %spjl = mle;  
[ah,   ahfe,ex(10)     ]=AH   (Z,ind,STARTMLE(:,21)   ,STARTFE(37,:)  ,bandAH); 
[ca,   cafe,ex(11)     ]=CARRO(Z,ind,0*STARTMLE(:,22) ,0*STARTFE(38,:)       );
est=[mle spj hk fv spjl ah ca]; ex=ex([1 2 5 6 7 10 11]);
if sum(sum(isnan(est)))>0, flag=2; disp('some of {hk fv ah ca}: nonexistence'), return, end
if sum(sum(ex))>0,         flag=2; disp('some of {hk fv ah ca}: nonexistence'), return, end
% asymptotic variances
for k=1:K, z{k}=Z{k}(:,ind); end; 
[~,~,h]=FUNC(mle,fe  (ind)',z{:}); v=-inv(h); avar(:,1)=v(:);
[~,~,h]=FUNC(hk ,hkfe(ind)',z{:}); v=-inv(h); avar(:,3)=v(:);
[~,~,h]=FUNC(fv ,fvfe(ind)',z{:}); v=-inv(h); avar(:,4)=v(:);    
[~,~,h]=FUNC(ah ,ahfe(ind)',z{:}); v=-inv(h); avar(:,6)=v(:);
[~,~,h]=FUNC(ca ,cafe(ind)',z{:}); v=-inv(h); avar(:,7)=v(:);  
if any(isnan(avar(:))), flag=1; disp('some avar of {mle hk fv ah ca} is NaN'), return, end
[S,~]=SPLITPANEL(2,T,1);   
if (flagspj+flagspjl)>0, avar(:,2)=avar(:,1); avar(:,5)=avar(:,1);
else
    for k=1:K, Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [ind1,~]=UNIQUENESS(Z1,'INITIAL');
        [mle1,fe1,flag1]=ML(Z1,ind1,mle,zeros(1,N),'MLE'); 
    for k=1:K, Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [ind2,~]=UNIQUENESS(Z2,'INITIAL');
        [mle2,fe2,flag2]=ML(Z2,ind2,mle,zeros(1,N),'MLE');
    for k=1:K, z1{k}=Z1{k}(:,ind1); end; [~,~,h]=FUNC(mle1,fe1(ind1)',z1{:}); v_mle1=-inv(h);   
    for k=1:K, z2{k}=Z2{k}(:,ind2); end; [~,~,h]=FUNC(mle2,fe2(ind2)',z2{:}); v_mle2=-inv(h);  
    v=(v_mle1+v_mle2)/2; avar(:,2)=v(:); avar(:,5)=v(:);   
    if any(isnan(avar(:))), flag=1; disp('avar of spj/spjl is NaN'), return, end
end
avar=avar([1 4],:); % keep diagonal only

function [logl,grad,Hess]=FUNC(mle,fe,YL,YR,X), global N % normalised concentrated likelihood, gradient, Hessian
% = CONLoglProbitARX1,but without maximization; uses only informative units
[T,~]=size(YL);
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X; F=normcdf(R); A=normcdf(-R); logF=log(F); logA=log(A); 
logFA=logF+logA; logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B; D=(R.*R-1).*B;
E=YL-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 
DFERHO     =-ones(T,1)*(sum(YR.*H)./sum(H));
DFEBETA    =-ones(T,1)*(sum(X.*H) ./sum(H));
DFERHORHO  = ones(T,1)*((sum(J.*(YR+DFERHO)).*sum(YR.*H)-sum(YR.*J.*(YR+DFERHO)).*sum(H))./((sum(H)).^2));
DFEBETABETA= ones(T,1)*((sum(J.*(YR+DFEBETA)).*sum(YR.*H)-sum(YR.*J.*(YR+DFEBETA)).*sum(H))./((sum(H)).^2));
DFERHOBETA = ones(T,1)*((sum(J.*(X+DFEBETA)).*sum(YR.*H)-sum(YR.*J.*(X+DFEBETA)).*sum(H))./((sum(H)).^2));
logl=sum(sum(YL.*logF+(1-YL).*logA))/N/T;
grad=[sum(sum(EB.*(YR+DFERHO)));sum(sum(EB.*(X+DFEBETA)))]./(N*T);
Hess=[sum(sum(H.*(YR+DFERHO).^2+EB.*DFERHORHO))           , sum(sum(H.*(YR+DFERHO).*(X+DFEBETA)+EB.*DFERHOBETA));
      sum(sum(H.*(YR+DFERHO).*(X+DFEBETA)+EB.*DFERHOBETA)), sum(sum(H.*(X+DFEBETA).^2+EB.*DFEBETABETA))        ]./(N*T);   