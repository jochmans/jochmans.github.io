function [mle fe flag]=ML(Z,indicator1,mle,fe,parent)
% compute mle for 'model' with data Z
global model
Logl=strcat('Logl',model); FUN=str2func(Logl); % call Logl for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator1); end; fe_ind1=fe(indicator1); % clean data, step 1
switch lower(parent)
    case {'mle'}; 
         flag=0;
         [mle fe_ind1 logl flag iter]=NewtonPartitionedMax(FUN,mle,fe_ind1',Z{:}); % estimate
         fe(indicator1)=fe_ind1'; % fill in estimated fixed effects
         if flag==1 warning('MLE did not converge');                          end
    case {'spj1','spj2','spj3'}; 
         [indicator2 flag]=UNIQUENESS(Z,parent);  % clean data, step 2
         if flag==0 for k=1:K Z{k}=Z{k}(:,indicator2); end; 
                    fe_ind2=fe_ind1(indicator2);  
                    [mle fe_ind2 logl flag iter]=NewtonPartitionedMax(FUN,mle,fe_ind2',Z{:}); % estimate
                    fe_ind1(indicator2)=fe_ind2'; fe(indicator1)=fe_ind1; % fill in estimated fixed effects
         end
         if flag==1 
             warning('Subpanel MLE for %s\t did not converge',parent); 
         end
         %dbstop if warning;
end 