function [logl grad Hess fe GRAD_i]=CONLoglProbitAR1(mle,fe,YL,YR)
% computes normalised concentrated likelihood, gradient, Hessian
[fe felogl flag it mle]=NewtonRaphsonMax(@FELoglProbitAR1,fe,mle,YL,YR);
%if flag==1 warning('FE did not converge to a solution'); end
[T N]=size(YL);
R=ones(T,1)*fe'+mle*YR; F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B; D=(R.*R-1).*B;
E=YL-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 

DFERHO   =-ones(T,1)*(sum(YR.*H)./sum(H));
DFERHORHO= ones(T,1)*((sum(J.*(YR+DFERHO)).*sum(YR.*H)-sum(YR.*J.*(YR+DFERHO)).*sum(H))./((sum(H)).^2));

logl=mean(mean(YL.*logF+(1-YL).*logA));
grad=mean(mean(EB.*(YR+DFERHO)));
Hess=mean(mean(H.*(YR+DFERHO).^2+EB.*DFERHORHO));

GRAD_i=cell(1,N); 
s_ik = mean(EB.*(YR+DFERHO)); 
for i=1:N, GRAD_i{i} = [s_ik(i)]; end

function [logl grad Hess mle]=FELoglProbitAR1(fe,mle,YL,YR)
% likelihood function, gradient and Hessian for fixed effects
[T,N]=size(YL); 
R=ones(T,1)*fe'+mle*YR; F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B;
E=YL-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB;

logl=sum(sum(YL.*logF+(1-YL).*logA)); 
grad=sum(EB)';
Hess=sum(H)';