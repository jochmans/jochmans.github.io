function Table5, format compact, format short, global model N T rho alpha R
rng(round(1000*clock*[0 0 0 3600 60 1]')), model = 'ProbitAR1';   %non-stationary regressor X \approx age: Hahn-Newey 2004
disp('                          --------- bias -----------    --------- se/sd ----------    ------- coverage ---------    --- validity ---')
disp('      N         T         mle       spj      spjl       mle       spj      spjl       mle       spj      spjl                     ')

R=10000; alpha=.05; 

N= 100; rho= 1; for T=[6 8 12 18], Go; end

function Go, global model N T rho alpha R
r=1; Est=zeros(R,3); Ava=Est; Val=zeros(R,2); rr=1; 
while r<=R
      [YL, YR]=generate(N,T,rho); Z=cell(1,2); Z{1}=YL; Z{2}=YR; K=numel(Z);
      [ind,UNIQUE]=UNIQUENESS2(Z,'INITIAL'); if UNIQUE~=0, disp('mle: non-existence'), rr=rr+1; return;  end;
      [mle, fe]                                    = ML          (Z,ind,0  ,zeros(1,N),'MLE');
      [spj, spjfe,mle1,mle2,fe1,fe2,Z1,Z2,flagspj] = estimatespj (Z,ind,mle,fe);           if flagspj==1,  disp('spj:  non-existence '), spj = mle;  end
      [spjl,spjlfe,flagspjl,SFE]                   = estimatespjl(Z,ind,mle,[fe;fe1;fe2]); if flagspjl==1, disp('spjl: no convergence'), spjl = mle; end
      FELogl=strcat('CONLogl',model); FUN=str2func(FELogl); 
      for k=1:K, z{k}=Z{k}(:,ind); end; f=fe(ind); [~,~,h]=FUNC(mle,f',z{:}); v_mle=-1/h;   
      [S,W]=SPLITPANEL(2,T,1);   
      for k=1:K, Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [~,s1,~]=FUN(mle,fe',Z1{:}); [~,~,h]=FUN(mle1,fe1',Z1{:}); v_mle1 = -1/h;
      for k=1:K, Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [~,s2,~]=FUN(mle,fe',Z2{:}); [~,~,h]=FUN(mle2,fe2',Z2{:}); v_mle2 = -1/h;
      if flagspj==1, v_mle1=v_mle; v_mle2=v_mle;
      else
          for k=1:K, Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [~,s1,~]=FUN(mle,fe',Z1{:}); [ind1,~]=UNIQUENESS2(Z1,'INITIAL');
          for k=1:K, Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [~,s2,~]=FUN(mle,fe',Z2{:}); [ind2,~]=UNIQUENESS2(Z2,'INITIAL');
          for k=1:K, z1{k}=Z1{k}(:,ind1); end; f1=fe1(ind1); [~,~,h]=FUNC(mle1,f1',z1{:}); v_mle1=-1/h;   
          for k=1:K, z2{k}=Z2{k}(:,ind2); end; f2=fe2(ind2); [~,~,h]=FUNC(mle2,f2',z2{:}); v_mle2=-1/h;
      end
      v_spj=(v_mle1+v_mle2)/2; v_spjl=v_spj;
      Est(r,:) =[  mle   spj   spjl];
      Ava(r,:) =[v_mle v_spj v_spjl];
      Val(r,:) =[mle1-mle2 s1-s2];
      r=r+1; rr=rr+1;   
end,  rr=rr-1; crit=chi2inv(1-alpha,1); 
if any(isnan(Est(:))), disp('some est is NaN'), end
if any(isnan(Ava(:))), disp('some avar is NaN'), end
if any(isnan(Val(:))), disp('some validity stat is NaN'), end    
Dev=Est-rho; bias=mean(Dev); sd=std(Dev); se=mean(sqrt(Ava/N/T)); rmse=sqrt(sd.^2+bias.^2);
                            z=N*T  *(Dev.*Dev./Ava); z=z<crit; coverage=mean(z);
ava=[Ava(:,2) 1./Ava(:,3)]; z=N*T/4*(Val.*Val./ava); z=z<crit; validity=mean(z);     
disp([N T bias se./sd coverage validity])
FILE=strcat('Table5B_Probit_nonstat_HN04','.xls'); fid=fopen(FILE,'a+');
fprintf(fid,'%g\t',[R N T rho bias se./sd sd rmse coverage validity]);
fprintf(fid,'\n'); fclose(fid);

function [logl,grad,Hess]=FUNC(mle,fe,YL,YR), global N % normalised concentrated likelihood, gradient, Hessian
% = CONLoglProbitAR1, but without maximization; uses only informative units
[T,~]=size(YL);
R=ones(T,1)*fe'+mle*YR; F=normcdf(R); A=normcdf(-R); logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B; D=(R.*R-1).*B;
E=YL-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 
DFERHO   =-ones(T,1)*(sum(YR.*H)./sum(H));
DFERHORHO= ones(T,1)*((sum(J.*(YR+DFERHO)).*sum(YR.*H)-sum(YR.*J.*(YR+DFERHO)).*sum(H))./((sum(H)).^2));
logl=sum(sum(YL.*logF+(1-YL).*logA))/N/T;
grad=sum(sum(EB.*(YR+DFERHO)))/N/T;
Hess=sum(sum(H.*(YR+DFERHO).^2+EB.*DFERHORHO))/N/T;

function [spj spjfe mle1 mle2 fe1 fe2 Z1 Z2 flag]=estimatespj(Z,indicator,mle,fe), global model
% computes spj1 from data Z with splits and weights from SPLITPANEL
[T N]=size(Z{1}); [S W]=SPLITPANEL(3,T,1);   SPlength=S(:,2)-S(:,1)+1; 
for k=1:numel(Z) Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [mle1 fe1 flag1]=ML(Z1,indicator,0,zeros(1,N),'SPJ1');
for k=1:numel(Z) Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [mle2 fe2 flag2]=ML(Z2,indicator,0,zeros(1,N),'SPJ1'); 
mle_bar=[mle1 mle2]*SPlength/sum(SPlength); spj  =(1+W)*mle-W*mle_bar;
fe_bar =[fe1' fe2']*SPlength/sum(SPlength); spjfe=(1+W)*fe -W*fe_bar';
SMLE=[mle1 mle2]; SFE=[fe1;fe2]; flag=[flag1 flag2]; % flag solution
if sum(flag)==0 flag=0; end
if sum(flag)~=0 flag=1; end

function [spjl spjlfe flag SFE]=estimatespjl(Z,indicator,spjl,SFE), global model
% computes spjl1 from data Z with splits and weights from SPLITPANEL
[T N]=size(Z{1});  [S W]=SPLITPANEL(2,T,1); K=numel(Z); % split panel
for k=1:K        Z{k} =Z{k}(:,indicator)    ; end; fe0=SFE(1,indicator);  % clean data
for k=1:numel(Z) Z1{k}=Z{k}(S(1,1):S(1,2),:); end; [indicator1 sflag(1)]=UNIQUENESS2(Z1,'SPJL1');   
for k=1:numel(Z) Z2{k}=Z{k}(S(2,1):S(2,2),:); end; [indicator2 sflag(2)]=UNIQUENESS2(Z2,'SPJL1');
if  any(sflag~=0) flag=1;          return   ; end
for k=1:K        Z1{k}=Z1{k}(:,indicator1)  ; end; fe1=SFE(2,indicator); fe1=fe1(indicator1);
for k=1:K        Z2{k}=Z2{k}(:,indicator2)  ; end; fe2=SFE(3,indicator); fe2=fe2(indicator2);
FE=[fe0';fe1';fe2']'; L=[length(fe0),length(fe1),length(fe2)]; C =cumsum(L); 
[spjl logl flag iter FE]=NewtonRaphsonMax(@SPJL1Logl,spjl,FE',Z,Z1,Z2,S,W,C,L);
if flag==1 warning('SPJL1 did not converge'); end
SFE(1,indicator)=FE(1:C(1))';
temp=zeros(1,length(fe0)); temp(indicator1)=FE(C(1)+1:C(2))'; SFE(2,indicator)=temp;
temp=zeros(1,length(fe0)); temp(indicator2)=FE(C(2)+1:C(3))'; SFE(3,indicator)=temp;
FELogl=strcat('FELogl',model); FUN=str2func(FELogl);
[fe_temp felogl flag it sspjl]=NewtonRaphsonMax(FUN,SFE(1,indicator)',spjl,Z{:});
spjlfe=zeros(1,N); spjlfe(indicator==1)=fe_temp;

function [logl grad Hess FE]=SPJL1Logl(spjl,FE,Z,Z1,Z2,S,W,C,L), global model
Logl=strcat('CONLogl',model); FUN=str2func(Logl); SPlength=S(:,2)-S(:,1)+1; 
[logl0 grad0 Hess0 FE(1:C(1))     ]=FUN(spjl,FE((1:C(1)))   ,Z{:} );
[logl1 grad1 Hess1 FE(C(1)+1:C(2))]=FUN(spjl,FE(C(1)+1:C(2)),Z1{:});
[logl2 grad2 Hess2 FE(C(2)+1:C(3))]=FUN(spjl,FE(C(2)+1:C(3)),Z2{:});
logl_bar=(L(2)/L(1)*SPlength(1)*logl1+L(3)/L(1)*SPlength(2)*logl2)/sum(SPlength);
grad_bar=(L(2)/L(1)*SPlength(1)*grad1+L(3)/L(1)*SPlength(2)*grad2)/sum(SPlength);
Hess_bar=(L(2)/L(1)*SPlength(1)*Hess1+L(3)/L(1)*SPlength(2)*Hess2)/sum(SPlength);
logl=(1+W)*logl0-W*logl_bar;
grad=(1+W)*grad0-W*grad_bar;
Hess=(1+W)*Hess0-W*Hess_bar;

function [YL,YR]=generate(N,T,rho) % (design) non-stationary regressor
X=zeros(T+1,N); Y=zeros(T+1,N); FE=randn(1,N); 
X(1,:) = -.5 + 1  *rand(1,N)              ;
Y(1,:) =  FE + rho*X(1,:)   +randn(1,N)>=0;
for t=2:T+1, 
    X(t,:) = (t-1)/10+.5*X(t-1,:)+(-.5 + 1  *rand(1,N) );
    Y(t,:) = FE+rho*X(t,:)+randn(1,N)>=0;
end
YL=Y(2:end,:); YR=X(2:end,:);

function [indicator flag]=UNIQUENESS2(Z,parent) %, global model
switch lower(parent)
    case {'mle'}
        indicator=ones(1,size(Z{1},2)); flag=0;
    case {'initial','spj1','spj2','spj3','spjl1','spjl2','spjl3'}
         [indicator flag]=SELECT2(Z);  
end

function [indicator flag]=SELECT2(Z) % AR1 case
YL=Z{1}; YR = Z{2};
indicator=mean(YL)>0 & mean(YL)<1;  % informative units
YL=YL(:,indicator); YR=YR(:,indicator);
[T N]=size(YR); 
% A=sum(YL.*YR)==sum(YR);             B=sum((1-YL).*YR)==sum(YR); B=-B; 
% C=sum(YL.*(1-YR))==sum(1-YR); C=-C; D=sum((1-YL).*(1-YR))==sum(1-YR); 
% infinities=A+B+(C+D).*((A+B)==0);
if N==0 flag=2; return; %disp('MLE is indeterminate due to collinearity');
%elseif abs(mean(infinities))==1 flag=3; return; %disp('MLE is +/- infinity');
else flag=0;
end

function [mle fe flag]=ML(Z,indicator1,mle,fe,parent)
% compute mle for 'model' with data Z
global model
Logl=strcat('Logl',model); FUN=str2func(Logl); % call Logl for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator1); end; fe_ind1=fe(indicator1); % clean data, step 1
switch lower(parent)
    case {'mle'}; 
         flag=0;
         [mle fe_ind1 logl flag iter]=NewtonPartitionedMax(FUN,mle,fe_ind1',Z{:}); % estimate
         fe(indicator1)=fe_ind1'; % fill in estimated fixed effects
         if flag==1 warning('MLE did not converge');                          end
    case {'spj1','spj2','spj3'}; 
         [indicator2 flag]=UNIQUENESS2(Z,parent);  % clean data, step 2
         if flag==0 for k=1:K Z{k}=Z{k}(:,indicator2); end; 
                    fe_ind2=fe_ind1(indicator2);  
                    [mle fe_ind2 logl flag iter]=NewtonPartitionedMax(FUN,mle,fe_ind2',Z{:}); % estimate
                    fe_ind1(indicator2)=fe_ind2'; fe(indicator1)=fe_ind1; % fill in estimated fixed effects
         end
         if flag==1 
             warning('Subpanel MLE for %s\t did not converge',parent); 
         end
         %dbstop if warning;
end 