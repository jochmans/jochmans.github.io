function Table10, format compact, format short, global N T gamma rhoU R 
disp('                        ------------------------ bias --------------------------    ------------------------ sd ----------------------------    -------------------------- se/sd ----------------------      ------------------- coverage -------------------------')
disp('                           mle       mle       mle       spj       spj       spj       mle       mle       mle       spj       spj       spj       mle       mle       mle       spj       spj       spj       mle       mle       mle       spj       spj       spj')
disp('      N         T        gamma     delta     sigma     gamma     delta     sigma     gamma     delta     sigma     gamma     delta     sigma     gamma     delta     sigma     gamma     delta     sigma     gamma     delta     sigma     gamma     delta     sigma')
gamma = .5; rhoU = .5;

R = 1000;

N = 500; T =6 ; run;
N = 500; T =8 ; run;
N = 500; T =12; run;
N = 500; T =18; run;
N =  20; T =N; run;
N =  50; T =N; run;
N = 100; T =N; run;
              

function run, global N T gamma rhoU R
for r=1:R
    [theta_mle std_theta_mle tst_theta_mle theta_spj std_theta_spj tst_theta_spj vartheta_mle std_vartheta_mle tst_vartheta_mle vartheta_spj std_vartheta_spj tst_vartheta_spj] = simultaneous(N,T,gamma,rhoU);
    PE_THETA(r,:) = [    theta_mle'     theta_spj']; PE_VARTHETA(r,:) = [    vartheta_mle'     vartheta_spj'];
    SE_THETA(r,:) = [std_theta_mle' std_theta_spj']; SE_VARTHETA(r,:) = [std_vartheta_mle' std_vartheta_spj'];
    IN_THETA(r,:) = [tst_theta_mle' tst_theta_spj']; IN_VARTHETA(r,:) = [tst_vartheta_mle' tst_vartheta_spj'];
end
BIAS1 = mean(PE_THETA)-[.5 .5 .5 .5]; BIAS2 = mean(PE_VARTHETA)-[gamma 1-gamma rhoU gamma 1-gamma rhoU];
 STD1 =  std(PE_THETA)              ;  STD2 =  std(PE_VARTHETA)                                        ;
 SED1 = mean(SE_THETA)./STD1        ;  SED2 = mean(SE_VARTHETA)./STD2                                  ;
 INF1 = mean(IN_THETA)              ;  INF2 = mean(IN_VARTHETA)                                        ;
disp([N T BIAS2 STD2 SED2 INF2])
FILE=strcat('Table10','.xls'); fid=fopen(FILE,'a+');
fprintf(fid,'%g\t',[N T gamma 1-gamma rhoU]);
fprintf(fid,'%g\t',BIAS1); fprintf(fid,'%g\t',STD1);  fprintf(fid,'%g\t',SED1); fprintf(fid,'%g\t',INF1);
fprintf(fid,'%g\t',BIAS2); fprintf(fid,'%g\t',STD2);  fprintf(fid,'%g\t',SED2); fprintf(fid,'%g\t',INF2);
fprintf(fid, '\n'       ); fclose(fid);

function [theta_mle std_theta_mle tst_theta_mle theta_spj std_theta_spj tst_theta_spj vartheta_mle std_vartheta_mle tst_vartheta_mle vartheta_spj std_vartheta_spj tst_vartheta_spj] = simultaneous(N,T,gamma,rhoU)
burn = 250;
beta1 = [.5;.5]; beta2 = [gamma;1-gamma];
rhoF = 0; 
% data generation
F = mvnrnd([0;0],[1,rhoF;rhoF,1],N); F = zeros(N,2);  FE1 = F(:,1)'; FE2 = F(:,2)';   FE3 = -sqrt(2/3)*FE1;
Y = zeros(T+burn+1,N);
X = zeros(T+burn+1,N); 
Z = zeros(T+burn+1,N);
sigma = 1;
for t=2:burn+T+1,
    error  = mvnrnd([0;0],[1,rhoU*sigma;rhoU*sigma,sigma^2],N);
    Z(t,:) = FE3+     .5 * Z(t-1,:)+                 +randn(1,N)     ;
    X(t,:) = FE1+beta1(1)*X(t-1,:) + beta1(2)*Z(t,:) + error(:,1)'>=0; X(t,:) = X(t,:)>0; % first stage: dynamic probit model
    Y(t,:) = FE2+beta2(1)*Y(t-1,:) + beta2(2)*X(t,:) + error(:,2)'   ;                    % scond stage: dynamic linear model with endogeneity on x
end
YL = Y; YL(1:burn+1,:) = []; YR = Y; YR(1:burn,:) = []; YR(end,:) = [];
XL = X; XL(1:burn+1,:) = []; XR = X; XR(1:burn,:) = []; XR(end,:) = [];
ZL = Z; ZL(1:burn+1,:) = []; ZR = Z; ZR(1:burn,:) = []; ZR(end,:) = [];
% limited-information ML estimation
% first stage point estimation
[movers   existenceflag]=SELECTX(XL,XR,ZL); 
[theta_mle alpha_interm]=NewtonPartitionedMax(@LoglProbit,[0;0],zeros(1,sum(movers))',XL(:,movers),XR(:,movers),ZL(:,movers)); alpha_mle = zeros(1,N); 
alpha_mle(movers) = alpha_interm; alpha_mle(mean(XL)==1) = 3; alpha_mle(mean(XL)==0) = -3;
U = ones(T,1)*alpha_mle+theta_mle(1)*XR+theta_mle(2)*ZL; RV = (XL-normcdf(U)).*normpdf(U)./(normcdf(U).*(1-normcdf(U))); RV(:,movers==0) = 0; %RV = XL.*(-normpdf(U)./normcdf(U))-(1-XL).*(-normpdf(-U)./normcdf(-U)); RV(:,movers==0) = 0;
% first-stage influence function
F=normcdf(U); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA; logf=-0.5*(log(2*pi)+U.*U); B=exp(logf-logFA); C=-U.*B; D=(U.*U-1).*B; E=XL-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 
DFEVARRHO = -ones(T,1)*(sum(XR.*H)./sum(H)); c_score_varrho = EB.*(XR+DFEVARRHO);
DFEVARPII = -ones(T,1)*(sum(ZL.*H)./sum(H)); c_score_varpii = EB.*(ZL+DFEVARPII);
DFEVARRHOVARRHO = ones(T,1)*((sum(J.*(XR+DFEVARRHO)).*sum(XR.*H)-sum(XR.*J.*(XR+DFEVARRHO)).*sum(H))./((sum(H)).^2)); c_hess_varrhovarrho = H.*(XR+DFEVARRHO).*(XR+DFEVARRHO)+EB.*DFEVARRHOVARRHO; Hess(1,1) = mean(mean(c_hess_varrhovarrho));
DFEVARPIIVARPII = ones(T,1)*((sum(J.*(ZL+DFEVARPII)).*sum(ZL.*H)-sum(ZL.*J.*(ZL+DFEVARPII)).*sum(H))./((sum(H)).^2)); c_hess_varpiivarpii = H.*(ZL+DFEVARPII).*(ZL+DFEVARPII)+EB.*DFEVARPIIVARPII; Hess(2,2) = mean(mean(c_hess_varpiivarpii));
DFEVARRHOVARPII = ones(T,1)*((sum(J.*(ZL+DFEVARPII)).*sum(XR.*H)-sum(XR.*J.*(ZL+DFEVARPII)).*sum(H))./((sum(H)).^2)); c_hess_varrhovarpii = H.*(XR+DFEVARRHO).*(ZL+DFEVARPII)+EB.*DFEVARRHOVARPII; Hess(1,2) = mean(mean(c_hess_varrhovarpii)); Hess(2,1) = Hess(1,2); Info = -inv(Hess);
fe_noise_varrho = ones(T,1)*(mean(XR.*H)./mean(-H)).*EB;
fe_noise_varpii = ones(T,1)*(mean(ZL.*H)./mean(-H)).*EB;
psi_varrho = Info(1,1)*c_score_varrho+Info(1,2)*c_score_varpii;
psi_varpii = Info(2,1)*c_score_varrho+Info(2,2)*c_score_varpii;
bandwidth = 0; asyvar = 0; vv0 = zeros(2,2);    
for ii=1:N, psi = [psi_varrho(:,ii),psi_varpii(:,ii)];  vv0   =  cov(psi);
    for j=1:bandwidth, 
        lag = psi(1:T-j,:); lag = lag-repmat(mean(lag),[T-j 1]);
        cur = psi(1+j:T,:); cur = cur-repmat(mean(cur),[T-j 1]); C = zeros(2,2);
        for k=1:2, for kk=1:2, C(k,kk) = mean(cur(:,k).*lag(:,kk)); end; end; vv0 = vv0 + 2*(1-j/(bandwidth+1))*C;
     end
     asyvar = asyvar + vv0/N;
end 
std_theta_mle = [sqrt(asyvar(1,1));sqrt(asyvar(2,2))]/sqrt(N*T); dev_theta_mle = theta_mle-beta1; tst_theta_mle = abs(dev_theta_mle./std_theta_mle)<=1.96; clear Hess;
% second stage point estimation
DYL = YL-ones(T,1)*mean(YL); DYR = YR-ones(T,1)*mean(YR); 
DXL = XL-ones(T,1)*mean(XL); DRV = RV-ones(T,1)*mean(RV);
XX =[mean(mean(DYR.*DYR)),mean(mean(DYR.*DXL)),mean(mean(DYR.*DRV)) ;
     mean(mean(DXL.*DYR)),mean(mean(DXL.*DXL)),mean(mean(DXL.*DRV)) ;
     mean(mean(DRV.*DYR)),mean(mean(DRV.*DXL)),mean(mean(DRV.*DRV))];
XY =[mean(mean(DYR.*DYL));mean(mean(DXL.*DYL));mean(mean(DRV.*DYL))]; 
vartheta_mle = inv(XX)*(XY); DR = DYL-vartheta_mle(1)*DYR-vartheta_mle(2)*DXL-vartheta_mle(3)*DRV;
% second stage influence function
c_score_gamma = DR.*DYR; c_hess_gammagamma = -DYR.*DYR; c_hess_gammadelta = -DYR.*DXL; c_hess_gammazetaa = -DYR.*DRV; Hess(1,1) = mean(mean(c_hess_gammagamma)); Hess(1,2) = mean(mean(c_hess_gammadelta)); Hess(1,3) = mean(mean(c_hess_gammazetaa));
c_score_delta = DR.*DXL; c_hess_deltagamma = -DXL.*DYR; c_hess_deltadelta = -DXL.*DXL; c_hess_deltazetaa = -DXL.*DRV; Hess(2,1) = mean(mean(c_hess_deltagamma)); Hess(2,2) = mean(mean(c_hess_deltadelta)); Hess(2,3) = mean(mean(c_hess_deltazetaa));
c_score_zetaa = DR.*DRV; c_hess_zetaagamma = -DRV.*DYR; c_hess_zetaadelta = -DRV.*DXL; c_hess_zetaazetaa = -DRV.*DRV; Hess(3,1) = mean(mean(c_hess_zetaagamma)); Hess(3,2) = mean(mean(c_hess_zetaadelta)); Hess(3,3) = mean(mean(c_hess_zetaazetaa));
Info = -inv(Hess);
DR_varrho = -vartheta_mle(3)*c_score_varrho;
DR_varpii = -vartheta_mle(3)*c_score_varpii;
c_noise_gammavarrho = DR_varrho.*DYR; c_noise_gammavarpii = DR_varpii.*DYR; Jacob(1,1) = mean(mean(c_noise_gammavarrho)); Jacob(1,2) = mean(mean(c_noise_gammavarpii));
c_noise_deltavarrho = DR_varrho.*DXL; c_noise_deltavarpii = DR_varpii.*DXL; Jacob(2,1) = mean(mean(c_noise_deltavarrho)); Jacob(2,2) = mean(mean(c_noise_deltavarpii));
c_noise_zetaavarrho = DR_varrho.*DRV; c_noise_zetaavarpii = DR_varpii.*DRV; Jacob(3,1) = mean(mean(c_noise_zetaavarrho)); Jacob(3,2) = mean(mean(c_noise_zetaavarpii));
c_total_gamma = c_score_gamma+Jacob(1,1)*psi_varrho+Jacob(1,2)*psi_varpii;
c_total_delta = c_score_delta+Jacob(2,1)*psi_varrho+Jacob(2,2)*psi_varpii;
c_total_zetaa = c_score_zetaa+Jacob(3,1)*psi_varrho+Jacob(3,2)*psi_varpii;
psi_gamma = Info(1,1)*c_total_gamma+Info(1,2)*c_total_delta+Info(1,3)*c_total_zetaa;
psi_delta = Info(2,1)*c_total_gamma+Info(2,2)*c_total_delta+Info(2,3)*c_total_zetaa;
psi_zetaa = Info(3,1)*c_total_gamma+Info(3,2)*c_total_delta+Info(3,3)*c_total_zetaa;
bandwidth = 0; asyvar = 0; vv0 = zeros(3,3);    
for ii=1:N, psi = [psi_gamma(:,ii),psi_delta(:,ii),psi_zetaa(:,ii)];  vv0   =  cov(psi);
    for j=1:bandwidth, 
        lag = psi(1:T-j,:); lag = lag-repmat(mean(lag),[T-j 1]);
        cur = psi(1+j:T,:); cur = cur-repmat(mean(cur),[T-j 1]); C = zeros(3,3);
        for k=1:3, for kk=1:3, C(k,kk) = mean(cur(:,k).*lag(:,kk)); end; end; vv0 = vv0 + 2*(1-j/(bandwidth+1))*C;
     end
     asyvar = asyvar + vv0/N;
end 
std_vartheta_mle = [sqrt(asyvar(1,1));sqrt(asyvar(2,2));sqrt(asyvar(3,3))]/sqrt(N*T); dev_vartheta_mle = vartheta_mle-[beta2;rhoU]; tst_vartheta_mle = abs(dev_vartheta_mle./std_vartheta_mle)<=1.96; clear Hess;
% limited-information SPJ estimation
% first stage point estimation
YL1 = YL(1:T/2,:); YL2 = YL(T/2+1:end,:);
YR1 = YR(1:T/2,:); YR2 = YR(T/2+1:end,:);
XL1 = XL(1:T/2,:); XL2 = XL(T/2+1:end,:);
XR1 = XR(1:T/2,:); XR2 = XR(T/2+1:end,:);
ZL1 = ZL(1:T/2,:); ZL2 = ZL(T/2+1:end,:);
[movers1 existenceflag1]=SELECTX(XL1,XR1,ZL1); 
[movers2 existenceflag2]=SELECTX(XL2,XR2,ZL2); 
[theta_mle1 alpha_interm1]=NewtonPartitionedMax(@LoglProbit,[0;0],zeros(1,sum(movers1))',XL1(:,movers1),XR1(:,movers1),ZL1(:,movers1)); 
alpha_mle1 = zeros(1,N);  alpha_mle1(mean(XL1)==1) = 2; alpha_mle1(mean(XL1)==0) = -2; alpha_mle1(movers1) = alpha_interm1;
U1 = ones(T/2,1)*alpha_mle1+theta_mle1(1)*XR1+theta_mle1(2)*ZL1; RV1 = (XL1-normcdf(U1)).*normpdf(U1)./(normcdf(U1).*(1-normcdf(U1))); RV1(:,movers1==0) = 0;
[theta_mle2 alpha_interm2]=NewtonPartitionedMax(@LoglProbit,[0;0],zeros(1,sum(movers2))',XL2(:,movers2),XR2(:,movers2),ZL2(:,movers2)); 
alpha_mle2 = zeros(1,N);  alpha_mle2(mean(XL2)==1) = 2; alpha_mle2(mean(XL2)==0) = -2; alpha_mle2(movers2) = alpha_interm2;
U2 = ones(T/2,1)*alpha_mle2+theta_mle2(1)*XR2+theta_mle2(2)*ZL2; RV2 = (XL2-normcdf(U2)).*normpdf(U2)./(normcdf(U2).*(1-normcdf(U2))); RV2(:,movers2==0) = 0;
theta_spj = 2*theta_mle-(theta_mle1+theta_mle2)/2;
alpha_spj = alpha_mle; 
U = ones(T,1)*alpha_spj+theta_spj(1)*XR+theta_spj(2)*ZL; RV = (XL-normcdf(U)).*normpdf(U)./(normcdf(U).*(1-normcdf(U))); RV(:,movers==0) = 0; %redefining control function for spj
% first-stage influence function
F =normcdf(U ); A =1-F ; logF =log(F ); logA =log(A ); logFA =logF +logA ; logf =-0.5*(log(2*pi)+U .*U ); B =exp(logf -logFA ); C =-U .*B ; D =(U .* U-1).*B ; E =XL -F ; EB =E .*B ; EC =E .*C ; ED =E .*D ; H =EC -EB .*EB ; J =ED -3*EB .*EC +2*EB .*EB .*EB ; 
F1=normcdf(U1); A1=1-F1; logF1=log(F1); logA1=log(A1); logFA1=logF1+logA1; logf1=-0.5*(log(2*pi)+U1.*U1); B1=exp(logf1-logFA1); C1=-U1.*B1; D1=(U1.*U1-1).*B1; E1=XL1-F1; EB1=E1.*B1; EC1=E1.*C1; ED1=E1.*D1; H1=EC1-EB1.*EB1; J1=ED1-3*EB1.*EC1+2*EB1.*EB1.*EB1; 
F2=normcdf(U2); A2=1-F2; logF2=log(F2); logA2=log(A2); logFA2=logF2+logA2; logf2=-0.5*(log(2*pi)+U2.*U2); B2=exp(logf2-logFA2); C2=-U2.*B2; D2=(U2.*U2-1).*B2; E2=XL2-F2; EB2=E2.*B2; EC2=E2.*C2; ED2=E2.*D2; H2=EC2-EB2.*EB2; J2=ED2-3*EB2.*EC2+2*EB2.*EB2.*EB2; 
DFEVARRHO = -ones(T,1)*(sum(XR.*H)./sum(H)); c_score_varrho = EB.*(XR+DFEVARRHO); DFEVARRHO1 = -ones(T/2,1)*(sum(XR1.*H1)./sum(H1)); c_score_varrho1 = EB1.*(XR1+DFEVARRHO1); DFEVARRHO2 = -ones(T/2,1)*(sum(XR2.*H2)./sum(H2)); c_score_varrho2 = EB2.*(XR2+DFEVARRHO2);
DFEVARPII = -ones(T,1)*(sum(ZL.*H)./sum(H)); c_score_varpii = EB.*(ZL+DFEVARPII); DFEVARPII1 = -ones(T/2,1)*(sum(ZL1.*H1)./sum(H1)); c_score_varpii1 = EB1.*(ZL1+DFEVARPII1); DFEVARPII2 = -ones(T/2,1)*(sum(ZL2.*H2)./sum(H2)); c_score_varpii2 = EB2.*(ZL2+DFEVARPII2);
DFEVARRHOVARRHO = ones(T,1)*((sum(J.*(XR+DFEVARRHO)).*sum(XR.*H)-sum(XR.*J.*(XR+DFEVARRHO)).*sum(H))./((sum(H)).^2)); c_hess_varrhovarrho = H.*(XR+DFEVARRHO).*(XR+DFEVARRHO)+EB.*DFEVARRHOVARRHO; Hess(1,1) = mean(mean(c_hess_varrhovarrho));
DFEVARPIIVARPII = ones(T,1)*((sum(J.*(ZL+DFEVARPII)).*sum(ZL.*H)-sum(ZL.*J.*(ZL+DFEVARPII)).*sum(H))./((sum(H)).^2)); c_hess_varpiivarpii = H.*(ZL+DFEVARPII).*(ZL+DFEVARPII)+EB.*DFEVARPIIVARPII; Hess(2,2) = mean(mean(c_hess_varpiivarpii));
DFEVARRHOVARPII = ones(T,1)*((sum(J.*(ZL+DFEVARPII)).*sum(XR.*H)-sum(XR.*J.*(ZL+DFEVARPII)).*sum(H))./((sum(H)).^2)); c_hess_varrhovarpii = H.*(XR+DFEVARRHO).*(ZL+DFEVARPII)+EB.*DFEVARRHOVARPII; Hess(1,2) = mean(mean(c_hess_varrhovarpii)); Hess(2,1) = Hess(1,2); Info = -inv(Hess);
DFEVARRHOVARRHO1 = ones(T/2,1)*((sum(J1.*(XR1+DFEVARRHO1)).*sum(XR1.*H1)-sum(XR1.*J1.*(XR1+DFEVARRHO1)).*sum(H1))./((sum(H1)).^2)); c_hess_varrhovarrho1 = H1.*(XR1+DFEVARRHO1).*(XR1+DFEVARRHO1)+EB1.*DFEVARRHOVARRHO1; Hess1(1,1) = mean(mean(c_hess_varrhovarrho1));
DFEVARPIIVARPII1 = ones(T/2,1)*((sum(J1.*(ZL1+DFEVARPII1)).*sum(ZL1.*H1)-sum(ZL1.*J1.*(ZL1+DFEVARPII1)).*sum(H1))./((sum(H1)).^2)); c_hess_varpiivarpii1 = H1.*(ZL1+DFEVARPII1).*(ZL1+DFEVARPII1)+EB1.*DFEVARPIIVARPII1; Hess1(2,2) = mean(mean(c_hess_varpiivarpii1));
DFEVARRHOVARPII1 = ones(T/2,1)*((sum(J1.*(ZL1+DFEVARPII1)).*sum(XR1.*H1)-sum(XR1.*J1.*(ZL1+DFEVARPII1)).*sum(H1))./((sum(H1)).^2)); c_hess_varrhovarpii1 = H1.*(XR1+DFEVARRHO1).*(ZL1+DFEVARPII1)+EB1.*DFEVARRHOVARPII1; Hess1(1,2) = mean(mean(c_hess_varrhovarpii1)); Hess1(2,1) = Hess1(1,2); Info1 = -inv(Hess1);
DFEVARRHOVARRHO2 = ones(T/2,1)*((sum(J2.*(XR2+DFEVARRHO2)).*sum(XR2.*H2)-sum(XR2.*J2.*(XR2+DFEVARRHO2)).*sum(H2))./((sum(H2)).^2)); c_hess_varrhovarrho2 = H2.*(XR2+DFEVARRHO2).*(XR2+DFEVARRHO2)+EB2.*DFEVARRHOVARRHO2; Hess2(1,1) = mean(mean(c_hess_varrhovarrho2));
DFEVARPIIVARPII2 = ones(T/2,1)*((sum(J2.*(ZL2+DFEVARPII2)).*sum(ZL2.*H2)-sum(ZL2.*J2.*(ZL2+DFEVARPII2)).*sum(H2))./((sum(H2)).^2)); c_hess_varpiivarpii2 = H2.*(ZL2+DFEVARPII2).*(ZL2+DFEVARPII2)+EB2.*DFEVARPIIVARPII2; Hess2(2,2) = mean(mean(c_hess_varpiivarpii2));
DFEVARRHOVARPII2 = ones(T/2,1)*((sum(J2.*(ZL2+DFEVARPII2)).*sum(XR2.*H2)-sum(XR2.*J2.*(ZL2+DFEVARPII2)).*sum(H2))./((sum(H2)).^2)); c_hess_varrhovarpii2 = H2.*(XR2+DFEVARRHO2).*(ZL2+DFEVARPII2)+EB2.*DFEVARRHOVARPII2; Hess2(1,2) = mean(mean(c_hess_varrhovarpii2)); Hess2(2,1) = Hess2(1,2); Info2 = -inv(Hess2);
psi_varrho = Info(1,1)*c_score_varrho+Info(1,2)*c_score_varpii; psi_varrho1 = Info1(1,1)*c_score_varrho1+Info1(1,2)*c_score_varpii1; psi_varrho2 = Info2(1,1)*c_score_varrho2+Info2(1,2)*c_score_varpii2;  
psi_varpii = Info(2,1)*c_score_varrho+Info(2,2)*c_score_varpii; psi_varpii1 = Info1(2,1)*c_score_varrho1+Info1(2,2)*c_score_varpii1; psi_varpii2 = Info2(2,1)*c_score_varrho2+Info2(2,2)*c_score_varpii2; 
bandwidth = 0; asyvar = 0; vv0 = zeros(2,2);    
for ii=1:N, psi = [psi_varrho(:,ii),psi_varpii(:,ii)];  vv0   =  cov(psi);
    for j=1:bandwidth, 
        lag = psi(1:T-j,:); lag = lag-repmat(mean(lag),[T-j 1]);
        cur = psi(1+j:T,:); cur = cur-repmat(mean(cur),[T-j 1]); C = zeros(2,2);
        for k=1:2, for kk=1:2, C(k,kk) = mean(cur(:,k).*lag(:,kk)); end; end; vv0 = vv0 + 2*(1-j/(bandwidth+1))*C;
     end
     asyvar = asyvar + vv0/N;
end 
std_theta_spj = [sqrt(asyvar(1,1));sqrt(asyvar(2,2))]/sqrt(N*T); dev_theta_spj = theta_spj-beta1; tst_theta_spj = abs(dev_theta_spj./std_theta_spj)<=1.96; clear Hess;
% second stage point estimation
DYL1 = YL1-ones(T/2,1)*mean(YL1); DYR1 = YR1-ones(T/2,1)*mean(YR1); 
DXL1 = XL1-ones(T/2,1)*mean(XL1); DRV1 = RV1-ones(T/2,1)*mean(RV1); 
XX1 =[mean(mean(DYR1.*DYR1)),mean(mean(DYR1.*DXL1)),mean(mean(DYR1.*DRV1)) ;
      mean(mean(DXL1.*DYR1)),mean(mean(DXL1.*DXL1)),mean(mean(DXL1.*DRV1)) ;
      mean(mean(DRV1.*DYR1)),mean(mean(DRV1.*DXL1)),mean(mean(DRV1.*DRV1))];
XY1 =[mean(mean(DYR1.*DYL1));mean(mean(DXL1.*DYL1));mean(mean(DRV1.*DYL1))]; 
vartheta_mle1 = inv(XX1)*(XY1);  DR1 = DYL1-vartheta_mle1(1)*DYR1-vartheta_mle1(2)*DXL1-vartheta_mle1(3)*DRV1;
DYL2 = YL2-ones(T/2,1)*mean(YL2); DYR2 = YR2-ones(T/2,1)*mean(YR2); 
DXL2 = XL2-ones(T/2,1)*mean(XL2); DRV2 = RV2-ones(T/2,1)*mean(RV2);
XX2 =[mean(mean(DYR2.*DYR2)),mean(mean(DYR2.*DXL2)),mean(mean(DYR2.*DRV2)) ;
      mean(mean(DXL2.*DYR2)),mean(mean(DXL2.*DXL2)),mean(mean(DXL2.*DRV2)) ;
      mean(mean(DRV2.*DYR2)),mean(mean(DRV2.*DXL2)),mean(mean(DRV2.*DRV2))];
XY2 =[mean(mean(DYR2.*DYL2));mean(mean(DXL2.*DYL2));mean(mean(DRV2.*DYL2))]; 
vartheta_mle2 = inv(XX2)*(XY2); DR2 = DYL2-vartheta_mle2(1)*DYR2-vartheta_mle2(2)*DXL2-vartheta_mle2(3)*DRV2;
vartheta_spj = 2*vartheta_mle-(vartheta_mle1+vartheta_mle2)/2; 
DRV = RV-ones(T,1)*mean(RV); DR = DYL-vartheta_spj(1)*DYR-vartheta_spj(2)*DXL-vartheta_spj(3)*DRV;
% second stage influence function
c_score_gamma = DR.*DYR; c_hess_gammagamma = -DYR.*DYR; c_hess_gammadelta = -DYR.*DXL; c_hess_gammazetaa = -DYR.*DRV; Hess(1,1) = mean(mean(c_hess_gammagamma)); Hess(1,2) = mean(mean(c_hess_gammadelta)); Hess(1,3) = mean(mean(c_hess_gammazetaa));
c_score_delta = DR.*DXL; c_hess_deltagamma = -DXL.*DYR; c_hess_deltadelta = -DXL.*DXL; c_hess_deltazetaa = -DXL.*DRV; Hess(2,1) = mean(mean(c_hess_deltagamma)); Hess(2,2) = mean(mean(c_hess_deltadelta)); Hess(2,3) = mean(mean(c_hess_deltazetaa));
c_score_zetaa = DR.*DRV; c_hess_zetaagamma = -DRV.*DYR; c_hess_zetaadelta = -DRV.*DXL; c_hess_zetaazetaa = -DRV.*DRV; Hess(3,1) = mean(mean(c_hess_zetaagamma)); Hess(3,2) = mean(mean(c_hess_zetaadelta)); Hess(3,3) = mean(mean(c_hess_zetaazetaa));
Info = -inv(Hess);
DR_varrho = -vartheta_spj(3)*c_score_varrho;
DR_varpii = -vartheta_spj(3)*c_score_varpii;
c_noise_gammavarrho = DR_varrho.*DYR; c_noise_gammavarpii = DR_varpii.*DYR; Jacob(1,1) = mean(mean(c_noise_gammavarrho)); Jacob(1,2) = mean(mean(c_noise_gammavarpii));
c_noise_deltavarrho = DR_varrho.*DXL; c_noise_deltavarpii = DR_varpii.*DXL; Jacob(2,1) = mean(mean(c_noise_deltavarrho)); Jacob(2,2) = mean(mean(c_noise_deltavarpii));
c_noise_zetaavarrho = DR_varrho.*DRV; c_noise_zetaavarpii = DR_varpii.*DRV; Jacob(3,1) = mean(mean(c_noise_zetaavarrho)); Jacob(3,2) = mean(mean(c_noise_zetaavarpii));
c_total_gamma = c_score_gamma+Jacob(1,1)*psi_varrho+Jacob(1,2)*psi_varpii;
c_total_delta = c_score_delta+Jacob(2,1)*psi_varrho+Jacob(2,2)*psi_varpii;
c_total_zetaa = c_score_zetaa+Jacob(3,1)*psi_varrho+Jacob(3,2)*psi_varpii;
psi_gamma = Info(1,1)*c_total_gamma+Info(1,2)*c_total_delta+Info(1,3)*c_total_zetaa;
psi_delta = Info(2,1)*c_total_gamma+Info(2,2)*c_total_delta+Info(2,3)*c_total_zetaa;
psi_zetaa = Info(3,1)*c_total_gamma+Info(3,2)*c_total_delta+Info(3,3)*c_total_zetaa;
bandwidth = 0; asyvar = 0; vv0 = zeros(3,3);    
for ii=1:N, psi = [psi_gamma(:,ii),psi_delta(:,ii),psi_zetaa(:,ii)];  vv0   =  cov(psi);
    for j=1:bandwidth, 
        lag = psi(1:T-j,:); lag = lag-repmat(mean(lag),[T-j 1]);
        cur = psi(1+j:T,:); cur = cur-repmat(mean(cur),[T-j 1]); C = zeros(3,3);
        for k=1:3, for kk=1:3, C(k,kk) = mean(cur(:,k).*lag(:,kk)); end; end; vv0 = vv0 + 2*(1-j/(bandwidth+1))*C;
     end
     asyvar = asyvar + vv0/N;
end 
std_vartheta_spj = [sqrt(asyvar(1,1));sqrt(asyvar(2,2));sqrt(asyvar(3,3))]/sqrt(N*T); dev_vartheta_spj = vartheta_spj-[beta2;rhoU]; tst_vartheta_spj = abs(dev_vartheta_spj./std_vartheta_spj)<=1.96; clear Hess;
% new:
% second stage influence functions for half panels
c_score_gamma1 = DR1.*DYR1; c_hess_gammagamma1 = -DYR1.*DYR1; c_hess_gammadelta1 = -DYR1.*DXL1; c_hess_gammazetaa1 = -DYR1.*DRV1; Hess1(1,1) = mean(mean(c_hess_gammagamma1)); Hess1(1,2) = mean(mean(c_hess_gammadelta1)); Hess1(1,3) = mean(mean(c_hess_gammazetaa1));
c_score_delta1 = DR1.*DXL1; c_hess_deltagamma1 = -DXL1.*DYR1; c_hess_deltadelta1 = -DXL1.*DXL1; c_hess_deltazetaa1 = -DXL1.*DRV1; Hess1(2,1) = mean(mean(c_hess_deltagamma1)); Hess1(2,2) = mean(mean(c_hess_deltadelta1)); Hess1(2,3) = mean(mean(c_hess_deltazetaa1));
c_score_zetaa1 = DR1.*DRV1; c_hess_zetaagamma1 = -DRV1.*DYR1; c_hess_zetaadelta1 = -DRV1.*DXL1; c_hess_zetaazetaa1 = -DRV1.*DRV1; Hess1(3,1) = mean(mean(c_hess_zetaagamma1)); Hess1(3,2) = mean(mean(c_hess_zetaadelta1)); Hess1(3,3) = mean(mean(c_hess_zetaazetaa1));
Info1 = -inv(Hess1);
DR_varrho1 = -vartheta_mle1(3)*c_score_varrho1;
DR_varpii1 = -vartheta_mle1(3)*c_score_varpii1;
c_noise_gammavarrho1 = DR_varrho1.*DYR1; c_noise_gammavarpii1 = DR_varpii1.*DYR1; Jacob1(1,1) = mean(mean(c_noise_gammavarrho1)); Jacob1(1,2) = mean(mean(c_noise_gammavarpii1));
c_noise_deltavarrho1 = DR_varrho1.*DXL1; c_noise_deltavarpii1 = DR_varpii1.*DXL1; Jacob1(2,1) = mean(mean(c_noise_deltavarrho1)); Jacob1(2,2) = mean(mean(c_noise_deltavarpii1));
c_noise_zetaavarrho1 = DR_varrho1.*DRV1; c_noise_zetaavarpii1 = DR_varpii1.*DRV1; Jacob1(3,1) = mean(mean(c_noise_zetaavarrho1)); Jacob1(3,2) = mean(mean(c_noise_zetaavarpii1));
c_total_gamma1 = c_score_gamma1+Jacob1(1,1)*psi_varrho1+Jacob1(1,2)*psi_varpii1;
c_total_delta1 = c_score_delta1+Jacob1(2,1)*psi_varrho1+Jacob1(2,2)*psi_varpii1;
c_total_zetaa1 = c_score_zetaa1+Jacob1(3,1)*psi_varrho1+Jacob1(3,2)*psi_varpii1;
psi_gamma1 = Info1(1,1)*c_total_gamma1+Info1(1,2)*c_total_delta1+Info1(1,3)*c_total_zetaa1;
psi_delta1 = Info1(2,1)*c_total_gamma1+Info1(2,2)*c_total_delta1+Info1(2,3)*c_total_zetaa1;
psi_zetaa1 = Info1(3,1)*c_total_gamma1+Info1(3,2)*c_total_delta1+Info1(3,3)*c_total_zetaa1;
bandwidth = 0; asyvar = 0; vv0 = zeros(3,3);    
for ii=1:N, psi = [psi_gamma1(:,ii),psi_delta1(:,ii),psi_zetaa1(:,ii)];  vv0   =  cov(psi);
    for j=1:bandwidth, 
        lag = psi(1:T-j,:); lag = lag-repmat(mean(lag),[T-j 1]);
        cur = psi(1+j:T,:); cur = cur-repmat(mean(cur),[T-j 1]); C = zeros(3,3);
        for k=1:3, for kk=1:3, C(k,kk) = mean(cur(:,k).*lag(:,kk)); end; end; vv0 = vv0 + 2*(1-j/(bandwidth+1))*C;
     end
     asyvar = asyvar + vv0/N;
end 
asyvar1 = asyvar;
c_score_gamma2 = DR2.*DYR2; c_hess_gammagamma2 = -DYR2.*DYR2; c_hess_gammadelta2 = -DYR2.*DXL2; c_hess_gammazetaa2 = -DYR2.*DRV2; Hess2(1,1) = mean(mean(c_hess_gammagamma2)); Hess2(1,2) = mean(mean(c_hess_gammadelta2)); Hess2(1,3) = mean(mean(c_hess_gammazetaa2));
c_score_delta2 = DR2.*DXL2; c_hess_deltagamma2 = -DXL2.*DYR2; c_hess_deltadelta2 = -DXL2.*DXL2; c_hess_deltazetaa2 = -DXL2.*DRV2; Hess2(2,1) = mean(mean(c_hess_deltagamma2)); Hess2(2,2) = mean(mean(c_hess_deltadelta2)); Hess2(2,3) = mean(mean(c_hess_deltazetaa2));
c_score_zetaa2 = DR2.*DRV2; c_hess_zetaagamma2 = -DRV2.*DYR2; c_hess_zetaadelta2 = -DRV2.*DXL2; c_hess_zetaazetaa2 = -DRV2.*DRV2; Hess2(3,1) = mean(mean(c_hess_zetaagamma2)); Hess2(3,2) = mean(mean(c_hess_zetaadelta2)); Hess2(3,3) = mean(mean(c_hess_zetaazetaa2));
Info2 = -inv(Hess2);
DR_varrho2 = -vartheta_mle2(3)*c_score_varrho2;
DR_varpii2 = -vartheta_mle2(3)*c_score_varpii2;
c_noise_gammavarrho2 = DR_varrho2.*DYR2; c_noise_gammavarpii2 = DR_varpii2.*DYR2; Jacob2(1,1) = mean(mean(c_noise_gammavarrho2)); Jacob2(1,2) = mean(mean(c_noise_gammavarpii2));
c_noise_deltavarrho2 = DR_varrho2.*DXL2; c_noise_deltavarpii2 = DR_varpii2.*DXL2; Jacob2(2,1) = mean(mean(c_noise_deltavarrho2)); Jacob2(2,2) = mean(mean(c_noise_deltavarpii2));
c_noise_zetaavarrho2 = DR_varrho2.*DRV2; c_noise_zetaavarpii2 = DR_varpii2.*DRV2; Jacob2(3,1) = mean(mean(c_noise_zetaavarrho2)); Jacob2(3,2) = mean(mean(c_noise_zetaavarpii2));
c_total_gamma2 = c_score_gamma2+Jacob2(1,1)*psi_varrho2+Jacob2(1,2)*psi_varpii2;
c_total_delta2 = c_score_delta2+Jacob2(2,1)*psi_varrho2+Jacob2(2,2)*psi_varpii2;
c_total_zetaa2 = c_score_zetaa2+Jacob2(3,1)*psi_varrho2+Jacob2(3,2)*psi_varpii2;
psi_gamma2 = Info2(1,1)*c_total_gamma2+Info2(1,2)*c_total_delta2+Info2(1,3)*c_total_zetaa2;
psi_delta2 = Info2(2,1)*c_total_gamma2+Info2(2,2)*c_total_delta2+Info2(2,3)*c_total_zetaa2;
psi_zetaa2 = Info2(3,1)*c_total_gamma2+Info2(3,2)*c_total_delta2+Info2(3,3)*c_total_zetaa2;
bandwidth = 0; asyvar = 0; vv0 = zeros(3,3);    
for ii=1:N, psi = [psi_gamma2(:,ii),psi_delta2(:,ii),psi_zetaa2(:,ii)];  vv0   =  cov(psi);
    for j=1:bandwidth, 
        lag = psi(1:T-j,:); lag = lag-repmat(mean(lag),[T-j 1]);
        cur = psi(1+j:T,:); cur = cur-repmat(mean(cur),[T-j 1]); C = zeros(3,3);
        for k=1:3, for kk=1:3, C(k,kk) = mean(cur(:,k).*lag(:,kk)); end; end; vv0 = vv0 + 2*(1-j/(bandwidth+1))*C;
     end
     asyvar = asyvar + vv0/N;
end 
asyvar2 = asyvar;
asyvar = (asyvar1+asyvar2)/2;
std_vartheta_spj = [sqrt(asyvar(1,1));sqrt(asyvar(2,2));sqrt(asyvar(3,3))]/sqrt(N*T); dev_vartheta_spj = vartheta_spj-[beta2;rhoU]; tst_vartheta_spj = abs(dev_vartheta_spj./std_vartheta_spj)<=1.96; clear Hess;

function [logl gtheta gfe Htheta Hfe Hfetheta]=LoglProbit(mle,fe,YL,YR,XL)
% computes likelihood (logl), partitioned score (g) and partitioned hessian (H)
i = ones(size(YL,1),1)*fe'+mle(1)*YR+mle(2)*XL; F = normcdf(i); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA; 
logf=-0.5*(log(2*pi)+i.*i); B=exp(logf-logFA); C=-i.*B; E=YL-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB;
logl=sum(sum(YL.*logF+(1-YL).*logA)); gfe=sum(EB)'; Hfe=sum(H)';
gtheta  = [sum(sum(YR.*EB));sum(sum(XL.*EB))];
Hfetheta= [    sum(   YR.* H)',    sum(   XL.* H)']; 
Htheta  = [sum(sum(YR.*YR.*H)),sum(sum(YR.*XL.*H)) ;sum(sum(YR.*XL.*H)),sum(sum(XL.*XL.*H))];
       
function [x1,x2,f,condition,it]=NewtonPartitionedMax(FUN,x1,x2,varargin)
% maximises FUN, starting at (x1,x2) by Newton-Raphson method
% while exploiting sparsity of hessian 
tol=1e-4; maxit=150; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x1);
[f g1 g2 H1 H2 H21]=feval(FUN,x1,x2,varargin{:});
while it<=maxit && condition==1 && improvement==1;
    J21=H21./(H2*ones(1,k)); A=inv(H1-H21'*J21);
    d1=-A*(g1-J21'*g2); d2=-g2./H2-J21*d1;
    step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff gg1 gg2 HH1 HH2 HH21]=feval(FUN,x1+step*d1,x2+step*d2,varargin{:});
        if (ff-f)/abs(f)>=-1e-6
            improvement=1; condition=sqrt(step*step*(d1'*d1+d2'*d2))>tol & (ff-f)>tol;
            x1=x1+step*d1; f=ff; g1=gg1; H1=HH1; H21=HH21;
            x2=x2+step*d2;       g2=gg2; H2=HH2;
        else
            step=step/2;
        end
    end
    it=it+1;
end
it=it-1;

function [indicator flag]=SELECTX(YL,YR,X) % ARX1 case
indicator=mean(YL)>0 & mean(YL)<1;     % informative units
YL=YL(:,indicator); YR=YR(:,indicator); X=X(:,indicator);
[T N]=size(YR);
s=mean(YR)>0 & mean(YR)<1;     % informative units w.r.t. rho
yl=YL(:,s); yr=YR(:,s); [T n]=size(yr);
flag=0;
if     n==0                   flag=2; end; %disp('rho is indeterminate'); end %return;                          
if separability1(yl,yr)   ==1 flag=3; end; %disp('rho = +/- infinity');   end %return;  elseif...
if separability2(YL,YR,X) ==1 flag=4; end; %disp('beta = + infinity');    end  %return;    
if separability2(YL,YR,-X)==1 flag=5; end; %disp('beta = - infinity');    end %return; end

function condition=separability1(yl,yr)
% check (quasi-)separability with beta=0 ; condition=1/0 if yes/no
a=sum(yl.*(1-yr))==sum(1-yr);     % 1 if sequence is semi-alternating: 0 -> 1
b=sum((1-yl).*(1-yr))==sum(1-yr); % 1 if sequence is monotonically decreasing
c=sum(yl.*yr)==sum(yr);           % 1 if sequence is monotonically increasing
d=sum((1-yl).*yr)==sum(yr);       % 1 if sequence is semi-alternating: 1 -> 0
infinities=sign(-a+b+c-d);
if abs(mean(infinities))==1 condition=1; else condition=0; end

function condition=separability2(YL,YR,X)
% check separability with beta=1 ; condition=1/0 if yes/no
condition=0; [T N]=size(YR); tt=1:T;
max00=zeros(N,1); min01=zeros(N,1); E00=zeros(N,1); E01=zeros(N,1);
max10=zeros(N,1); min11=zeros(N,1); E10=zeros(N,1); E11=zeros(N,1);
for i=1:N
    T00=tt(YR(:,i)==0 & YL(:,i)==0);  T01=tt(YR(:,i)==0 & YL(:,i)==1); 
    T10=tt(YR(:,i)==1 & YL(:,i)==0);  T11=tt(YR(:,i)==1 & YL(:,i)==1);
    if size(T00,2)>0 max00(i)=max(X(T00,i)); E00(i)=1; end
    if size(T01,2)>0 min01(i)=min(X(T01,i)); E01(i)=1; end
    if size(T10,2)>0 max10(i)=max(X(T10,i)); E10(i)=1; end
    if size(T11,2)>0 min11(i)=min(X(T11,i)); E11(i)=1; end
    if E01(i)==1 & E00(i)==1 & min01(i)<max00(i);   end  % X01 >= X00 violated return;
    if E11(i)==1 & E10(i)==1 & min11(i)<max10(i);   end  % X11 >= X10 violated return;
end
z=min01-max10; z=z(E01.*E10>0); rhomax=min(z);
z=max00-min11; z=z(E00.*E11>0); rhomin=max(z);
if rhomax<rhomin return; end                             % condition on rho violated 
condition=1;