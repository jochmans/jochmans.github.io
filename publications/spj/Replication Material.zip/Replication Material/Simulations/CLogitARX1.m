function [Ascore] = CLogitARX1(mmle,mfe,YL,YR,X)


[mfe] = NewtonRaphsonMax(@FELoglLogitARX1,mfe',mmle,YL,YR,X); [T N] = size(YL); Y0=YR(1,:); mfe=mfe'; 

PrS = zeros(T,N); PrF = PrS;
PrS(1,:) = logitcdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:)); PrF(1,:) =  1-PrS(1,:) ;
for t=2:T, 
    PrS(t,:) = logitcdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*PrS(t-1,:)+logitcdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).*PrF(t-1,:); 
    PrF(t,:) =  1-PrS(t,:); 
end

dPrS = zeros(T,N); dPrF = dPrS;
dPrS(1,:) = logitpdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:)); dPrF(1,:) = -dPrS(1,:);
for t=2:T, 
    dPrS(t,:) = logitpdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).* PrS(t-1,:)+logitpdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).* PrF(t-1,:)...
              + logitcdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*dPrS(t-1,:)+logitcdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).*dPrF(t-1,:);
    dPrF(t,:) = -dPrS(t,:);      
end

EDfefe = zeros(T,N); EDferho=EDfefe; EDfebeta=EDfefe;
EDfefe(1,:) = -logitpdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:)); EDferho(1,:)  = -Y0    .*logitpdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:));
                                                        EDfebeta(1,:) = -X(1,:).*logitpdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:));
for t=2:T, 
    EDfefe(t,:)   = -         logitpdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*PrS(t-1,:)-logitpdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).*PrF(t-1,:); 
    EDferho(t,:)  = -         logitpdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*PrS(t-1,:);  
    EDfebeta(t,:) = -X(t,:).*(logitpdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*PrS(t-1,:)+logitpdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).*PrF(t-1,:)); 
end
EDfefe = mean(EDfefe); EDferho = mean(EDferho); EDfebeta = mean(EDfebeta); 

dEDfefe=zeros(T,N); dEDferho=dEDfefe; dEDfebeta=dEDfefe;
dEDfefe(1,:) = -logitmdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:)) ; 
dEDferho(1,:) = -Y0.*logitmdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:)); dEDfebeta(1,:) = -X(1,:).*logitmdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:));
for t=2:T, 
    dEDfefe(t,:)   = -logitmdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).* PrS(t-1,:)-logitmdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).* PrF(t-1,:)...
                     -logitpdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*dPrS(t-1,:)-logitpdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).*dPrF(t-1,:); 
    dEDferho(t,:)  = -logitmdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).* PrS(t-1,:)-logitpdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*dPrS(t-1,:); 
    dEDfebeta(t,:) = -X(t,:).*logitmdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).* PrS(t-1,:)-X(t,:).*logitmdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).* PrF(t-1,:)...
                     -X(t,:).*logitpdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*dPrS(t-1,:)-X(t,:).*logitpdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).*dPrF(t-1,:);
end
dEDfefe = mean(dEDfefe); dEDferho = mean(dEDferho); dEDfebeta = mean(dEDfebeta); 

[plogl pscore]=CONLoglLogitARX1(mmle,mfe',YL,YR,X); MFE=ones(T,1)*mfe;
Ebias = [(dEDferho.*EDfefe-EDferho.*dEDfefe)./(EDfefe).^2;(dEDfebeta.*EDfefe-EDfebeta.*dEDfefe)./(EDfefe).^2]; 
BbiasR = (mean(-YR.*logitmdf(MFE+mmle(1)*YR+mmle(2)*X))+mean(-logitmdf(MFE+mmle(1)*YR+mmle(2)*X)).*(-(sum(YR.*logitpdf(MFE+mmle(1).*YR+mmle(2)*X))./sum(logitpdf(MFE+mmle(1)*YR+mmle(2)*X)))))...
      ./(mean(-logitpdf(MFE+mmle(1).*YR+mmle(2)*X)));
BbiasB = (mean(-X.*logitmdf(MFE+mmle(1)*YR+mmle(2)*X))+mean(-logitmdf(MFE+mmle(1)*YR+mmle(2)*X)).*(-(sum(X.*logitpdf(MFE+mmle(1).*YR+mmle(2)*X))./sum(logitpdf(MFE+mmle(1)*YR+mmle(2)*X)))))...
      ./(mean(-logitpdf(MFE+mmle(1).*YR+mmle(2)*X)));
Bbias=[BbiasR;BbiasB];   
Ebias = mean(Ebias,2); Bbias=-.5*mean(Bbias,2);
Ascore = pscore+Bbias/T+Ebias/T;

function [F] = logitcdf(z)
F = 1./(1+exp(-z)); 

function [f] = logitpdf(z)
f = logitcdf(z).*(1-logitcdf(z));

function [df] = logitmdf(z)
df = logitpdf(z).*(1-2*logitcdf(z));