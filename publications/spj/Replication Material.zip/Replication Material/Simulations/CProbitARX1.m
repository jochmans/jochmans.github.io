function [Ascore] = CProbitARX1(mmle,mfe,YL,YR,X)


[mfe] = NewtonRaphsonMax(@FELoglProbitARX1,mfe',mmle,YL,YR,X); [T N] = size(YL); Y0=YR(1,:); mfe=mfe';

PrS = zeros(T,N); PrF = PrS;
PrS(1,:) = normcdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:)); PrF(1,:) =  1-PrS(1,:) ;
for t=2:T, 
    PrS(t,:) = normcdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*PrS(t-1,:)+normcdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).*PrF(t-1,:); 
    PrF(t,:) =  1-PrS(t,:); 
end

dPrS = zeros(T,N); dPrF = dPrS;
dPrS(1,:) = normpdf(mfe+mmle(1)*Y0+mmle(2)*X(1,:)); dPrF(1,:) = -dPrS(1,:);% 1-dPrS(1,:);
for t=2:T, 
    dPrS(t,:) = normpdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).* PrS(t-1,:)+normpdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).* PrF(t-1,:)...
              + normcdf(mfe+mmle(1)* 1+mmle(2)*X(t,:)).*dPrS(t-1,:)+normcdf(mfe+mmle(1)* 0+mmle(2)*X(t,:)).*dPrF(t-1,:);
    dPrF(t,:) = -dPrS(t,:);      
end

EDfefe = zeros(T,N); EDferho = EDfefe; EDfebeta = EDfefe;
EDfefe(1,:)   =          D2(1,Y0,mfe,X(1,:),mmle).*PrS(1,:) + D2(0,Y0,mfe,X(1,:),mmle).*PrF(1,:) ; 
EDferho(1,:)  = Y0    .*(D2(1,Y0,mfe,X(1,:),mmle).*PrS(1,:) + D2(0,Y0,mfe,X(1,:),mmle).*PrF(1,:)); 
EDfebeta(1,:) = X(1,:).*(D2(1,Y0,mfe,X(1,:),mmle).*PrS(1,:) + D2(0,Y0,mfe,X(1,:),mmle).*PrF(1,:)); 
for t=2:T, 
    EDfefe(t,:)  =          (D2(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).*PrS(t-1,:)...
                 +          (D2(1,0,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)) + D2(0,0,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)))).*PrF(t-1,:)   ; 
    EDferho(t,:) =          (D2(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).*PrS(t-1,:)   ;
    EDfebeta(t,:)= X(t,:).*((D2(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).*PrS(t-1,:))...
                 + X(t,:).*((D2(1,0,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)) + D2(0,0,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)))).*PrF(t-1,:))  ;
end
EDfefe = mean(EDfefe); EDferho = mean(EDferho); EDfebeta = mean(EDfebeta); 


dEDfefe=zeros(T,N); dEDferho=dEDfefe; dEDfebeta=dEDfefe;
dEDfefe(1,:)  =                   D3(1,Y0,mfe,X(1,:),mmle).*PrS(1,:) + D3(0,Y0,mfe,X(1,:),mmle).*PrF(1,:)  + D2(1,Y0,mfe,X(1,:),mmle).*dPrS(1,:) + D2(0,Y0,mfe,X(1,:),mmle).*dPrF(1,:); 
dEDferho(1,:) = Y0    .*((D3(1,Y0,mfe,X(1,:),mmle).*PrS(1,:) + D3(0,Y0,mfe,X(1,:),mmle).*PrF(1,:)) + D2(1,Y0,mfe,X(1,:),mmle).*dPrS(1,:) + D2(0,Y0,mfe,X(1,:),mmle).*dPrF(1,:)); 
dEDfebeta(1,:)= X(1,:).*((D3(1,Y0,mfe,X(1,:),mmle).*PrS(1,:) + D3(0,Y0,mfe,X(1,:),mmle).*PrF(1,:)) + D2(1,Y0,mfe,X(1,:),mmle).*dPrS(1,:) + D2(0,Y0,mfe,X(1,:),mmle).*dPrF(1,:));
for t=2:T, 
    dEDfefe(t,:)    = (D3(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D3(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).* PrS(t-1,:)...
                    + (D3(1,0,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)) + D3(0,0,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)))).* PrF(t-1,:)...
                    + (D2(1,1,mfe,X(t,:),mmle).*normpdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(0-normpdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).* PrS(t-1,:)...
                    + (D2(1,0,mfe,X(t,:),mmle).*normpdf(mfe+mmle(1)*0+mmle(2)*X(t,:)) + D2(0,0,mfe,X(t,:),mmle).*(0-normpdf(mfe+mmle(1)*0+mmle(2)*X(t,:)))).* PrF(t-1,:)...
                    + (D2(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).*dPrS(t-1,:)...
                    + (D2(1,0,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)) + D2(0,0,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)))).*dPrF(t-1,:)   ;
    
    dEDferho(t,:)   = (D3(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D3(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).* PrS(t-1,:)...
                    + (D2(1,1,mfe,X(t,:),mmle).*normpdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(0-normpdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).* PrS(t-1,:)...
                    + (D2(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).*dPrS(t-1,:)   ;
    
    dEDfebeta(t,:)  = (D3(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D3(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).* PrS(t-1,:).*X(t,:)...%.*X(t,:)...
                    + (D3(1,0,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)) + D3(0,0,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)))).* PrF(t-1,:).*X(t,:)...%.*X(t,:)...
                    + (D2(1,1,mfe,X(t,:),mmle).*normpdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(0-normpdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).* PrS(t-1,:).*X(t,:)...
                    + (D2(1,0,mfe,X(t,:),mmle).*normpdf(mfe+mmle(1)*0+mmle(2)*X(t,:)) + D2(0,0,mfe,X(t,:),mmle).*(0-normpdf(mfe+mmle(1)*0+mmle(2)*X(t,:)))).* PrF(t-1,:).*X(t,:)...
                    + (D2(1,1,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)) + D2(0,1,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*1+mmle(2)*X(t,:)))).*dPrS(t-1,:).*X(t,:)...
                    + (D2(1,0,mfe,X(t,:),mmle).*normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)) + D2(0,0,mfe,X(t,:),mmle).*(1-normcdf(mfe+mmle(1)*0+mmle(2)*X(t,:)))).*dPrF(t-1,:).*X(t,:)   ;
end
dEDfefe = mean(dEDfefe); dEDferho = mean(dEDferho); dEDfebeta = mean(dEDfebeta); 

[plogl pscore]=CONLoglProbitARX1(mmle,mfe',YL,YR,X); 
Ebias = [(dEDferho.*EDfefe-EDferho.*dEDfefe)./(EDfefe).^2;(dEDfebeta.*EDfefe-EDfebeta.*dEDfefe)./(EDfefe).^2]; 
BbiasR = (mean(YR.*D3(YL,YR,mfe,X,mmle))+mean(D3(YL,YR,mfe,X,mmle)).*(-sum(YR.*D2(YL,YR,mfe,X,mmle))./sum(D2(YL,YR,mfe,X,mmle))))...
      ./(mean(D2(YL,YR,mfe,X,mmle)));
BbiasB = (mean(X.*D3(YL,YR,mfe,X,mmle))+mean(D3(YL,YR,mfe,X,mmle)).*(-sum(X.*D2(YL,YR,mfe,X,mmle))./sum(D2(YL,YR,mfe,X,mmle))))...
      ./(mean(D2(YL,YR,mfe,X,mmle)));


Bbias=[BbiasR;BbiasB]; 
Ebias = mean(Ebias,2); Bbias=-.5*mean(Bbias,2);
Ascore = pscore+Bbias/T+Ebias/T;


function [H] = D2(yl,yr,fe,x,theta)
[T N] = size(yl); R = ones(T,1)*fe+theta(1)*yr+theta(2)*x;
F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B; D=(R.*R-1).*B; 
E=yl-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 

function [J] = D3(yl,yr,fe,x,theta)
[T N] = size(yl); R = ones(T,1)*fe+theta(1)*yr+theta(2)*x;
F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B; D=(R.*R-1).*B; 
E=yl-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 