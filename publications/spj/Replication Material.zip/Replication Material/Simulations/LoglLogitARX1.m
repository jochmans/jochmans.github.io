function [logl gtheta gfe Htheta Hfe Hfetheta]=LoglLogitARX1(mle,fe,YL,YR,X)
% computes likelihood (logl), partitioned score (g) and partitioned hessian (H)
[T N]=size(YL);
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X; 
expR=exp(R); A=1./(1+expR); F=1-A; f=F.*A; logA=log(A); logF=log(F); E=YL-F; 
YRf=YR.*f; Xf=X.*f; 

logl= sum(sum(YL.*logF+(1-YL).*logA));
grho= sum(sum(YR.*E));      gbeta=sum(sum(X.*E));   gfe= sum(E)';    
Hrho=-sum(sum(YR.*YRf));    Hbeta=-sum(sum(X.*Xf)); Hfe=-sum(f)';
Hrhobeta=-sum(sum(YR.*Xf)); Hferho=-sum(YRf)';      Hfebeta=-sum(Xf)'; 
gtheta=[grho;gbeta]; 
Htheta=[Hrho,Hrhobeta;Hrhobeta,Hbeta]; Hfetheta=[Hferho,Hfebeta];