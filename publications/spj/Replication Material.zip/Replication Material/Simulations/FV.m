function [fv fvfe flag]=FV(Z,indicator,mle,fe,m) % m is bandwidth parameter
% performs analytical bias correction as in Fernandez-Val (2009)
global model
FLogl=strcat('F',model); FUN=str2func(FLogl); % call F for 'model'
fv=mle-FUN(mle,fe',Z{:},m); flag=0;

FELogl=strcat('FELogl',model); FUN=str2func(FELogl); % call FELogl for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; sfe=fe(indicator); %clean data
[fv_fe]=NewtonRaphsonMax(FUN,sfe',fv,Z{:});
fvfe=fe; fvfe(indicator==1)=fv_fe;