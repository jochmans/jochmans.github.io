function [Z FE]=GENLogitARX1(N,T,theta,sigma,design)%(design)
% generates data Y,X = (T+1)xN matrices; passed up as cell array Z

%design = 2; % 0 (benchmark) 1 (Carro etc) 2 HK variant of probit 3 (benchmark + correlation)

%% benchmark design
if design==0,
    burn=0;
    FE=sigma*randn(1,N); X=zeros(T+1+burn,N); Y=zeros(T+1+burn,N);
    % AR(1) covariate design
    delta=0; gamma=.5; % intercept and slope coefficient for AR(1) X-process
    X(1,:)=1/(sqrt(1-gamma^2))*randn(1,N);
    % AR(1)-trend covariate design
    %X(1,:)=zeros(1,N);
    % iid covariate design
    %X(1,:)=randn(1,N);                 % iid standardnormal covariate
    %X(1,:)=(.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
    Y(1,:)=zeros(1,N);
    for t=2:T+1+burn
        X(t,:) = delta+gamma*X(t-1,:)+randn(1,N); % AR(1) covariate
        %X(t,:) = .1*(t-1)+gamma*X(t-1,:)+randn(1,N); % AR(1)-trend covariate
        %X(t,:) = randn(1,N); % iid standardnormal covariate
        %X(t,:) = (.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
        uniform=rand(1,N); 
        Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)+(sqrt(3)/pi)*log(uniform./(1-uniform)))>=0;
    end
    Y(1:burn,:)=[]; X(1:burn,:)=[];
    YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
    Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;
end

%% Carro (2007)/ Fernandez-Val (2009) design % theta = (.5, 1)'
if design==1,
    X  = sqrt(pi^2/3)*randn(T+1,N); FE = .25*sum(X(1:4,:));
    Y=zeros(T+1,N); uniform=rand(1,N);
    Y(1,:) = (FE   +theta(2)*X(1,:)>=             log(uniform./(1-uniform))); % without variance normalization
    %Y(1,:) = (FE   +theta(2)*X(1,:)>=(sqrt(3)/pi)*log(uniform./(1-uniform))); % with    variance normalization
    for t=2:T+1
        uniform=rand(1,N);
        Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)>=             log(uniform./(1-uniform))); % without variance normalization 
        %Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)>=(sqrt(3)/pi)*log(uniform./(1-uniform))); % with    variance normalization 
    end
    YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
    Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;  
end

%% HK (2011) probit variant design % theta = (.5, 1)' % autoregressive X
if design==2,
    % AR(1) covariate design
    X = zeros(T+1,N); delta=0; gamma=.5; X(1,:)=sqrt(pi^2/3)*1/(sqrt(1-gamma^2))*randn(1,N);
    for t=2:T+1, X(t,:) = delta+gamma*X(t-1,:)+sqrt(pi^2/3)*randn(1,N); end
    FE = .25*sum(X(1:4,:));
    Y = zeros(T+1,N); uniform=rand(1,N);
    %Y(1,:) = (FE   +theta(2)*X(1,:)>=             log(uniform./(1-uniform))); % without variance normalization
    Y(1,:) = (FE   +theta(2)*X(t,:)>=(sqrt(3)/pi)*log(uniform./(1-uniform))); % with    variance normalization
    for t=2:T+1
        uniform=rand(1,N);
        %Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)>=             log(uniform./(1-uniform))); % without variance normalization 
        Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)>=(sqrt(3)/pi)*log(uniform./(1-uniform))); % with    variance normalization 
    end
    YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
    Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;  
end

%% benchmark design + dependence between alpha and x
if design==3,
    burn=50;
    FE=sigma*randn(1,N); X=zeros(T+1+burn,N); Y=zeros(T+1+burn,N); FE2 = .5*FE;
    % AR(1) covariate design
    delta=FE2; gamma=.5; % intercept and slope coefficient for AR(1) X-process
    X(1,:)=1/(sqrt(1-gamma^2)).*randn(1,N);
    % AR(1)-trend covariate design
    %X(1,:)=zeros(1,N);
    % iid covariate design
    %X(1,:)=randn(1,N);                 % iid standardnormal covariate
    %X(1,:)=(.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
    Y(1,:)=zeros(1,N);
    for t=2:T+1+burn
        X(t,:) = delta+gamma*X(t-1,:)+randn(1,N); % AR(1) covariate
        %X(t,:) = .1*(t-1)+gamma*X(t-1,:)+randn(1,N); % AR(1)-trend covariate
        %X(t,:) = randn(1,N); % iid standardnormal covariate
        %X(t,:) = (.5-(-.5))*rand(1,N)+(-.5); % iid uniform (-0.5, 0.5) covariate
        uniform=rand(1,N); 
        Y(t,:) = (FE   +theta(1)*Y(t-1,:)+theta(2)*X(t,:)+(sqrt(3)/pi)*log(uniform./(1-uniform)))>=0;
    end
    Y(1:burn,:)=[]; X(1:burn,:)=[];
    YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[]; X(1,:)=[];
    Z=cell(1,3);  Z{1}=YL; Z{2}=YR; Z{3}=X;
end
