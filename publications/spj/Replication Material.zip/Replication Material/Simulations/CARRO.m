function [mmle mfe flag] = CARRO(Z,indicator,mmle,fe)
global model

% using different matlab routine; no Jacobian
%CLogl=strcat('C',model); FUN=str2func(CLogl); % call C for 'model'
%CLogl=strcat('C',model,'_Jacobian'); FUN=str2func(CLogl); % call C for 'model'
K=numel(Z); for k=1:K Z{k}=Z{k}(:,indicator); end; sfe=fe(indicator); %clean data
%opt=optimset('Display','off','Jacobian','off','LargeScale','On','TolFun',1e-6,'TolX',1e-6,'PrecondBandWidth',Inf,'DerivativeCheck','off'); 
% ,'Algorithm','levenberg-marquardt'
% supress algorithm statements % 'trust-region-reflective'
%[mmle func flag output Jacob] = fsolve(@(theta) FUN(theta,sfe,Z{:}),mmle,opt); if flag>0, flag=0; else flag=1; end

% using different matlab routine; no Jacobian
%CLogl=strcat('C',model); FUN=str2func(CLogl); % call C for 'model'
%opt=optimset('Display','off','Jacobian','off','LargeScale','On','TolFun',1e-6,'TolX',1e-6,'NonlEqnAlgorithm','gn'); % supress algorithm statements
%[mmle2 func2 flag2 output2 Jacob2] = fsolve(@(theta) FUN(theta,sfe,Z{:}),mmle,opt); if flag2>0, flag2=0; else flag2=1; end
%[VJ DJ]=eigs(Jacob); DJ



%using home-grown Newton-Raphson; Jacobian % only for logit
%CLogl=strcat('C',model,'_Jacobian'); FUN=str2func(CLogl); % call C for 'model'
%[mmleX grad flag iter]=NewtonRaphsonMoment(FUN,mmle,sfe,Z{:});


% using different matlab routine; no Jacobian
CLogl=strcat('C',model); FUN=str2func(CLogl); % call C for 'model'
opt=optimset('Display','off','Jacobian','off','LargeScale','Off','TolFun',1e-4,'TolX',1e-4,'Algorithm','levenberg-marquardt'); % gn, lm, 
[mmle func flag output Jacob] = fsolve(@(theta) FUN(theta,sfe,Z{:}),mmle,opt);



if flag>0, flag=0; else flag=1; end
% mmle3 func3 flag3 output3 Jacob3


% recovering estimated fixed effects
FELogl=strcat('FELogl',model); FUN=str2func(FELogl); % call FELogl for 'model'
[mmle_fe]=NewtonRaphsonMax(FUN,sfe',mmle,Z{:});
mfe=fe; mfe(indicator==1)=mmle_fe;







%[mmle*sqrt(3)/pi mmle2*sqrt(3)/pi mmle3*sqrt(3)/pi;func func2 func3]
%[mmle mmle2 mmle3;func func2 func3]
