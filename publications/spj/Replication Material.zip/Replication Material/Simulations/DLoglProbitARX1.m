function bias=DLoglProbitARX1(mle,fe,YL,YR,X,m) % m is bandwidth parameter
% computes bias approximation from Hahn-Kuersteiner (2004)
[T,N]=size(YL);
R=ones(T,1)*fe'+mle(1)*YR+mle(2)*X; F=normcdf(R); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+R.*R); B=exp(logf-logFA); C=-R.*B; D=(R.*R-1).*B;
E=YL-F; EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB; 

DFERHO     =-ones(T,1)*(sum(YR.*H)./sum(H));
DFEBETA    =-ones(T,1)*(sum(X.*H) ./sum(H));
DFERHORHO  = ones(T,1)*((sum(J.*(YR+DFERHO)).*sum(YR.*H)-sum(YR.*J.*(YR+DFERHO)).*sum(H))./((sum(H)).^2));
DFEBETABETA= ones(T,1)*((sum(J.*(X+DFEBETA)).*sum(X.*H)-sum(X.*J.*(X+DFEBETA)).*sum(H))./((sum(H)).^2))  ;
DFERHOBETA = ones(T,1)*((sum(J.*(X+DFEBETA)).*sum(YR.*H)-sum(YR.*J.*(X+DFEBETA)).*sum(H))./((sum(H)).^2));
%DFEBETARHO = ones(T,1)*((sum(J.*(YR+DFERHO)).*sum(X.*H)-sum(X.*J.*(YR+DFERHO)).*sum(H))./((sum(H)).^2));
% compute likelihood-based quantities 
Ur    =EB.*(YR+DFERHO); Ub    =EB.*(X+DFEBETA); V    =EB; % scores
Urfe  =H.*(YR+DFERHO) ; Ubfe  =H.*(X+DFEBETA) ; Vfe  =H ; % hessian terms
Urfefe=J.*(YR+DFERHO) ; Ubfefe=J.*(X+DFEBETA) ; Vfefe=J ;
Urr   =H.*(YR+DFERHO).^2+EB.*DFERHORHO;
Ubb   =H.*(X+DFEBETA).^2+EB.*DFEBETABETA;
Urb   =H.*(YR+DFERHO).*(X+DFEBETA)+EB.*DFERHOBETA;
% compute spectra and cross-spectra
M=(-m:1:m); GVV=zeros(length(M),N); GVUr=GVV; GVUb=GVV;
for j=1:length(M)
    l=max(1,M(j)+1); u=min(T,T+M(j));
    gVV =V(l:u,:).*V(l-M(j):u-M(j),:);    GVV(j,:) =mean(gVV);
    gVUr=V(l:u,:).*Urfe(l-M(j):u-M(j),:); GVUr(j,:)=mean(gVUr);
    gVUb=V(l:u,:).*Ubfe(l-M(j):u-M(j),:); GVUb(j,:)=mean(gVUb);
end
fVV=sum(GVV); fVUr=sum(GVUr); fVUb=sum(GVUb);
% form bias estimate
NUM=[mean(fVUr./mean(Vfe)-(mean(Urfefe).*fVV)./(2*(mean(Vfe)).^2));
     mean(fVUb./mean(Vfe)-(mean(Ubfefe).*fVV)./(2*(mean(Vfe)).^2))];
DEN=[mean(mean(Urr)),mean(mean(Urb));mean(mean(Urb)),mean(mean(Ubb))];
bias=1/T*(inv(DEN)*NUM);