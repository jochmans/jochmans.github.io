function AdviceApplication
%% LOAD DATASET
% see: https://www.stats.ox.ac.uk/~snijders/siena/Lazega_lawyers_data.htm
%load ELfriend; Y = double(st_dataset); % Friendship network - application in 9/2016 version
load ELadvice; Y = double(st_dataset); % Advice network - application in 1/2017 version
load ELattr  ; Z = double(st_dataset); Z(:,1) = []; Z(:,end) = []; Z(:,end) = []; % raw regressors
% construct covariates
[N K] = size(Z); x = zeros(N,N,K); for k=1:K, x(:,:,k) = Z(:,k)*ones(1,N)-(Z(:,k)*ones(1,N))'; end; Z = x; clear x; % construct differences
X = zeros(N,N,K);
X(:,:,1) = Z(:,:,1)== 0; % sender and receiver are same level
X(:,:,2) = Z(:,:,2)== 0; % sender and receiver are same gender 
X(:,:,3) = Z(:,:,3)== 0; % sender and receiver work in same office
X(:,:,4) = Z(:,:,4)    ; % linear term in tenure difference
X(:,:,5) = Z(:,:,5)    ; % linear term in age difference
X(:,:,4) = abs(X(:,:,4));
X(:,:,5) = abs(X(:,:,5));
% Set data size
n = size(X,1); dim = size(X,3);
%% FIXED-EFFECT MLE
% create dummies and delete non-movers
for i = 1:n, temp = zeros(n,n); temp(i,:) = ones(1,n); DD(:,i) = reshape(temp',n*n,1); end; YY = reshape(Y,n*n,1  );
for j = 1:n, temp = zeros(n,n); temp(:,j) = ones(n,1); TT(:,j) = reshape(temp',n*n,1); end; XX = reshape(X,n*n,dim); C = zeros(n*n,1);
for i=1:n, C(i+(i-1)*n) = 1; end; YY(C==1)=[]; XX(C==1,:)=[]; DD(C==1,:)=[]; TT(C==1,:)=[]; 
% estimation    
[bb dev stats] = glmfit([XX DD TT],YY,'binomial','constant','off'); mle = bb(1:dim); se_mle = stats.se(1:dim); % [mle se_mle],
%% CONDITIONAL MLE
% construct quadruples
[zz rr ss] = Rearrangement(Y,X);  
zzz = zz(ss==1); zzz = (zzz+1)/2;
rrr = rr(ss==1,:);
%save data_rearranged; % display('computing...')
% point estimation
[gmm dev stats] = glmfit(rrr,zzz,'binomial','constant','off'); % gmm,
% standard error 
[se] = StandardError(gmm,Y,X); %  ci = [gmm-1.96*se, gmm+1.96*se]; % [gmm se ci]
    




%% CONDITIONAL-LIKELIHOOD FUNCTIONS
function [z r s] = Rearrangement(y,x)
F = @(e) 1./(1+exp(-e)); f = @(e) F(e).*(1-F(e)); ff = @(e) f(e).*(1-F(e))-f(e).*F(e); fff = @(e) ff(e).*(1-F(e))-2*f(e).*f(e)-F(e).*F(e).*ff(e); % unit logistic F, f, and f' and f'

[n m k] =size(x); nn = nchoosek(n,2); mm = nchoosek(m-2,2); rho = nn*mm; 

z = zeros(rho,1); r = zeros(rho,k); s = z;

c = 1;
for i1 = 1:n,
    for j1=1:m,
        if j1==i1; continue; end
        y11 = y(i1,j1); x11 = squeeze(x(i1,j1,:));
        for i2 = i1+1:n,
            if i2==j1; continue; end
            y21 = y(i2,j1); x21 = squeeze(x(i2,j1,:));
            for j2 =  j1+1:m,
                if j2==i1 || j2==i1, continue; end
                y12 = y(i1,j2); x12 = squeeze(x(i1,j2,:));
                y22 = y(i2,j2); x22 = squeeze(x(i2,j2,:));

                s(c)   = (y11>y12 & y21<y22) + (y11<y12 & y21>y22);
                z(c)   = (y11-y12)-(y21-y22)                      ; 
                r(c,:) = (x11-x12)-(x21-x22)                      ; c = c+1;
            end
        end
    end
end
z = z/2;

function [se] = StandardError(psi,y,x)
F = @(e) 1./(1+exp(-e)); f = @(e) F(e).*(1-F(e)); ff = @(e) f(e).*(1-F(e))-f(e).*F(e); fff = @(e) ff(e).*(1-F(e))-2*f(e).*f(e)-F(e).*F(e).*ff(e); % unit logistic F, f, and f' and f''

[n m] =size(y); nn = nchoosek(n,2); mm = nchoosek(m-2,2); rho = nn*mm/4; dim = length(psi);

S = cell(dim,  1); for d=1:dim,               S{d}    = zeros(n,m-1,n-2,m-3);      end
J = cell(dim,dim); for d=1:dim, for dd=1:dim, H{d,dd} = zeros(n,m-1,n-2,m-3); end; end
for i1 = 1:n,
    for j1=1:m,
        if j1==i1, continue; end
        for i2 = 1:n,
            if i2==1 || i2==j1, continue; end
            for j2 =  1:m,
                if j2==i2 || j2==i1 || j2==j1, continue; end
                y11 = y(i1,j1); x11 = squeeze(x(i1,j1,:));
                y21 = y(i2,j1); x21 = squeeze(x(i2,j1,:));
                y12 = y(i1,j2); x12 = squeeze(x(i1,j2,:));
                y22 = y(i2,j2); x22 = squeeze(x(i2,j2,:));
                
                nondiag = (j1~=i1 & j1~=i2) + (j2~=i1 & j2~=i2);
                
                c = (y11>y12 & y21<y22) + (y11<y12 & y21>y22);
                a = (y11>y12 & y21<y22)                      ;
                b = (y11<y12 & y21>y22)                      ;
                r = (x11-x12)-(x21-x22)                      ;
                  
                % standard GMM - conditional likelihood
                for d=1:dim, S{d}(i1,j1,i2,j2) = r(d) *(a- F(r'*psi))*c*nondiag; end
                for d=1:dim,
                    for dd=1:dim, J{d,dd}(i1,j1,i2,j2) =   r(d)*r(dd)*(0- f(r'*psi))*c*nondiag; end
                end
   
            end
        end
    end
end

xi = cell(dim,1); V = zeros(dim,dim); Q =zeros(dim,dim);
for d=1:dim, xi{d} = 4*mean(mean(S{d},4),3); end
for d=1:dim,
    for dd=1:dim,
        V(d,dd) = mean(mean(xi{d}.*xi{dd}))              ; % moment asy variance
        Q(d,dd) = mean(mean(mean(mean(J{d,dd},4),3),2),1); % limit jacobian
    end
end
W = inv(Q'*Q)'*(Q'*V*Q)*inv(Q'*Q); se = sqrt(diag(W)/(n*m)); 