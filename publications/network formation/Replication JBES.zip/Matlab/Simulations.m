function [OUTPUT]=Simulations
% parameters
R  = 10; % # of Monte Carlo replications
n  =   25; % # of nodes 
theta = 1; % parameter value

% initialization
CMLE = zeros(R,1); MLE = CMLE; BC = CMLE; SECMLE = CMLE; SEMLE = CMLE; SEBC = CMLE;SE_X = CMLE;
% Replications
parfor r=1:R, [CMLE(r) MLE(r) BC(r) SECMLE(r) SEMLE(r) SEBC(r) SE_X(r)] = Simulation(n); end
% prepare screem output
TCMLE = (CMLE-ones(R,1)*theta)./SECMLE; aCMLE = abs(TCMLE)>=1.96;
TMLE  = ( MLE-ones(R,1)*theta)./SEMLE ; aMLE  = abs(TMLE )>=1.96;
TBC   = ( BC -ones(R,1)*theta)./SEBC  ; aBC   = abs(TBC  )>=1.96;
OUTPUT = [CMLE MLE BC SECMLE SEMLE SEBC TCMLE TMLE TBC aCMLE aMLE aBC];

function [cmle mle bc se_cmle se_mle se_bc se_x] = Simulation(n)
warning('off','all'); % prevent overparametrization warning for MLE
% auxiliary parameters and functions
m = nchoosek(n,2)*nchoosek(n-2,2); theta = 1;
F = @(u) 1./(1+exp(-u)); Q = @(u) log(u./(1-u)); f = @(u) F(u).*(1-F(u)); df = @(u) f(u).*(1-2*F(u));

% data generation % see paper for details on design choices
%L = 0           ;
L = log(log(n)) ;
%L = log(n)^(1/2);
%L = log(n)      ; 
a = (n-([1:n]))/(n-1)*L; a = a'; g = a'; 

v =  betarnd(2,2,n,1)-1/2; 
x = v*ones(1,n)-(v*ones(1,n))'; x = abs(x);
y = a*ones(1,n)+ones(n,1)*g+x*theta>=Q(rand(n,n)); 

% conditional logit estimation
[cmle se_cmle se_x m_star] = ConditionalLogit(y,x); 

% maximum likelihood estimation
for i = 1:n, temp = zeros(n,n); temp(i,:) = ones(1,n); D(:,i) = reshape(temp',n*n,1); end; Y = reshape(y,n*n,1);
for j = 1:n, temp = zeros(n,n); temp(:,j) = ones(n,1); T(:,j) = reshape(temp',n*n,1); end; X = reshape(x,n*n,1); C = zeros(n*n,1);
for i=1:n, C(i+(i-1)*n) = 1; end; Y(C==1)=[]; X(C==1)=[]; D(C==1,:)=[]; T(C==1,:)=[]; 
[coeff dev stats] = glmfit([X D T],Y,'binomial','constant','off'); mle = coeff(1); se_mle = stats.se(1); t_mle = (mle-theta)./se_mle;

% bias-corrected estimation
ahat = coeff(  2:n+1) ;
ghat = coeff(n+2:end)';
uhat = ahat*ones(1,n)+ones(n,1)*ghat + x*mle; 
w = f(uhat); W = reshape(w,n*n,1); W(C==1)=[];
[coeff dev stats] = glmfit([D T],X,'normal','constant','off','weights',W); V = stats.resid; 

Uhat = reshape(uhat,n*n,1); Uhat(C==1)=[]; uhat2 = reshape(Uhat,n,n-1); v2 = reshape(V,n,n-1); w2 = reshape(W,n,n-1);
denominator =           w2; 
numerator   = df(uhat2).*v2;  B = -.5*sum(numerator,2)./sum(denominator,2); B(isnan(B)==1)=[]; B = sum(B)/n;

Uhat = reshape(uhat,n*n,1); Uhat(C==1)=[]; uhat1 = reshape(Uhat,n,n-1); v1 = reshape(V,n,n-1); w1 = reshape(W,n,n-1);
denominator =           w1; 
numerator   = df(uhat1).*v1;  D = -.5*sum(numerator,1)./sum(denominator,1); D(isnan(D)==1)=[]; D = sum(D)/n;

W =  mean(mean(w1.*v1.*v1));

bias = inv(W)*B/n+inv(W)*D/n; bc = mle-bias; se_bc = se_mle; 

function [cmle se se_x m_star] = ConditionalLogit(y,x)

% construct quadruples
[zz rr ss] = Rearrangement(y,x);  m_star = sum(ss);
% drop non-informative quadruples
zzz = zz(ss==1); zzz = (zzz+1)/2;
rrr = rr(ss==1);
% estimate logit on quadruples
[cmle dev stats] = glmfit(rrr,zzz,'binomial','constant','off'); %cmle = coeff(1); se_mle = stats.se(1); t_mle = (mle-theta)./se_mle;
% construct standard errors
[se_x  se] = StandardError(cmle,y,x,m_star);

function [z r s] = Rearrangement(y,x)
% auxiliary parameters and functions
F = @(e) 1./(1+exp(-e)); f = @(e) F(e).*(1-F(e)); ff = @(e) f(e).*(1-F(e))-f(e).*F(e); % unit logistic F, f, and f'
[n m] =size(y); nn = nchoosek(n,2); mm = nchoosek(m-2,2); rho = nn*mm; 

% initialization
z = zeros(rho,1); r = z; s = z;

% construction loop (exploiting symmetry in i and j)
c = 1;
for i1 = 1:n,
    for j1=1:m,
        if j1==i1, continue; end
        y11 = y(i1,j1); x11 = x(i1,j1);
        for i2 = i1+1:n,
            if i2==i1 || i2==j1, continue; end
            y21 = y(i2,j1); x21 = x(i2,j1);
            for j2 =  j1+1:m,
                if j2==i1 || j2==j1 || j2==i2, continue; end
                y12 = y(i1,j2); x12 = x(i1,j2);
                y22 = y(i2,j2); x22 = x(i2,j2);

                s(c) = (y11>y12 & y21<y22) + (y11<y12 & y21>y22);
                z(c) = (y11-y12)-(y21-y22)                      ; 
                r(c) = (x11-x12)-(x21-x22)                      ; c = c+1;
            end
        end
    end
end
z = z/2;

function [se1 se2] = StandardError(psi,y,x,m_star)
% auxiliary parameters and functions
F = @(e) 1./(1+exp(-e)); f = @(e) F(e).*(1-F(e)); ff = @(e) f(e).*(1-F(e))-f(e).*F(e);  % unit logistic F, f, and f' and f''
[n m] =size(y); nn = nchoosek(n,2); mm = nchoosek(m-2,2);  rho = nn*mm; pn = m_star/rho;

n_units = 0;
S = zeros(n,n,n,n); J = S;
for i1 = 1:n,
    for j1=1:m,
        if j1==i1, continue; end
        y11 = y(i1,j1); x11 = x(i1,j1);
        for i2 = 1:n,
            if i2==i1 || i2==j1, continue; end
            y21 = y(i2,j1); x21 = x(i2,j1);
            for j2 =  1:m,
                if j2==i1 || j2==i2 || j2==j1, continue; end
                y12 = y(i1,j2); x12 = x(i1,j2);
                y22 = y(i2,j2); x22 = x(i2,j2);
                
                c = (y11>y12 & y21<y22) + (y11<y12 & y21>y22); if c==1, n_units = n_units+1; end
                a = (y11>y12 & y21<y22)                      ;
                b = (y11<y12 & y21>y22)                      ;
                r = (x11-x12)-(x21-x22)                      ;
                
                % standard GMM - conditional likelihood
                S(i1,j1,i2,j2) =     r*(a- F(r*psi))*c;
                J(i1,j1,i2,j2) =   r*r*(0- f(r*psi))*c;
            end
        end
    end
end

xi = 4*sum(sum(S,4),3)/((n-2)*(n-3)); V = sum(sum(xi.*xi))/(n*(n-1)); % moment asy variance
 Q =   sum(sum(sum(sum(J,4),3),2),1)/(n*(n-1)*(n-2)*(n-3)); % limit jacobian
 
Q = Q/pn; V = V/pn;

W = inv(Q'*Q)'*(Q'*V*Q)*inv(Q'*Q); se1 = sqrt( W     /(n*(n-1)*pn));
W = inv(Q)        *V*      inv(Q); se2 = sqrt( W     /(n*(n-1)*pn));
W = inv(Q)        *V*      inv(Q); se1 = .25*sqrt( W     /(n*(n-1)*pn));


