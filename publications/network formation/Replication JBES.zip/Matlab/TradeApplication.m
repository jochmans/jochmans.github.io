function TradeApplication
%% LOAD DATASET
load SST_panel_2; % Original data source: Santos-Silva & Tenreyro (2006, ReStat)
% Set data size 
n = 136; 
nobs = 20; n = nobs; m = n; dim = 5;
% Define dependent variable
Y = (TRADE(1:m,1:n)>0);
% Define independent variables
X = zeros(n,m,dim);
X(:,:,1) = LNDIST(1:m,1:n);
X(:,:,2) = BORDER(1:m,1:n);
X(:,:,3) = COMLNG(1:m,1:n);
X(:,:,4) = COLONY(1:m,1:n);
X(:,:,5) = COMFRT(1:m,1:n);

%% FIXED_EFFECT MLE
% Manually create dummies
for i = 1:n, a = zeros(n,m); a(i,:) = ones(1,m); DD(:,i) = reshape(a',n*m,1); end; YY = reshape(Y,n*m,1);
for j = 1:m, a = zeros(n,m); a(:,j) = ones(m,1); TT(:,j) = reshape(a',n*m,1); end; XX = reshape(X,n*m,dim); 
% Estimation   
warning('off','all'); % prevent overparametrization warning for MLE
[bb dev stats] = glmfit([XX DD TT],YY,'binomial','constant','off'); mle = bb(1:dim); se_mle = stats.se(1:dim); % [mle se_mle],

%% CONDITIONAL MLE
% Point estimation
[cmle likelihood condition niter] = NewtonRaphsonMax(@GMM,mle,Y,X);
% Standard error construction
[se] = StandardError(cmle,Y,X); % [cmle se], 


%% CONDITIONAL-LIKELIHOOD FUNCTIONS
function [L LL LLL] = GMM(psi,y,x)
F = @(e) 1./(1+exp(-e)); f = @(e) F(e).*(1-F(e)); ff = @(e) f(e).*(1-F(e))-f(e).*F(e); fff = @(e) ff(e).*(1-F(e))-2*f(e).*f(e)-F(e).*F(e).*ff(e); % unit logistic F, f, and f' and f''

[n m] =size(y); nn = nchoosek(n,2); mm = nchoosek(m-2,2); rho = nn*mm; dim = length(psi);

S = zeros(dim,1); J = zeros(dim,dim); CC = 0; %H = 0;
for i1 = 1:n,
    for j1=1:m, 
        if j1==i1, continue; end
        for i2 = i1+1:n,
            if i2==i1 || i2==j1, continue; end
            for j2 =  j1+1:m,
                if j2==i1 || j2==j1 || j2==i2, continue; end
                y11 = y(i1,j1); x11 = squeeze(x(i1,j1,:));
                y21 = y(i2,j1); x21 = squeeze(x(i2,j1,:));
                y12 = y(i1,j2); x12 = squeeze(x(i1,j2,:));
                y22 = y(i2,j2); x22 = squeeze(x(i2,j2,:));
               
                c = (y11>y12 & y21<y22) + (y11<y12 & y21>y22); CC = CC + c;
                a = (y11>y12 & y21<y22)                      ;
                b = (y11<y12 & y21>y22)                      ;
                r = (x11-x12)-(x21-x22)                      ;
                
                % standard GMM - conditional likelihood
                S = S +     r *(a- F(r'*psi))*c/rho;
                J = J +   r*r'*(0- f(r'*psi))*c/rho;
               % H = H + r*r*r*(0-ff(r*psi))*c/rho;    
            end
        end
    end
end

L   =   S'*S      ; L   = -L  ; % GMM objective
LL  = 2*J *S      ; LL  = -LL ; % first derivative
LLL = 2*J *J      ; LLL = -LLL; % second derivative
%LLL = 2*H*S+2*J*J; LLL = -LLL; % second derivative



function [se] = StandardError(psi,y,x)
F = @(e) 1./(1+exp(-e)); f = @(e) F(e).*(1-F(e)); ff = @(e) f(e).*(1-F(e))-f(e).*F(e); fff = @(e) ff(e).*(1-F(e))-2*f(e).*f(e)-F(e).*F(e).*ff(e); % unit logistic F, f, and f' and f''

[n m] =size(y); nn = nchoosek(n,2); mm = nchoosek(m-2,2); rho = n*(n-2)*(n-3)*(n-4); dim = length(psi);

S =  cell(dim,  1); for d=1:dim,               S{d}    = zeros(n,m);      end
J = zeros(dim,dim); % for d=1:dim, for dd=1:dim, H{d,dd} = zeros(n,m-1,n-2,m-3); end; end
for i1 = 1:n,
    for j1=1:m,
        if j1==i1, continue; end
        
        
        for i2 = 1:n,
            if i2==1 || i2==j1, continue; end
            for j2 =  1:m,
                if j2==i2 || j2==i1 || j2==j1, continue; end
                y11 = y(i1,j1); x11 = squeeze(x(i1,j1,:));
                y21 = y(i2,j1); x21 = squeeze(x(i2,j1,:));
                y12 = y(i1,j2); x12 = squeeze(x(i1,j2,:));
                y22 = y(i2,j2); x22 = squeeze(x(i2,j2,:));
                
                nondiag = (j1~=i1 & j1~=i2) + (j2~=i1 & j2~=i2);
                
                c = (y11>y12 & y21<y22) + (y11<y12 & y21>y22);
                a = (y11>y12 & y21<y22)                      ;
                b = (y11<y12 & y21>y22)                      ;
                r = (x11-x12)-(x21-x22)                      ;
                  
                % standard GMM - conditional likelihood
                for d=1:dim, 
                    S{d}(i1,j1) = S{d}(i1,j1) + 4*r(d) *(a- F(r'*psi))*c*nondiag/((n-2)*(m-3)); 
                end
                for d=1:dim,
                    for dd=1:dim, 
                        J(d,dd) = J(d,dd) + r(d)*r(dd)*(0- f(r'*psi))*c*nondiag/rho; 
                    end
                end
   
            end
        end
        
        
    end
end

xi = cell(dim,1); V = zeros(dim,dim); Q =zeros(dim,dim);
%for d=1:dim, xi{d} = 4*mean(mean(S{d},4),3); end
xi = S;
for d=1:dim,
    for dd=1:dim,
        V(d,dd) = mean(mean(xi{d}.*xi{dd}))              ; % moment asy variance
        Q(d,dd) = J(d,dd); % limit jacobian
    end
end
W = inv(Q'*Q)'*(Q'*V*Q)*inv(Q'*Q); se = sqrt(diag(W)/(n*m));  

%% OPTIMIZATION ROUTINE
function [x f g H condition it]=NewtonRaphsonMax(FUN,x,varargin) % varargout
% maximises FUN, starting at x by Newton-Raphson method
tol=1e-5; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x);
[f g H]=feval(FUN,x,varargin{:}); %varargout
while it<=maxit && condition==1 && improvement==1;
    [s1 s2]=size(H); if s1==s2 && s2>1 d=-inv(H)*g; else d=-g./H; end      
    step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff gg HH]=feval(FUN,x+step*d,varargin{:}); %varargout
        if (ff-f)/abs(f)>=-1e-5
            improvement=1; condition=sqrt(step*step*(d'*d))>tol & (ff-f)>tol;
            x=x+step*d; f=ff; g=gg; H=HH;
        else
            step=step/2;
        end
        %if length(x)>length(x2); return; end
    end
    it=it+1;
end
it=it-1;