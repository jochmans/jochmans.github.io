function AR1, global R alpha N T rho psi sigma file, format compact, format short g
R=10, alpha=.05; sigma = 1; file = 0; WRITEFILEHEADERS; % screen/file output
tic, for rho=[.5 .9 .99], for N=[100 250 500 1000 2500 5000 10000], for T=[2 4 6 8 16 24], for psi=[0 1 2], RUNMAL; end, end, end,end, toc

function RUNMAL, global R rho file alpha 
EST=zeros(R,3); CI=zeros(R,3); INFLEXION=zeros(R,1); DIST=zeros(R,1); crit=abs(norminv(alpha/2));
for r=1:R
    Y= GENERATE; [al,ab,hk,val,vab,vhk,INFLEXION(r),DIST(r)] = ESTIMATE(Y);
    EST(r,:)=[al ab hk]; t=([al ab hk]-rho)./sqrt([val vab vhk]); CI(r,:)=abs(t)<crit;
end, [RESULTS_est,~]=DSTATS(EST,CI,INFLEXION,DIST); disp(RESULTS_est); if file==1, WRITEFILE(RESULTS,est); end

function [al,ab,hk,val,vab,vhk,inflexion,dist] = ESTIMATE(Y), global T % ONE SIMULATION RUN
Yd  = Y; Yd(1,:)   =[]; Yd =Yd -ones(T,1)*mean(Yd) ; 
YLd = Y; YLd(T+1,:)=[]; YLd=YLd-ones(T,1)*mean(YLd); 
MM(1,1)=mean(mean(Yd.*Yd)); MM(1,2)=mean(mean(Yd .*YLd)); 
MM(2,1)=MM(1,2);            MM(2,2)=mean(mean(YLd.*YLd)); MM=MM/MM(1,1); % rescaled moments
[al,mle,val,~,inflexion,dist] = ESTIMATE_MAL(Yd,YLd,MM);   
                     [ab,vab] = ESTIMATE_ABGMM(Y); 
                     [hk,vhk] = ESTIMATE_HK(mle,MM);

function Y = GENERATE, global N T rho psi sigma % DATA GENERATION
FE = randn(1,N); Y0 =  FE/(1-rho)+psi*sigma/sqrt(1-rho^2);
Y=zeros(T+1,N); Y(1,:)=Y0; for t=2:T+1, Y(t,:)=FE+rho*Y(t-1,:)+sigma.*randn(1,N); end

function [mal,mle,avar,cond,inflexion,dist] = ESTIMATE_MAL(Yd,YLd,MM) % MAL ESTIMATION AND INFERENCE
[mle,bounds]=Ellipsoid(MM);
[mal0,~,~,~,cond0,it0]=NewtonMaxCstr(@Maximand,mle,bounds,MM,0); 
[mal1,~,~,~,cond1,it1]=NewtonMaxCstr(@Maximand,mle,bounds,MM,1); 
if cond0==0, inflexion=0; avar=AVAR_MAL(mal0,Yd,YLd,MM); end 
if cond0==1, inflexion=1; avar=inf; end
if cond0==0 && cond1==0 && abs(mal0-mal1)>1E-5,      disp([bounds mal0 mal1 cond0 cond1 it0 it1]), end
if             cond1==1 && abs(bounds(2)-mal1)>1E-5, disp([bounds mal0 mal1 cond0 cond1 it0 it1]), end
mal=mal1; cond=cond1; dist=abs(mle-mal)/abs(mle-bounds(1));
%n=1000;z=mle:(bounds(2)-mle)/n:bounds(2); for i=1:n+1, [f(i),~,]=Maximand(z(i),MM,0); end
%v=max(f); v=[v v-.05]; plot(z,f,[mal0 mal0],v,[mal1 mal1],v)

function [mle,bounds]=Ellipsoid(MM)
XX=MM(2,2); XY=MM(2,1); mle=XX\XY; Q=1-2*mle*XY+mle*mle*XX;  
h=-XX./Q; zeta2=-1/h; bounds=[mle-sqrt(zeta2) mle+sqrt(zeta2)];

function [Al,As,Ah,Aj]=ALogl(mal,MM) % adjusted profile loglikelihood, derivatives
XX=MM(2,2); XY=MM(2,1); Q=1-2*mal*XY+mal*mal*XX;  [iB,B,dB,ddB]=Bias(mal);           
l = -0.5*log(Q)    ; Al = l- iB;
s = (XY-XX*mal)/Q  ; As = s-  B;
h = -XX/Q+2*s*s'   ; Ah = h- dB;
j = -2*s*XX/Q+4*s*h; Aj = j-ddB;

function [f,df,ddf]=Maximand(mal,MM,maxim) 
[Al,As,Ah,Aj]=ALogl(mal,MM);
if maxim==0, f=Al;       df=As;     ddf=Ah;             end % maximand = Alogl
if maxim==1, f=-As*As/2; df=-Ah*As; ddf=-(Ah*Ah+Aj*As); end % maximand = -.5*Ascore^2
    
function [iB,B,dB,ddB]=Bias(mal), global T
t=1:(T-1); summand=(T./t-1)           .*mal.^t    ;  iB = -sum(summand)/(T*T-T);
           summand=(T-t)              .*mal.^(t-1);   B = -sum(summand)/(T*T-T);
           summand=(T-t).*(t-1)       .*mal.^(t-2);  dB = -sum(summand)/(T*T-T);
t=2:(T-1); summand=(T-t).*(t-1).*(t-2).*mal.^(t-3); ddB = -sum(summand)/(T*T-T);

function avar=AVAR_MAL(mal,Yd,YLd,MM), global N T 
[~,~,Ah,~]=ALogl(mal,MM); R = Yd-mal*YLd; [~,B,~,~]=Bias(mal);
sig2=sum(sum(R.*R))/N/(T-1); E=sum((YLd-R*B).*R)/sig2/(T-1); AV=mean(E.*E); avar=Ah\AV/Ah/N;

function [abgmm,avar]=ESTIMATE_ABGMM(Y), global T  % GMM ESTIMATION AND INFERENCE
DY=Y(2:T+1,:)-Y(1:T,:); DYL=DY; DY(1,:)=[]; DYL(T,:)=[];
s =[]; for t=1:T-1 s =[s 1:t]          ; end
ss=[]; for t=1:T-1 ss=[ss; t*ones(t,1)]; end
Z=Y(s',:); [d,n]=size(Z);
ZDY =Z.*DY(ss,:); ZDY=sum(ZDY,2); ZDYL=Z.*DYL(ss,:); ZDYL=sum(ZDYL,2);
A=Y*Y'; V1=zeros(d,d); V1(1,1)=2*A(1,1);  
for i=2:T-1
    ii=1+sum(1:i-1):sum(1:i); ij=ii(1:i-1)-i+1;
    V1(ii,ii)=2*A(1:i,1:i); V1(ii,ij)=-A(1:i,1:i-1); V1(ij,ii)=V1(ii,ij)';
end
a=V1\ZDYL; M=ZDYL'*a; abgmm=(ZDY'*a)/M;   
R=DY-abgmm*DYL; ZR=Z.*R(ss,:); V2=ZR*ZR'; avar=(a'*V2*a)/(M*M); 

function [hk,avar]=ESTIMATE_HK(mle,MM), global N T % HAHN AND KUERSTEINER ESTIMATION AND INFERENCE
hk=mle+(1+mle)/T; XX=MM(2,2); XY=MM(2,1); mse=[1,-hk']*MM*[1;-hk];
score=(XY-XX*hk)/mse; Hess=2*score*score'-XX/mse; avar = -inv(Hess)/(N*T);

function [x,f,g,H,cond,it]=NewtonMaxCstr(FUN,x,bounds,varargin) 
tol=1e-8; maxit=100; smalleststep=.5^20; it=1; cond=1; improvement=1; 
[f,g,H]=feval(FUN,x,varargin{:}); 
while it<=maxit && cond==1 && improvement==1;
    d=-H\g; step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff,gg,HH]=feval(FUN,x+step*d,varargin{:}); 
        if (ff-f)>=-tol && x+step*d>=bounds(1) && x+step*d<=bounds(2) 
            improvement=1; cond=sqrt(d'*d)>tol | (ff-f)>tol;
            x=x+step*d; f=ff; g=gg; H=HH;
        else step=step/2; end
    end, it=it+1;
end, it=it-1;

function [results_est,results_se]=DSTATS(EST,CI,INFLEXION,DIST), global R N T rho psi % CONSTRUCT OUTPUT FILES
Bias=mean(EST,1)-rho; SD=std(EST); seBias=SD/sqrt(R); 
%dev=EST-rho; dev2=dev.*dev; dev4=dev2.*dev2; mse=mean(dev2); RMSE=sqrt(mse); seRMSE=sqrt(mean(dev4)-mse.*mse)./(2*RMSE*sqrt(R));
de=EST-ones(R,1)*mean(EST); de2=de.*de; de4=de2.*de2; mde2=mean(de2); rmde2=sqrt(mde2);
seSD=sqrt(mean(de4)-mde2.*mde2)./(2*rmde2*sqrt(R)); 
seCI=std(CI)/sqrt(R); CI=mean(CI); seINFLEXION=std(INFLEXION)/sqrt(R); INFLEXION=mean(INFLEXION);
minDIST=min(DIST); maxDIST=max(DIST); seDIST=std(DIST)/sqrt(R); DIST=mean(DIST);
results_est=[N T psi rho   Bias   SD   CI   INFLEXION minDIST   DIST maxDIST];
results_se =[N T psi rho seBias seSD seCI seINFLEXION  NaN    seDIST   NaN  ];

function WRITEFILEHEADERS, global file
if file==1, fid=fopen('AR1.xls','a+'); 
            fprintf(fid,'Monte Carlo for MAL, (one-step) Arellano and Bond-GMM and Hahn-Kuersteiner in linear AR(1) DPD model with FE\n');
            fprintf(fid,' \t \t \t \t  Bias\t Bias\t Bias\t SD\t SD\t SD\t 95CI\t 95CI\t 95CI\t Inflexion\t minDIST\t DIST\t maxDIST\n');
            fprintf(fid,' N\t T\t psi\t rho\t MAL\t GMM1\t HK\t  MAL\t GMM1\t HK\t MAL\t GMM1\t HK\n'); fclose(fid); end
disp('                                                       ----------------- Bias -------------     ------------------ SD ------------   ----------------- 95CI -------------    Inflexion      minDIST     meanDIST      maxDIST  ')
disp('            N            T          psi          rho          MAL         GMM1           HK          MAL         GMM1           HK          MAL         GMM1           HK                                                      ')

function WRITEFILE(RESULTS)
fid=fopen('AR1.xls','a+'); fprintf(fid,'%g\t',RESULTS); fprintf(fid,'\n');  fclose(fid); 