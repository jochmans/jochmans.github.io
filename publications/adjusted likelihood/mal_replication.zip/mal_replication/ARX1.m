function ARX1(s), global R rho gamma N T psi alpha theta delta sigmaE sigmaU file , format compact, format short g % theta = (rho,beta)'
%WRITESCREENHEADERS; % screen output
WRITEFILEHEADERS;   % file output
R=10000; if ischar(s), s=str2double(s); end

% design point selection
NN  =[10000 5000 2500 1000 500 250 100]';  design=NN;
TT  =[24 16 8 6 4 2]';                     z=repmat(TT  ,1,size(design,1))'; design=[repmat(design,size(TT  ,1),1) z(:)]; 
ppsi=[0 1 2]';                             z=repmat(ppsi,1,size(design,1))'; design=[repmat(design,size(ppsi,1),1) z(:)]; 
ggam=[.5 .99]';                            z=repmat(ggam,1,size(design,1))'; design=[repmat(design,size(ggam,1),1) z(:)]; 
rrho=[.5 .9 .99]';                         z=repmat(rrho,1,size(design,1))'; design=[repmat(design,size(ppsi,1),1) z(:)];
design=design(:,[5 4 1 2 3]);
rho  =design(s,1);
gamma=design(s,2);
N    =design(s,3);
T    =design(s,4);
psi  =design(s,5); theta =[rho; 1-rho]; alpha=.05; delta =.5; sigmaE = 1; sigmaU = .5; file = 1; 

                                        % if ~(N>=5000 && T==24),      return, end
fname=['ARX1result',num2str(s),'.mat']; if size(dir(fname),1)==1, return, end

RESULT=RUNMAL; save(fname,'RESULT')
disp([R rho gamma N T psi])

function RESULTS_est=RUNMAL, global R theta file alpha
EST=zeros(R,6); CI=zeros(R,6); INFLEXION=zeros(R,1); DIST=zeros(R,1); crit=abs(norminv(alpha/2));
for r=1:R
    [Y,X] = GENERATE; [al,ab,hk,val,vab,vhk,INFLEXION(r),DIST(r)]=ESTIMATE(Y,X); EST(r,:)=[al' ab' hk'];
    t=([al' ab' hk']-[theta' theta' theta'])./sqrt([diag(val)' diag(vab)' diag(vhk)']); CI(r,:)=abs(t)<crit;
end, [RESULTS_est,~]=DSTATS(EST,CI,INFLEXION,DIST); if file==1, WRITEFILE([[R;R] RESULTS_est]); end
%disp(RESULTS_est)

function [al,ab,hk,val,vab,vhk,inflexion,dist] = ESTIMATE(Y,X)
[al,val,~,inflexion,dist] = ESTIMATE_MAL(Y,X); 
                 [ab,vab] = ESTIMATE_ABGMM(Y,X);
                 [hk,vhk] = HK(Y,X); hk=hk(1:2); 

function [Y,X] = GENERATE,global N T theta delta gamma sigmaE sigmaU psi % generate ARX(1) data; Y=(T+1)xN, X=TxN 
FE = randn(1,N); phi = delta*FE./(1-gamma);    phi2 = sigmaU^2./(1-gamma^2); Q=(1+theta(1)*gamma)/(1-theta(1)*gamma);
mu  = (FE+phi*theta(2))./(1-theta(1)); mu2  = (sigmaE^2+phi2*theta(2)^2*Q)/(1-theta(1)^2);
X0  =phi+sqrt(phi2); Y0  =mu+psi.*sqrt(mu2); X=zeros(T,N); Y=zeros(T+1,N);             
X(1,:)=X0; for t=2:T+1 X(t,:)=delta*FE +gamma   *X(t-1,:)                +sigmaU.*randn(1,N); end
Y(1,:)=Y0; for t=2:T+1 Y(t,:)=      FE +theta(1)*Y(t-1,:)+theta(2)*X(t,:)+sigmaE.*randn(1,N); end, X=X(2:T+1,:);

function [mal,avar,cond,inflexion,dist]=ESTIMATE_MAL(Y,X), global T
Yd  = Y; Yd(1,:)   =[]; Yd  = Yd -ones(T,1)*mean(Yd) ;
YLd = Y; YLd(T+1,:)=[]; YLd = YLd-ones(T,1)*mean(YLd);
Xd  = X;                Xd  = Xd -ones(T,1)*mean(Xd) ;
MM(1,1)=mean(mean(Yd.*Yd)); MM(1,2)=mean(mean(Yd .*YLd));  MM(1,3)=mean(mean(Yd .*Xd)); % moments
MM(2,1)=MM(1,2);            MM(2,2)=mean(mean(YLd.*YLd));  MM(2,3)=mean(mean(YLd.*Xd));
MM(3,1)=MM(1,3);            MM(3,2)=MM(2,3);               MM(3,3)=mean(mean(Xd .*Xd));
Pi0=MM(3,3)\MM(3,1); RYd  = Yd -Xd*Pi0;  % concentrating out X
Pi1=MM(3,3)\MM(3,2); RYLd = YLd-Xd*Pi1; 
MMc(1,1)=mean(mean(RYd.*RYd)); MMc(1,2)=mean(mean(RYd .*RYLd)); % concentrated moments
MMc(2,1)=MMc(1,2);             MMc(2,2)=mean(mean(RYLd.*RYLd));
[mle,bounds]=Ellipsoid(MMc); %[Pi0 Pi1 mle bounds]

[mal0,~,~,~,cond0,it0]=NewtonMaxCstr(@Maximand,mle,bounds,MMc,0); mal0=[mal0;Pi0-Pi1*mal0]; %disp([mal0 cond0 it0])
[mal1,~,~,~,cond1,it1]=NewtonMaxCstr(@Maximand,mle,bounds,MMc,1); mal1=[mal1;Pi0-Pi1*mal1]; %disp([mal1 cond1 it1 mal1-bounds(2)])
if cond0==0, inflexion=0; avar=AVAR_MAL(mal0,Yd,YLd,Xd,MM); end 
if cond0==1, inflexion=1; avar=[inf inf; inf inf]; end
mal=mal1; cond=cond1; dist=abs(mle-mal(1))/abs(mle-bounds(1));
if cond0==0 && cond1==0 && max(abs(mal0-mal1))>1E-5, disp([mal0' mal1' cond0 cond1 it0 it1]), end
if             cond1==1 && 1-dist>1E-5,              disp([mal0' mal1' cond0 cond1 it0 it1]), end

function [Al,As,Ah,Aj]=ALogl(mal,MMc) % adjusted profile loglikelihood, derivatives (with X profiled out)
XX=MMc(2,2); XY=MMc(2,1); mse=[1,-mal']*MMc*[1;-mal]; [iB,B,dB,ddB]=Bias(mal);           
l = -0.5*log(mse)    ; Al = l- iB;
s = (XY-XX*mal)/mse  ; As = s-  B;
h = -XX/mse+2*s*s'   ; Ah = h- dB;
j = -2*s*XX/mse+4*s*h; Aj = j-ddB;

function [f,df,ddf]=Maximand(mal,MMc,maxim) 
[Al,As,Ah,Aj]=ALogl(mal,MMc);
if maxim==0, f=Al;       df=As;     ddf=Ah;             end % maximand = Alogl
if maxim==1, f=-As*As/2; df=-Ah*As; ddf=-(Ah*Ah+Aj*As); end % maximand = -.5*Ascore^2

function [iB,B,dB,ddB]=Bias(mal), global T
t=1:(T-1); summand=(T./t-1)           .*mal.^t    ;  iB = -sum(summand)/(T*T-T);
           summand=(T-t)              .*mal.^(t-1);   B = -sum(summand)/(T*T-T);
           summand=(T-t).*(t-1)       .*mal.^(t-2);  dB = -sum(summand)/(T*T-T);
t=2:(T-1); summand=(T-t).*(t-1).*(t-2).*mal.^(t-3); ddB = -sum(summand)/(T*T-T);

function [mle,bounds]=Ellipsoid(MMc) 
XX=MMc(2,2); XY=MMc(2,1); mle=XX\XY; mse=[1,-mle']*MMc*[1;-mle]; 
h=-XX./mse; zeta2=-1/h; bounds=[mle-sqrt(zeta2) mle+sqrt(zeta2)];

function avar = AVAR_MAL(mal,Yd,YLd,Xd,MM), global N T
R=Yd-mal(1)*YLd-mal(2)*Xd; sig2=sum(sum(R.*R))/N/(T-1); [~,b,c,~]=Bias(mal(1));
E1=sum((YLd-R*b).*R)/sig2/(T-1);
E2=sum((Xd -R*0).*R)/sig2/(T-1);
XX=MM(2:3,2:3); XY=MM(2:3,1); mse=[1,-mal']*MM*[1;-mal]; 
s = (XY-XX*mal)/mse  ; %As = s-[b;0];
h = -XX/mse+2*s*s'   ; Ah = h-[c 0;0 0];
AV=[mean(E1.*E1) mean(E1.*E2); mean(E1.*E2) mean(E2.*E2)]; avar=Ah\AV/Ah/N;

function [abgmm,avar]=ESTIMATE_ABGMM(Y,X), global T  % one-step Arellano-Bond GMM
d1=(T-1)*(T)/2; d2=(T-1)*T; 
V11=zeros(d1,d1); V12=zeros(d1,d2); V22=zeros(d2,d2); % V21=V12' % components of weighting matrix V1
DY=Y(2:T+1,:)-Y(1:T,:); DYL=DY; DY(1,:)=[]; DYL(T,:)=[]; DX=X(2:T,:)-X(1:T-1,:);
s_lag =[]; for t=1:T-1 s_lag =[s_lag 1:t]          ; end
ss_lag=[]; for t=1:T-1 ss_lag=[ss_lag; t*ones(t,1)]; end
s_cov =[]; for t=1:T-1 s_cov =[s_cov; 1:T]         ; end 
ss_cov=[]; for t=1:T-1 ss_cov=[ss_cov;t*ones(T,1)] ; end
Zlag=Y(s_lag',:); Zcov=X(s_cov',:); Z=[Zlag;Zcov];
ZDYL=[Zlag.*DYL(ss_lag,:); Zcov.*DYL(ss_cov,:)];                 ZDYL=sum(ZDYL,2);
ZDX =[Zlag.* DX(ss_lag,:); Zcov.* DX(ss_cov,:)];                  ZDX=sum(ZDX ,2);
ZDRX  =[ZDYL,ZDX]; ZDY =[Zlag.*DY(ss_lag,:);Zcov.*DY(ss_cov,:)];  ZDY=sum(ZDY,2) ;
YY=Y*Y'; XX=X*X'; YX=Y*X';
V11(1,1)=2*YY(1,1); V22(1:T,1:T)=2*XX(1:T,1:T); V12(1,1:T)=2*YX(1,1:T);
for i=2:T-1
    iiy=1+sum(1:i-1):sum(1:i); ijy=iiy(1:i-1)-i+1;
    iix=1+(i-1)*T:i*T;         ijx=1+(i-2)*T:(i-1)*T;
    V11(iiy,iiy)=2*YY(1:i,1:i); V11(iiy,ijy)=-YY(1:i,1:i-1); V11(ijy,iiy)=V11(iiy,ijy)' ;
    V22(iix,iix)=2*XX(1:T,1:T); V22(iix,ijx)=-XX(1:T,1:T  ); V22(ijx,iix)=V22(iix,ijx)' ;
    V12(iiy,iix)=2*YX(1:i,1:T); V12(iiy,ijx)=-YX(1:i,1:T  ); V12(ijy,iix)=-YX(1:i-1,1:T);
end
V1=[V11,V12;V12',V22]; a=ZDRX'/V1; %a=ZDRX'*inv(V1);
abgmm=(a*ZDRX)\(a*ZDY); %inv(a*ZDRX)*(a*ZDY);
R=DY-abgmm(1)*DYL-abgmm(2)*DX; ZR =[Zlag.*R(ss_lag,:);Zcov.*R(ss_cov,:)]; V2=ZR*ZR';
M=inv(a*ZDRX); avar=M*(a*V2*a')*M;

function [hk,avar] = HK(Y,X), global N T % HAHN AND KUERSTEINER ESTIMATION AND INFERENCE
% compute mle for r,b, and s2
Yd  = Y; Yd(1,:)   =[]; Yd  = Yd -ones(T,1)*mean(Yd) ;
YLd = Y; YLd(T+1,:)=[]; YLd = YLd-ones(T,1)*mean(YLd);
Xd  = X;                Xd  = Xd -ones(T,1)*mean(Xd) ;
mle = inv([mean(mean(YLd.*YLd)),mean(mean(YLd.*Xd));mean(mean(Xd.*YLd)),mean(mean(Xd.*Xd))])*[mean(mean(YLd.*Yd));mean(mean(Xd.*Yd))];
r = mle(1); b = mle(2);
R = Yd-r*YLd-b*Xd; s2 = mean(mean(R.*R));
Ur = YLd.*R  /s2; Ub = Xd.*R /s2; Us  =-.5/s2    +.5*R.^2/s2;
Urr=-YLd.*YLd/s2; Ubb=-Xd.*Xd/s2; Uss= .5/(s2^2)-   R.^2/s2^3;
Urb=-YLd.*Xd /s2; Urs=0; Ubs=0; 
Urfe = -YLd/s2; Urfefe = 0;
Ubfe = -Xd /s2; Ubfefe = 0;
Usfe= -R/s2^2; Usfefe=1/s2^2;
V=R/s2; Vfe=-1/s2; Vfefe=0;
m =1;
M=(-m:1:m); GVV=zeros(length(M),size(Yd,2)); GVUr=GVV; GVUb=GVV; GVUs=GVV;
for j=1:length(M)
    l=max(1,M(j)+1); u=min(T,T+M(j));
    gVV =V(l:u,:).*V(l-M(j):u-M(j),:);    GVV(j,:) =mean(gVV);
    gVUr=V(l:u,:).*Urfe(l-M(j):u-M(j),:); GVUr(j,:)=mean(gVUr);
    gVUb=V(l:u,:).*Ubfe(l-M(j):u-M(j),:); GVUb(j,:)=mean(gVUb);
    gVUs=V(l:u,:).*Usfe(l-M(j):u-M(j),:); GVUs(j,:)=mean(gVUs);
end
fVV=sum(GVV); fVUr=sum(GVUr); fVUb=sum(GVUb); fVUs=sum(GVUs);
% form bias estimate
NUM=[mean(fVUr./mean(Vfe)-(mean(Urfefe).*fVV)./(2*(mean(Vfe)).^2));
     mean(fVUb./mean(Vfe)-(mean(Ubfefe).*fVV)./(2*(mean(Vfe)).^2));
     mean(fVUs./mean(Vfe)-(mean(Usfefe).*fVV)./(2*(mean(Vfe)).^2))];
DEN=[mean(mean(Urr)),mean(mean(Urb)),mean(mean(Urs));
     mean(mean(Urb)),mean(mean(Ubb)),mean(mean(Ubs));
     mean(mean(Urs)),mean(mean(Ubs)),mean(mean(Uss));];
bias=1/T*(inv(DEN)*NUM);
hk = [r;b;s2]-bias;
% asy var
varU  = mean(mean(R  .*R  )); covUY = mean(mean(R.*YLd)); covUX = mean(mean(R.*X)); s = [covUY./varU; covUX./varU];
varY  = mean(mean(YLd.*YLd));
varX  = mean(mean( Xd.* Xd));
covXY = mean(mean( Xd.*YLd));
H = [-(varY*varU+2*covUY*covUY)/varU^2, -(covXY*varU+2*covUY*covUX)/varU^2;-(covXY*varU+2*covUY*covUX)/varU^2, -(varX*varU+2*covUX*covUX)/varU^2];
avar = -inv(H)/(N*T); % avar = -inv(H)/(N*(T-1));

function [x,f,g,H,cond,it]=NewtonMaxCstr(FUN,x,bounds,varargin) 
tol=1e-8; maxit=100; smalleststep=.5^20; it=1; cond=1; improvement=1; 
[f,g,H]=feval(FUN,x,varargin{:}); 
while it<=maxit && cond==1 && improvement==1;
    d=-H\g; step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff,gg,HH]=feval(FUN,x+step*d,varargin{:}); 
        if (ff-f)>=-tol && x+step*d>=bounds(1) && x+step*d<=bounds(2) 
            improvement=1; cond=sqrt(d'*d)>tol | (ff-f)>tol;
            x=x+step*d; f=ff; g=gg; H=HH;
        else step=step/2; end
    end, it=it+1;
end, it=it-1;

function [results_est,results_se]=DSTATS(EST,CI,INFLEXION,DIST), global R N T theta gamma psi
Bias=mean(EST,1)-repmat(theta',1,3); SD=std(EST); seBias=SD/sqrt(R); 
%dev=EST-ones(R,1)*[theta',theta',theta'];  dev2=dev.*dev; dev4=dev2.*dev2; mse=mean(dev2); RMSE=sqrt(mse); seRMSE=sqrt(mean(dev4)-mse.*mse)./(2*RMSE*sqrt(R)); 
de=EST-ones(R,1)*mean(EST,1); de2=de.*de; de4=de2.*de2; mde2=mean(de2); rmde2=sqrt(mde2);
seSD=sqrt(mean(de4)-mde2.*mde2)./(2*rmde2*sqrt(R));
seCI=std(CI)/sqrt(R); CI=mean(CI); seINFLEXION=std(INFLEXION)/sqrt(R); INFLEXION=mean(INFLEXION);
minDIST=min(DIST); maxDIST=max(DIST); seDIST=std(DIST)/sqrt(R); DIST=mean(DIST);
results_est=[[N T psi; NaN NaN gamma] reshape([theta'   Bias   SD   CI],2,10) [  INFLEXION minDIST   DIST maxDIST; NaN NaN NaN NaN]];
results_se =[[N T psi; NaN NaN gamma] reshape([theta' seBias seSD seCI],2,10) [seINFLEXION     NaN seDIST     NaN; NaN NaN NaN NaN]];

function WRITEFILEHEADERS, global file
if file==1
     fid=fopen('ARX1.xls','a+'); 
     fprintf(fid,'Monte Carlo for MAL, (one-step) Arellano and Bond-GMM and Hahn-Kuersteiner in linear ARX(1) DPD model with FE\n');
     fprintf(fid,' \t \t \t \t \t  Bias\t Bias\t Bias\t SD\t SD\t SD\t 95CI\t 95CI\t 95CI\t Inflexion\t minDIST\t meanDIST\t maxDIST\n');
     fprintf(fid,' R\t N\t T\t psi/gam\t rho/beta\t MAL\t GMM1\t HK\t  MAL\t GMM1\t HK\t MAL\t GMM1\t HK\n'); fclose(fid); end
 
function WRITESCREENHEADERS
disp('                                                       ----------------- Bias -------------     ------------------ SD ------------   ----------------- 95CI -------------    Inflexion      minDIST     meanDIST      maxDIST  ')
disp('            N            T      psi/gam     rho/beta          MAL         GMM1           HK          MAL         GMM1           HK          MAL         GMM1           HK                                                      ')

function WRITEFILE(RESULTS)
fid=fopen('ARX1.xls','a+'); fprintf(fid,'%g\t',RESULTS(1,:)); fprintf(fid,'\n');
                            fprintf(fid,'%g\t',RESULTS(2,:)); fprintf(fid,'\n');  fclose(fid);                            