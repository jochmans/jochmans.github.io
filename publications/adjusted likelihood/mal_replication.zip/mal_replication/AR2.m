function AR2, global R alpha N T rho sigma psi file, format compact, format short g
R=10, alpha=.05; sigma = 1; file = 0; WRITEFILEHEADERS(file); % screen/file output
tic, rho=[.6; .2]; for N=[100 250 500 1000 2500 5000 10000], for T=[2 4 6 8 16 24], for psi=[0.3 1 2], RUNMAL; end, end, end, toc
tic, rho=[ 1;-.2]; for N=[100 250 500 1000 2500 5000 10000], for T=[2 4 6 8 16 24], for psi=[0.3 1 2], RUNMAL; end, end, end, toc

function RUNMAL, global R rho file alpha T
EST=zeros(R,6); CI=zeros(R,6); INFLEXION=zeros(R,1); DIST=zeros(R,1); crit=abs(norminv(alpha/2)); [K,A,B,C,D]=polynomials(2,T); 
for r=1:R
    [Y]= GENERATE; [al,ab,hk,val,vab,vhk,INFLEXION(r),DIST(r)] = ESTIMATE(Y,K,A,B,C,D); EST(r,:)=[al' ab' hk'];
    t=([al' ab' hk']-[rho' rho' rho'])./sqrt([diag(val)' diag(vab)' diag(vhk)']); CI(r,:)=abs(t)<crit;
end, [RESULTS_est,~]=DSTATS(EST,CI,INFLEXION,DIST); disp(RESULTS_est), if file==1, WRITEFILE(RESULTS); end

function [al,ab,hk,val,vab,vhk,inflexion,dist] = ESTIMATE(Y,K,A,B,C,D), global T
Yd  = Y; Yd(1:2,:)      =[]; Yd  =Yd  -ones(T,1)*mean(Yd)  ; 
YL1d= Y; YL1d([1,T+2],:)=[]; YL1d=YL1d-ones(T,1)*mean(YL1d); 
YL2d= Y; YL2d(T+1:T+2,:)=[]; YL2d=YL2d-ones(T,1)*mean(YL2d);
MM(1,1)=mean(mean(Yd.*Yd)); MM(1,2)=mean(mean(Yd  .*YL1d));  MM(1,3)=mean(mean(Yd  .*YL2d)); % moments
MM(2,1)=MM(1,2);            MM(2,2)=mean(mean(YL1d.*YL1d));  MM(2,3)=mean(mean(YL1d.*YL2d));
MM(3,1)=MM(1,3);            MM(3,2)=MM(2,3);                 MM(3,3)=mean(mean(YL2d.*YL2d));
[al,val,~,inflexion,dist] = ESTIMATE_MAL(Yd,YL1d,YL2d,MM,K,A,B,C,D); 
                 [ab,vab] = ESTIMATE_ABGMM(Y); 
                 [hk,vhk] = HK(Y); hk=hk(1:2); 

function Y = GENERATE, global N T rho sigma psi % generate AR(2) data; Y=(T+2)xN 
FE = randn(1,N); mu = ones(2,1)*FE./(1-sum(rho)); gamma0 = (1-rho(2))/((1+rho(2))*((1-rho(2))^2-rho(1)^2));
                                                  gamma1 = rho(1)/(1-rho(2))*gamma0;
Omega = sigma^2*[gamma0,gamma1;gamma1,gamma0]; L = chol(Omega,'lower'); Y0 = mu+psi*L*ones(2,N);
Y=zeros(T+2,N); Y(1:2,:)=Y0; for t=3:T+2, Y(t,:)= FE+rho(1)*Y(t-1,:)+rho(2)*Y(t-2,:)+sigma.*randn(1,N); end

function [mal,avar,cond,inflexion,dist]=ESTIMATE_MAL(Yd,YL1d,YL2d,MM,K,A,B,C,D) % MAL ESTIMATION AND INFERENCE
[mle,W]=Ellipsoid(MM);
[mal0,~,~,~,cond0,it0]=NewtonMaxCstr(@Maximand,mle,mle,W,MM,0,K,A,B,C,D); dist=sqrt((mal0-mle)'*W*(mal0-mle)); %a0=[mal0' cond0 it0 dist] 
[mal1,~,~,~,cond1,it1]=NewtonMaxCstr(@Maximand,mle,mle,W,MM,1,K,A,B,C,D); dist=sqrt((mal1-mle)'*W*(mal1-mle)); %a1=[mal1' cond1 it1 dist] 
if cond0==0, inflexion=0; avar=AVAR_MAL(mal0,Yd,YL1d,YL2d,MM,K,A,B,C,D); end 
if cond0==1, inflexion=1; avar=[inf inf; inf inf]; end
mal=mal1; cond=cond1; dist=sqrt((mal-mle)'*W*(mal-mle)); %disp([cond1 it1 dist])
if cond0==0 && cond1==0 && max(abs(mal0-mal1))>1E-5, disp([mal0' mal1' cond0 cond1 it0 it1]), end
if             cond1==1 && 1-dist>1E-5,              disp([mal0' mal1' cond0 cond1 it0 it1]), end

function [mle,W]=Ellipsoid(MM)
XX=MM(2:3,2:3); XY=MM(2:3,1); mle=XX\XY; mse=[1,-mle']*MM*[1;-mle]; Hessian=-XX./mse; W=-Hessian;

function [Al,As,Ah,Aj]=ALogl(mal,MM,K,A,B,C,D)  % normalised adjusted profile loglikelihood
XX=MM(2:3,2:3); XY=MM(2:3,1); Q=[1,-mal']*MM*[1;-mal]; [a,b,c,d]=bias(mal,K,A,B,C,D);
l = -0.5*log(Q)    ; Al = l-a;
s = (XY-XX*mal)/Q  ; As = s-b;
h = -XX/Q+2*s*s'   ; Ah = h-c;
 j=d*0; for u=1:2, for v=u:2, for w=v:2, j(u,v,w)= -2*XX(u,v)*s(w)/Q +2*h(u,w)*s(v)+2*h(v,w)*s(u); end, end, end
j(1,2,1)=j(1,1,2); j(2,1,1)=j(1,1,2); j(2,1,2)=j(1,2,2); j(2,2,1)=j(1,2,2); Aj = j-d;

function [f,df,ddf]=Maximand(mal,MM,maxim,K,A,B,C,D)
[Al,As,Ah,Aj]=ALogl(mal,MM,K,A,B,C,D);
if maxim==0, f=Al;        df=As;     ddf=Ah;             end % maximand = Alogl
if maxim==1, f=-As'*As/2; df=-Ah*As; ddf=-Ah*Ah-sum(Aj.*repmat(reshape(As,1,1,2),[2,2,1]),3); end % maximand = -.5*Ascore^2   

function [K,A,B,C,D]=polynomials(p,T) % polynomial coefficients of a,b,c,d
% each row of K is a vector of powers k; each row of A (B,C,D) is the corresponding coefficient (and 1st,2nd,3rd derivatives)
SS=[0;1]; for i=2:p, s=size(SS,1); SS=[repmat(SS,2,1),[zeros(s,1);ones(s,1)]]; end, KKK=[]; CCC=[];
for i=2:2^p, S=SS(i,:); % S indicates the subset of {1,...,p}
    for t=sum(S(:)):T-1
        maxk=floor(t./(1:p)); K=0;
        for ii=1:p, [r,c]=size(K); KK=[K zeros(r,1)]; for j=1:maxk(ii); KK=[KK; K j*ones(r,1)]; end, K=KK; end
        K=K(:,2:p+1); tt=K*(1:p)'; s=tt==t; K=K(s,:); s=sign(K)==sign(repmat(S,size(K,1),1)); s=all(s,2); K=K(s,:);
        [ncoef,c]=size(K); C=zeros(ncoef,1); for ii=1:ncoef, k=K(ii,:); C(ii)=factorial(sum(k)-1)/prod(factorial(k)); end
        C=-(T-t)/T/(T-1)*C; KKK=[KKK;K]; CCC=[CCC;C]; end, end
K=KKK; A=CCC; B=repmat(A,1,p).*K; k=size(K,1); C=zeros(k,p,p); for i=1:k, C(i,:,:)=A(i)*(K(i,:)'*K(i,:)-diag(K(i,:))); end, D=zeros(k,p,p,p);
for i=1:k, for u=1:p, for v=1:p, for w=1:p
    if     u==v && u==w, d=K(i,u)*(K(i,u)-1)*(K(i,u)-2);
    elseif u==v && u~=w, d=K(i,u)*(K(i,u)-1)*K(i,w);
    elseif u==w && u~=v, d=K(i,u)*(K(i,u)-1)*K(i,v);
    elseif v==w && u~=v, d=K(i,v)*(K(i,v)-1)*K(i,u);
    else                 d=K(i,u)*K(i,v)*K(i,w); end
    D(i,u,v,w)=A(i)*d; end, end, end, end

function [a,b,c,d]=bias(mal,K,A,B,C,D) % polynomial correction terms a,b,c
k=size(K,1); MAL=repmat(mal',k,1); b=zeros(2,1); c=zeros(2,2); d=zeros(2,2,2); 
           P=K;             Z=prod(MAL.^P,2); a=sum(A.*Z);
for i=1:2, P=K;
    P(:,i)=max(P(:,i)-1,0); Z=prod(MAL.^P,2); b(i)=sum(B(:,i).*Z); end 
for i=1:2, for j=i:2, P=K;
    P(:,i)=max(P(:,i)-1,0);
    P(:,j)=max(P(:,j)-1,0); Z=prod(MAL.^P,2); c(i,j)=sum(C(:,i,j).*Z); end, end
c(2,1)=c(1,2);
for i=1:2, for j=i:2, for m=j:2, P=K;
    P(:,i)=max(P(:,i)-1,0);
    P(:,j)=max(P(:,j)-1,0);
    P(:,m)=max(P(:,m)-1,0); Z=prod(MAL.^P,2); d(i,j,m)=sum(D(:,i,j,m).*Z); end, end, end
d(1,2,1)=d(1,1,2); d(2,1,1)=d(1,1,2); d(2,1,2)=d(1,2,2); d(2,2,1)=d(1,2,2);

function [internal]=IsinternaltoE(rho,mle,W)
internal=(rho-mle)'*W*(rho-mle)<=1;

function [avar] = AVAR_MAL(mal,Yd,YL1d,YL2d,MM,K,A,B,C,D), global N T
[~,~,Ah,~]=ALogl(mal,MM,K,A,B,C,D); R=Yd-mal(1)*YL1d-mal(2)*YL2d; [~,b,~,~]=bias(mal,K,A,B,C,D);
sig2=sum(sum(R.*R))/N/(T-1);
E1=sum((YL1d-R*b(1)).*R)/sig2/(T-1);
E2=sum((YL2d-R*b(2)).*R)/sig2/(T-1); AV=[mean(E1.*E1) mean(E1.*E2); mean(E1.*E2) mean(E2.*E2)]; avar=Ah\AV/Ah/N;

function [abgmm,avar]=ESTIMATE_ABGMM(Y), global T  % one-step Arellano-Bond GMM
DY=Y(4:T+2,:)-Y(3:T+1,:)  ; DYL=Y(3:T+1,:)-Y(2:T,:); DYL2=Y(2:T,:)-Y(1:T-1,:);
s =[]; for t=1:T-1 s =[s 1:t+1]         ; end
ss=[]; for t=1:T-1 ss=[ss;t*ones(t+1,1)]; end
Z =Y(s',:); ZDYL=Z.*DYL(ss,:); ZDYL2=Z.*DYL2(ss,:); ZDY=Z.*DY(ss,:);
ZDYL=sum(ZDYL,2); ZDYL2=sum(ZDYL2,2); ZDX=[ZDYL,ZDYL2]; ZDY=sum(ZDY,2);
YY=Y*Y'; d=(T-1)*T/2+(T-1); V1=zeros(d,d); V1(1:2,1:2)=2*YY(1:2,1:2);  
for i=2:T-1
    ii=sum(1:i):sum(1:i)+i; ij=ii(1:i)-i;
    V1(ii,ii)=2*YY(1:i+1,1:i+1);  V1(ii,ij)=-YY(1:i+1,1:i); V1(ij,ii)=V1(ii,ij)';
end
a=ZDX'/V1; abgmm=(a*ZDX)\(a*ZDY);
R=DY-abgmm(1)*DYL-abgmm(2)*DYL2; ZR =Z.*R(ss,:); V2=ZR*ZR'; M=inv(a*ZDX); avar=M*(a*V2*a')*M;

function [hk,avar] = HK(Y), global N T  % HAHN AND KUERSTEINER ESTIMATION AND INFERENCE
% compute mle for r1,r2, and s2
Yd  = Y; Yd(1:2,:)      =[]; Yd  =Yd  -ones(T,1)*mean(Yd)  ;
YL1d= Y; YL1d([1,T+2],:)=[]; YL1d=YL1d-ones(T,1)*mean(YL1d);
YL2d= Y; YL2d(T+1:T+2,:)=[]; YL2d=YL2d-ones(T,1)*mean(YL2d);
mle = inv([mean(mean(YL1d.*YL1d)),mean(mean(YL1d.*YL2d));mean(mean(YL2d.*YL1d)),mean(mean(YL2d.*YL2d))])*[mean(mean(YL1d.*Yd));mean(mean(YL2d.*Yd))];
r1 = mle(1); r2 = mle(2);
R = Yd-r1*YL1d-r2*YL2d; s2 = mean(mean(R.*R));
Ur1  = YL1d.*R   /s2; Ur2  = YL2d.*R   /s2; Us  =-.5/s2    +.5*R.^2/s2;
Ur1r1=-YL1d.*YL1d/s2; Ur2r2=-YL2d.*YL2d/s2; Uss = .5/(s2^2)-   R.^2/s2^3;
Ur1r2=-YL1d.*YL2d/s2; Ur1s=0; Ur2s=0; 
Ur1fe = -YL1d/s2; Ur1fefe = 0;
Ur2fe = -YL2d/s2; Ur2fefe = 0;
Usfe  = -R/s2^2 ; Usfefe  =1/s2^2;
V=R/s2; Vfe=-1/s2; Vfefe=0;
m =1;
M=(-m:1:m); GVV=zeros(length(M),size(Yd,2)); GVUr=GVV; GVUb=GVV; GVUs=GVV;
for j=1:length(M)
    l=max(1,M(j)+1); u=min(T,T+M(j));
    gVV =V(l:u,:).*V(l-M(j):u-M(j),:);     GVV(j,:) =mean(gVV);
    gVUr=V(l:u,:).*Ur1fe(l-M(j):u-M(j),:); GVUr(j,:)=mean(gVUr);
    gVUb=V(l:u,:).*Ur2fe(l-M(j):u-M(j),:); GVUb(j,:)=mean(gVUb);
    gVUs=V(l:u,:).*Usfe(l-M(j):u-M(j),:) ; GVUs(j,:)=mean(gVUs);
end
fVV=sum(GVV); fVUr=sum(GVUr); fVUb=sum(GVUb); fVUs=sum(GVUs);
% form bias estimate
NUM=[mean(fVUr./mean(Vfe)-(mean(Ur1fefe).*fVV)./(2*(mean(Vfe)).^2));
     mean(fVUb./mean(Vfe)-(mean(Ur2fefe).*fVV)./(2*(mean(Vfe)).^2));
     mean(fVUs./mean(Vfe)-(mean(Usfefe).*fVV)./(2*(mean(Vfe)).^2))];
DEN=[mean(mean(Ur1r1)),mean(mean(Ur1r2)),mean(mean(Ur1s));
     mean(mean(Ur1r2)),mean(mean(Ur2r2)),mean(mean(Ur2s));
     mean(mean(Ur1s )),mean(mean(Ur2s )),mean(mean(Uss));];
bias=1/T*(inv(DEN)*NUM);
hk = [r1;r2;s2]-bias;
% asy var
varU  = mean(mean(R  .*R  )); covUY1 = mean(mean(R.*YL1d)); covUY2 = mean(mean(R.*YL2d)); s = [covUY1./varU; covUY2./varU];
varY1   = mean(mean(YL1d.*YL1d));
varY2   = mean(mean(YL2d.*YL2d));
covY2Y1 = mean(mean(YL2d.*YL1d));
H = [-(varY1*varU+2*covUY1*covUY1)/varU^2, -(covY2Y1*varU+2*covUY1*covUY2)/varU^2;-(covY2Y1*varU+2*covUY1*covUY2)/varU^2, -(varY2*varU+2*covUY2*covUY2)/varU^2];
avar = -inv(H)/(N*T); % avar = -inv(H)/(N*(T-1))

function [x,f,g,H,cond,it]=NewtonMaxCstr(FUN,x,mle,W,varargin) 
tol=1e-8; maxit=100; smalleststep=.5^20; it=1; cond=1; improvement=1; 
[f,g,H]=feval(FUN,x,varargin{:}); 
while it<=maxit && cond==1 && improvement==1;
    d=-H\g; step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff,gg,HH]=feval(FUN,x+step*d,varargin{:}); 
        if (ff-f)>=-tol && IsinternaltoE(x+step*d,mle,W)==1
            improvement=1; cond=sqrt(d'*d)>tol | (ff-f)>tol; %[d' ff-f cond]
            x=x+step*d; f=ff; g=gg; H=HH;
        else step=step/2; end
    end, it=it+1;
end, it=it-1;

function [results_est,results_se]=DSTATS(EST,CI,INFLEXION,DIST), global R N T rho psi
Bias=mean(EST,1)-[rho',rho',rho']; SD=std(EST); seBias=SD/sqrt(R); 
%dev=EST-ones(R,1)*[rho',rho',rho']; dev2=dev.*dev; dev4=dev2.*dev2; mse=mean(dev2); RMSE=sqrt(mse); seRMSE=sqrt(mean(dev4)-mse.*mse)./(2*RMSE*sqrt(R)); 
de=EST-ones(R,1)*mean(EST,1); de2=de.*de; de4=de2.*de2; mde2=mean(de2); rmde2=sqrt(mde2);
seSD=sqrt(mean(de4)-mde2.*mde2)./(2*rmde2*sqrt(R));
seCI=std(CI)/sqrt(R); CI=mean(CI); seINFLEXION=std(INFLEXION)/sqrt(R); INFLEXION=mean(INFLEXION);
minDIST=min(DIST); maxDIST=max(DIST); seDIST=std(DIST)/sqrt(R); DIST=mean(DIST);
results_est=[[N T psi; NaN NaN NaN;] reshape([rho'   Bias   SD   CI],2,10) [  INFLEXION minDIST   DIST maxDIST; NaN NaN NaN NaN]];
results_se =[[N T psi; NaN NaN NaN;] reshape([rho' seBias seSD seCI],2,10) [seINFLEXION     NaN seDIST     NaN; NaN NaN NaN NaN]];

function WRITEFILEHEADERS(file)
if file==1, fid=fopen('AR2.xls','a+'); 
            fprintf(fid,'Monte Carlo for MAL, (one-step) ABond GMM and HK in linear AR(2) DPD model with FE\n');
            fprintf(fid,' \t  \t    \t    \t  Bias\t Bias\t Bias\t SD\t SD\t SD\t 95CI\t 95CI\t 95CI\t Inflexion\t minDIST\t DIST\t maxDIST\n');
            fprintf(fid,'N\t T\t psi\t rho\t MAL\t GMM1\t HK\t  MAL\t GMM1\t HK\t MAL\t GMM1\t HK\n'); fclose(fid); end
disp('                                                       ----------------- Bias -------------     ------------------ SD ------------   ----------------- 95CI -------------    Inflexion      minDIST     meanDIST      maxDIST  ')
disp('            N            T          psi          rho          MAL         GMM1           HK          MAL         GMM1           HK          MAL         GMM1           HK                                                      ')

function WRITEFILE(RESULTS)
fid=fopen('AR2.xls','a+'); fprintf(fid,'%g\t',RESULTS(1,:)); fprintf(fid,'\n');
                           fprintf(fid,'%g\t',RESULTS(2,:)); fprintf(fid,'\n');  fclose(fid);