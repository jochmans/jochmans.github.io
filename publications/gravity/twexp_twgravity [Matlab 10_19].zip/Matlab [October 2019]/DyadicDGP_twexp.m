function[exporter importer Y X1 X2 YY XX1 XX2] =  DyadicDGP_twexp(n1,n2)

b1 =  1; % coefficient on 1st regressor
b2 =  1; % coefficient on 2nd regressor

% initialization
exporter = zeros(n1*n2,1);
importer = zeros(n1*n2,1);
Y = zeros(n1*n2,1); X1 = zeros(n1*n2,1); XX1 = zeros(n1,n2); 
E = zeros(n1*n2,1); X2 = zeros(n1*n2,1); XX2 = zeros(n1,n2); YY = zeros(n1,n2);

% generate dyadic interactions  
m = 1;
for i=1:n1,
    for j=1:n2,

        exporter(m) = i;
        importer(m) = j;
        
        
        Z = (mvnrnd(zeros(2,1),[1, .5; .5 1]));
       
        X1(m) = double(Z(1)> 1); 
        X2(m) = double(Z(2)<-1); 
  

        E(m) = randn;  
        Y(m) = exp(X1(m)*b1+X2(m)*b2+E(m));
        
        XX1(i,j) = X1(m); 
        XX2(i,j) = X2(m);
         YY(i,j) =  Y(m);
        
        m = m+1;
    end
end