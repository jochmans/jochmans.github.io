function [gmm se asyvar] = twgravity1(Y,X,gmm0)
%% Calculates GMM1 point estimator and standard error as described in `Two-way model for gravity' (Jochmans 2016)
%% for a two-way exponential regression model on an n-by-n network without loops (i.e., no self-links)
% INPUT: 
% Y = n-by-n array of outcomes; diagonal should be set to zero
% X = d-dimensional cell of n-by-m matrices of regressors; diagonals should be set to zero
% starting value for optimization (gmm0).
% OUTPUT: 
% point estimate (gmm); 
% standard error (se);
% asymptotic covariance matrix (asyvar)

% NOTES: 
% The diagonal entries in the above matrices will be re-set to zero
% This algorithm is optimized for speed in both optimization and calculation of the standard error

%% Demean regressors to deal with possible non-negativity of covariates
Y = Y-diag(diag(Y));
[d] = length(gmm0); for k=1:d, X{k} = X{k}-mean(mean(X{k})); X{k} = X{k}-diag(diag(X{k})); end

% Minimization of GMM problem by Newton's method, starting at gmm0
[gmm, condition, numiter, S] = Newton(@QuadraticForm,gmm0,Y,X); 
% Estimation of variance of moment conditions
[n ~] = size(Y); nn = nchoosek(n,2); mm = nchoosek(n-2,2); rho = nn*mm; J = inv(S/rho);
[V] = Vmatrix(gmm,Y,X);  
% Construction of standard errors
Upsilon = J*V*J'; asyvar = Upsilon/(n*(n-1)); se = sqrt(diag(Upsilon)/(n*(n-1)));

%% Evaluation of GMM problem at fixed parameter value psi
function [criterion score Hessian H] = QuadraticForm(psi,Y,X)
% dimensions
[n ~] =   size(Y  ); % sample size
[  d] = length(psi); % number of regressors
% variable definitions
index = zeros(n,n); for k=1:d, index = index+X{k}*psi(k); end % linear index 
phi   = exp(index); % exponential transform  
error =     Y./phi; % disturbance
d_error = cell(d,1); for k=1:d, d_error{k} = error.*X{k}; end % derivative of disturbance
% averages
error_i = sum(error,2);  
error_j = sum(error,1); m_error = sum(sum(error));
d_error_i =  cell(d,1); for k=1:d, d_error_i{k} = sum(d_error{k},2)  ; end
d_error_j =  cell(d,1); for k=1:d, d_error_j{k} = sum(d_error{k},1)  ; end 
m_derror  =  cell(d,1); for k=1:d, m_derror{k} = sum(sum(d_error{k})); end
% score vector
S = zeros(d,1); 
% full block
for k=1:d, S(k) = sum(sum(error.*X{k}))*sum(sum(error)) - sum(sum((error_i*error_j).*X{k})); end
% correction term
c_error = error*error;
for k=1:d, 
    A = sum(sum(X{k}.*(error.*error'+c_error)))-sum(error_j'.*sum(X{k}.*error,2))-sum(error_i'.*sum(X{k}.*error,1));
    S(k) = S(k)+ A;
end

% Jacobian matrix
H = zeros(d,d); 
% full block
for k=1:d,
    for j=1:d,
        H(k,j) = sum(sum(X{k}.*error.*(X{j}*m_error+m_derror{j}) - X{k}.*(error_i*d_error_j{j}+d_error_i{j}*error_j)));
    end
end
H = -H;
% correction term
c_derror  =  cell(d,1); for k=1:d, c_derror{k} = (error.*X{k})*error + error*(error.*X{k}) ; end

for k=1:d,
    for j=1:d,
        A1 = - sum(sum(X{k}.*(error.*error').*(X{j}+X{j}') + X{k}.*c_derror{j}));
        A2 =   sum(sum(X{k}.*X{j}.*error,2).*error_j')+ sum(sum(X{k}.*X{j}.*error,1).*error_i');
        A3 =   sum(sum(X{k}.*error,2).*sum(d_error{j},1)')+sum(sum(X{k}.*error,1).*sum(d_error{j},2)');
        H(k,j) = H(k,j) + A1 + A2 + A3; 
    end
end

% objective function
criterion = -  S'*S; 
score     = -2*H'*S;
Hessian   = -2*H'*H;

%% Estimation of the asymptotic variance of the moment conditions
function [mVar] = Vmatrix(psi,Y,X)
% dimensions
[n m] =   size(Y  ); % sample size
[  d] = length(psi); % number of regressors
% variable definitions
index = zeros(n,m); for k=1:d, index = index+X{k}*psi(k); end % linear index 
phi   = exp(index); % exponential transform  
error =     Y./phi; % disturbance
xerror = cell(d,1); for k=1:d, xerror{k} = error.*X{k}; end % derivative of disturbance

uXu = cell(d,1); for k=1:d, uXu{k} = error*X{k}'*error; end

u   = sum(sum(error)); xu = cell(d,1); for k=1:d, xu{k} = sum(sum(xerror{k})); end
u_i = sum(error,2); xu_i =  cell(d,1); for k=1:d, xu_i{k} = sum(xerror{k},2) ; end 
u_j = sum(error,1); xu_j =  cell(d,1); for k=1:d, xu_j{k} = sum(xerror{k},1) ; end 
xuu_j = cell(d,1); for k=1:d, xuu_j{k} = sum(X{k}.*(u_i*ones(1,m)),1); end
xuu_i = cell(d,1); for k=1:d, xuu_i{k} = sum(X{k}.*(ones(n,1)*u_j),2); end

xu_ij = cell(d,1); for k=1:d, xu_ij{k} = X{k}*error'; end
xu_ji = cell(d,1); for k=1:d, xu_ji{k} = (X{k}'*error)'; end

uxu_ji = cell(d,1); for k=1:d, uxu_ji{k} = error*(X{k}.*error); end
uxu_ij = cell(d,1); for k=1:d, uxu_ij{k} = (error.*X{k})*error; end

for k=1:d,
    fullterm = error.*(X{k}*u+xu{k})-(X{k}.*(u_i*u_j)+uXu{k}) + (xu_i{k}*u_j+u_i*xu_j{k}) - error.*(xuu_i{k}*ones(1,m)+ones(n,1)*xuu_j{k});
    
    A1 = X{k}.*error.*(error'-(ones(n,1)*u_j)'-(u_i*ones(1,n))');
    A2 = X{k}.*(error*error)+X{k}'.*(error.*error');
    A3 = -error.*((ones(n,1)*xu_j{k})'+(xu_i{k}*ones(1,n))');
    A4 = error.*(xu_ij{k}+xu_ji{k});
    A5 = - (uxu_ij{k} + uxu_ji{k});
    A = A1+A2+A3+A4+A5;
    
    xi{k} = fullterm + A;
    xi{k} = 4*xi{k}/((n-2)*(n-3));xi{k} = xi{k} - diag(diag(xi{k}));
end

for k=1:d,
    for j=1:d,
        mVar(k,j) = mean(mean(xi{k}.*xi{j})); 
    end
end

%% Newton algorithm used for optimization
function [x condition it J]=Newton(FUN,x,varargin) % varargout
% maximises FUN, starting at x by Newton-Raphson method
tol=1e-5; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x);
[f g H J] =feval(FUN,x,varargin{:}); %varargout
while it<=maxit && condition==1 && improvement==1;
    [s1 s2]=size(H); if s1==s2 && s2>1 d=-inv(H)*g; else d=-g./H; end      
    step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff gg HH JJ] =feval(FUN,x+step*d,varargin{:}); %varargout
        bounded = sum(sum(isnan(HH)))==0 & sum(sum(isinf(HH)))==0;
        if (ff-f)/abs(f)>=-1e-5 & bounded==1;
            improvement=1; condition=sqrt(step*step*(d'*d))>tol & (ff-f)>tol;
            x=x+step*d; f=ff; g=gg; H=HH; J = JJ;
        else
            step=step/2;
        end
    end
    it=it+1;
end
it=it-1;