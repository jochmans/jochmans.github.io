function smallsimulation_twgravity

n = 50; 

for r=1:100, 
    
    [exporter importer Y X1 X2 YY XX1 XX2] =  DyadicDGP_twgravity(n); % generate data

    XX = cell(2,1); XX{1}=XX1;  XX{2}=XX2; % arrange regressors in cell array

    gmm0 =  [0; 0]; % set starting values
    
    [gmm se condition] = twgravity1(YY,XX,gmm0);  GMMa(r,:)=gmm; SEa(r,:) = se; % GMM1
    [gmm se condition] = twgravity2(YY,XX,gmm0);  GMMb(r,:)=gmm; SEb(r,:) = se; % GMM2   

end


display('simulation results for GMM1');
mean(GMMa), median(GMMa),
std(GMMa), mean(SEa), median(SEa),

display('simulation results for GMM12');
mean(GMMb), median(GMMb),
std(GMMb), mean(SEb), median(SEb),

