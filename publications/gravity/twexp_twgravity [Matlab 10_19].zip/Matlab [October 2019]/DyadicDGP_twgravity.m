function[exporter importer Y X1 X2 YY XX1 XX2] =  DyadicDGP_twgravity(n)

b1 = -1; % coefficient on 1st regressor
b2 =  1; % coefficient on 2nd regressor

% initialization
exporter = zeros(n*n,1);
importer = zeros(n*n,1);
Y = zeros(n*n,1); X1 = zeros(n*n,1); XX1 = zeros(n,n); 
E = zeros(n*n,1); X2 = zeros(n*n,1); XX2 = zeros(n,n); YY = zeros(n,n);

% generate covariates at the individual level

x1 = double(randn(n,1)>0);
x2 = double(randn(n,1)>0);

% generate dyadic interactions  
m = 1;
for i=1:n,
    for j=1:n,
        if j==i, continue; end % no self-links here - all set to zero
        exporter(m) = i;
        importer(m) = j;
       
        X1(m) = double(x1(i)==x1(j))-double(x1(i)~=x1(j)); 
        X2(m) = double(x2(i)==x2(j))-double(x2(i)~=x2(j)); 
 
        E(m) = randn;  
        Y(m) = exp(X1(m)*b1+X2(m)*b2+E(m));
        
        XX1(i,j) = X1(m); 
        XX2(i,j) = X2(m);
         YY(i,j) =  Y(m);
        
        m = m+1;
    end
end

YY =  YY -diag(diag(YY ));
XX1 = XX1-diag(diag(XX1));
XX2 = XX2-diag(diag(XX2));
