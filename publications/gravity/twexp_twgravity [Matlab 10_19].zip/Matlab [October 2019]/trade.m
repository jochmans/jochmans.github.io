function trade

%% LOAD DATASET
load SantosSilva_Tenreyro_Data; 
% Set data size 
n = 136; dim = 5;
% Define dependent variable
Y =  TRADE(1:n,1:n)'; Y = Y - diag(diag(Y));
% Define independent variables
X = zeros(n,n,dim);
X(:,:,1 ) = LNDIST(1:n,1:n)';
X(:,:,2 ) = BORDER(1:n,1:n)';
X(:,:,3 ) = COMLNG(1:n,1:n)';
X(:,:,4 ) = COLONY(1:n,1:n)';
X(:,:,5 ) = COMFRT_WTO(1:n,1:n)';

%X(:,:,6 ) =   OPEN(1:n,1:n)';
%X(:,:,7 ) = COMFRT(1:n,1:n);
%X(:,:,8 ) =   OPEN_WTO(1:n,1:n)';

 XX = cell(dim,1); for k = 1:dim, XX{k} = X(:,:,k)-diag(diag(X(:,:,k))); end; X = XX;
 
[gmm se asyvar] = twgravity1(Y,X,zeros(dim,1)); display('GMM1:'); [gmm, se, gmm./se, gmm-1.96*se, gmm+1.96*se],

[gmm se asyvar] = twgravity2(Y,X,zeros(dim,1)); display('GMM2:'); [gmm, se, gmm./se, gmm-1.96*se, gmm+1.96*se],

