function [gmm se asyvar] = twgravity2(Y,X,gmm0)
%% Calculates GMM2 point estimator and standard error as described in `Two-way model for gravity' (Jochmans 2016)
%% for a two-way exponential regression model on an n-by-n network without loops (i.e., no self-links)
% INPUT: 
% Y = n-by-n array of outcomes; diagonal should be set to zero
% X = d-dimensional cell of n-by-m matrices of regressors
% starting value for optimization (gmm0).
% OUTPUT: 
% point estimate (gmm); 
% standard error (se);
% asymptotic covariance matrix (asyvar)

% NOTES: 
% The diagonal entries in the above matrices will be re-set as above
% This algorithm is optimized for speed in both optimization and calculation of the standard error

[n ~] = size(Y); nn = nchoosek(n,2); mm = nchoosek(n-2,2); rho = nn*mm;

% Minimization of GMM problem by Newton's method, starting at gmm0
[gmm, condition, numiter, S, M] = Newton(@QuadraticForm,gmm0,Y,X); 
if sqrt(M'*M)>1e-5 && condition==0, 
    condition=1; display('convergence to a local solution - check starting values'); 
end
J = inv(S/rho);[V] = Vmatrix(gmm,Y,X);  
% Construction of standard errors
Upsilon = J*V*J'; asyvar = Upsilon/(n*(n-1)); se = sqrt(diag(Upsilon)/(n*(n-1)));

%% Evaluation of GMM problem at fixed parameter value psi
function [criterion score Hessian H S] = QuadraticForm(psi,Y,X)
% dimensions
[n ~] =   size(Y  ); % sample size
[  d] = length(psi); % number of regressors
% variable definitions
index = zeros(n,n); for k=1:d, index = index+X{k}*psi(k); end % linear index 
phi   = exp(index); % exponential transform  
phi = phi-diag(diag(phi)); % normalize diagonal entries to zero

% score vector
S = zeros(d,1); for k=1:d, S(k) = sum(sum(X{k}.*(Y.*(phi*Y'*phi)-phi.*(Y*phi'*Y)))); end
% Jacobian matrix
H = zeros(d,d);
for k=1:d,
    for j=1:d,
        H(k,j) =  sum(sum(X{k}.*Y.*((phi.*X{j})*Y'*phi) + X{k}.*Y.*(phi*Y'*(phi.*X{j}))-X{k}.*phi.*X{j}.*(Y*phi'*Y)-X{k}.*phi.*(Y*(phi.*X{j})'*Y)));
    end
end
% objective function
criterion = -  S'*S; 
score     = -2*H'*S;
Hessian   = -2*H'*H;

%% Estimation of the asymptotic variance of the moment conditions
function [mVar] = Vmatrix(psi,Y,X)
% dimensions
[n ~] =   size(Y  ); % sample size
[  d] = length(psi); % number of regressors
% variable definitions
index = zeros(n,n); for k=1:d, index = index+X{k}*psi(k); end % linear index 
phi   = exp(index); % exponential transform  
phi = phi-diag(diag(phi)); % normalize diagonal entries to zero

for k=1:d,
    T1 =  X{k}.*Y.*(phi*Y'*phi)  ;  T2 = -X{k}.*phi.*(Y*phi'*Y)  ;
    T3 = -Y.*((phi.*X{k})*Y'*phi);  T4 =  phi.*((X{k}.*Y)*phi'*Y);
    T5 = -Y.*(phi*Y'*(phi.*X{k}));  T6 =  phi.*(Y*phi'*(X{k}.*Y));
    T7 =  Y.*(phi*(X{k}.*Y)'*phi);  T8 = -phi.*(Y*(phi.*X{k})'*Y);
    
    T = T1+T2+T3+T4+T5+T6+T7+T8; xi{k} = 4*T/((n-2)*(n-3));
end
for k=1:d,
    for j=1:d,
        mVar(k,j) = mean(mean(xi{k}.*xi{j})); 
    end
end

%% Newton algorithm used for optimization
function [x condition it J S]=Newton(FUN,x,varargin) % varargout
% maximises FUN, starting at x by Newton-Raphson method
tol=1e-7; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x);
[f g H J S] =feval(FUN,x,varargin{:}); %varargout
while it<=maxit && condition==1 && improvement==1;
    [s1 s2]=size(H); if s1==s2 && s2>1 d=-inv(H)*g; else d=-g./H; end      
    step=1; improvement=0;
    while step>=smalleststep && improvement==0;
        [ff gg HH JJ SS] =feval(FUN,x+step*d,varargin{:}); %varargout
        bounded = sum(sum(isnan(HH)))==0 & sum(sum(isinf(HH)))==0;
        if (ff-f)/abs(f)>=-tol & bounded==1;
            improvement=1; 
            condition= (ff-f)>tol  & sqrt(step*step*(d'*d))>tol; 
            % condition = (SS'*SS)>tol;
            x=x+step*d; f=ff; g=gg; H=HH; J = JJ; S = SS;
        else
            step=step/2;
        end
    end
    it=it+1;
end
it=it-1;