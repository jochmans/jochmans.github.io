function smallsimulation_twexp
 
n1 = 50; n2 = 5;

for r=1:100, 
 
    [exporter importer Y X1 X2 YY XX1 XX2] =  DyadicDGP_twexp(n1,n2); % generate data
 
    XX = cell(2,1); XX{1}=XX1;  XX{2}=XX2; % arrange regressors in cell array

    gmm0 =  [0; 0]; % set starting values
  
    [gmm se condition] = twexp1(YY,XX,gmm0);  GMMa(r,:)=gmm; SEa(r,:) = se; % GMM1
    [gmm se condition] = twexp2(YY,XX,gmm0);  GMMb(r,:)=gmm; SEb(r,:) = se; % GMM2
    

end


display('simulation results for GMM1');
mean(GMMa), median(GMMa),
std(GMMa), mean(SEa), median(SEa),

display('simulation results for GMM12');
mean(GMMb), median(GMMb),
std(GMMb), mean(SEb), median(SEb),

