function RMISE_STUDENTT(lambda)
% 

%clc; clear; close all;

R= 500;

for r=1:R, 
    [ISE1(r,:) ISE2(r,:) ISE3(r,:) PI1(r,:) PI2(r,:) PI3(r,:)] = ISEcalculation(lambda);
end

MISE1 = mean(ISE1); RMISE1 = sqrt(MISE1),
MISE2 = mean(ISE2); RMISE2 = sqrt(MISE2),
MISE3 = mean(ISE3); RMISE3 = sqrt(MISE3),

display('------------------------------')
MISE1 = mean(ISE1); RMISE1 = sqrt(MISE1),
MISE2 = mean(ISE2); RMISE2 = sqrt(MISE2),
MISE3 = mean(ISE3); RMISE3 = sqrt(MISE3),
display('------------------------------')

if lambda==.1, save student_results_lambda_1; display('finished 1; continuing on...'); end
if lambda==.2, save student_results_lambda_2; display('finished 2; continuing on...'); end
if lambda==.3, save student_results_lambda_3; display('finished 3; continuing on...'); end
if lambda==.4, save student_results_lambda_4; display('finished 4; continuing on...'); end
if lambda==.5, save student_results_lambda_5; display('finished 5; continuing on...'); end
if lambda==.6, save student_results_lambda_6; display('finished 6; continuing on...'); end
if lambda==.7, save student_results_lambda_7; display('finished 7; continuing on...'); end
if lambda==.8, save student_results_lambda_8; display('finished 8; continuing on...'); end
if lambda==.9, save student_results_lambda_9; display('finished 9; finished my runs'); end



function [ise1 ise2 ise3 pi1 pi2 pi3] = ISEcalculation(lambda)

%% POPULATION MODEL
T = 3  ; % number of outcome variables
K = 2  ; % number of mixing proportions
I = 10-1; % number of basis functions for diagonalization
J = 10-1;

dof = 10;
mu1 = [0,0,0]; % non-centrality of first component for all outcomes

mu2 = [3,4,5]; % non-centrality of second component for all outcomes
%mu2 = [1,1,1]; % iid case

pi  = [lambda 1-lambda]; % mixing proportions

%% SAMPLE
N = 500;
y = zeros(N,T);
u =  rand(N,1); uu = (u<=pi(1))+2*(u>pi(1)); u=uu; 
for t=1:T, 
    for i = 1:N,   y(i,t) = (u(i)==1).*nctrnd(dof,mu1(t))+(u(i)==2).*nctrnd(dof,mu2(t)); end
end 
y1 = y(:,1); y2 = y(:,2); y3 = y(:,3);


%% ESTIMATION
% INPUT MATRICES
g = @(i,y) hf_function_value   ( size(y,1), max(i)-1, y)'; % orthonormalized Hermite polynomials

% Estimation of Fourier coefficients from marginals
B1_1 = mean(g((1:J+1)',y1),2);
B1_2 = mean(g((1:J+1)',y2),2);
B1_3 = mean(g((1:J+1)',y3),2);

B2_1 = zeros(I+1,I+1);
B2_2 = zeros(I+1,I+1);
B2_3 = zeros(I+1,I+1);
for i = 1:I+1;
     for j = 1:I+1;
         g1 = g(i,y2); g2 = g(j,y3); B2_1(i,j) = mean(g1(end,:).*g2(end,:),2);
         g1 = g(i,y1); g2 = g(j,y3); B2_2(i,j) = mean(g1(end,:).*g2(end,:),2); 
         g1 = g(i,y1); g2 = g(j,y2); B2_3(i,j) = mean(g1(end,:).*g2(end,:),2); 
     end
end

B3_1 = zeros(I+1,I+1,J+1);
B3_2 = zeros(I+1,I+1,J+1);
B3_3 = zeros(I+1,I+1,J+1);
for i = 1:I+1;
     for j = 1:I+1;
         for k = 1:J+1
             g1 = g(k,y1); g2 = g(i,y2); g3 = g(j,y3); B3_1(i,j,k) = mean(g1(end,:).*g2(end,:).*g3(end,:),2);
             g1 = g(i,y1); g2 = g(k,y2); g3 = g(j,y3); B3_2(i,j,k) = mean(g1(end,:).*g2(end,:).*g3(end,:),2);
             g1 = g(i,y1); g2 = g(j,y2); g3 = g(k,y3); B3_3(i,j,k) = mean(g1(end,:).*g2(end,:).*g3(end,:),2);
         end
     end
end

% Whitening of B2 matrices
[Q_1,L_1,U_1] = svd(B2_1); L_ = sqrt(abs(L_1)); L_1=L_; L_1 = real(diag(1./diag(L_1(1:K,1:K)))); Q_1 = Q_1(:,1:K); U_1 = U_1(:,1:K);
[Q_2,L_2,U_2] = svd(B2_2); L_ = sqrt(abs(L_2)); L_2=L_; L_2 = real(diag(1./diag(L_2(1:K,1:K)))); Q_2 = Q_2(:,1:K); U_2 = U_2(:,1:K);
[Q_3,L_3,U_3] = svd(B2_3); L_ = sqrt(abs(L_3)); L_3=L_; L_3 = real(diag(1./diag(L_3(1:K,1:K)))); Q_3 = Q_3(:,1:K); U_3 = U_3(:,1:K);

W_1 = zeros(K,K,J+1); for k=1:J+1, W_1(:,:,k) = L_1*Q_1'*B3_1(:,:,k)*U_1*L_1; end; WW_1 = reshape(W_1,K,K*(J+1));
W_2 = zeros(K,K,J+1); for k=1:J+1, W_2(:,:,k) = L_2*Q_2'*B3_2(:,:,k)*U_2*L_2; end; WW_2 = reshape(W_2,K,K*(J+1));
W_3 = zeros(K,K,J+1); for k=1:J+1, W_3(:,:,k) = L_3*Q_3'*B3_3(:,:,k)*U_3*L_3; end; WW_3 = reshape(W_3,K,K*(J+1));

% Estimation of joint eigenvectors and associated eigenvalues
[QQ_1, ~, ~, D_1]= JDTM(W_1,1e-6,100); for j=1:J+1, D_1(:,:,j) = diag(diag(D_1(:,:,j))); end,
[QQ_2, ~, ~, D_2]= JDTM(W_2,1e-6,100); for j=1:J+1, D_2(:,:,j) = diag(diag(D_2(:,:,j))); end;
[QQ_3, ~, ~, D_3]= JDTM(W_3,1e-6,100); for j=1:J+1, D_3(:,:,j) = diag(diag(D_3(:,:,j))); end;

% QUASI-SHRT as an alternative
%[DD_1]= quasi_shrt(WW_1); DD_1 = reshape(DD_1,I+1,I+1,I+1); D_1 = DD_1;
%[DD_2]= quasi_shrt(WW_2); DD_2 = reshape(DD_2,I+1,I+1,I+1); D_2 = DD_2;
%[DD_3]= quasi_shrt(WW_3); DD_3 = reshape(DD_3,I+1,I+1,I+1); D_3 = DD_3;

% Numerical check for iid cases with JADE
% [QQ_1,D_1]= rjd(W_1); for j=1:I+1, D_1(:,:,j) = diag(diag(D_1(:,:,j))); end;
% [QQ_2,D_2]= rjd(W_2); for j=1:I+1, D_2(:,:,j) = diag(diag(D_2(:,:,j))); end;
% [QQ_3,D_3]= rjd(W_3); for j=1:I+1, D_3(:,:,j) = diag(diag(D_3(:,:,j))); end;

% LEAST-SQUARES FIT FOR MIXING PROPORTIONS
for k=1:J+1, G1(k,:) = diag(D_1(:,:,k))'; end; GG1 = inv(G1'*G1)*G1'; phat1  = GG1*B1_1; %omegahat1   = diag(Omegahat1);
for k=1:J+1, G2(k,:) = diag(D_2(:,:,k))'; end; GG2 = inv(G2'*G2)*G2'; phat2  = GG2*B1_2; %omegahat2   = diag(Omegahat2);
for k=1:J+1, G3(k,:) = diag(D_3(:,:,k))'; end; GG3 = inv(G3'*G3)*G3'; phat3  = GG3*B1_3; %omegahat3   = diag(Omegahat3);


% CROSS-VALIDATION FOR DENSITY ESTIMATION
% construction of `Omega' weights for density estimator
for k=1:K, 
    for n=1:N, % weights
        for i = 1:I+1;
            for j = 1:I+1;
                g1 = g(i,y2(n)); g2 = g(j,y3(n)); Xn_1(i,j) = g1(end,:)*g2(end,:); 
                g1 = g(i,y1(n)); g2 = g(j,y3(n)); Xn_2(i,j) = g1(end,:)*g2(end,:);   
                g1 = g(i,y1(n)); g2 = g(j,y2(n)); Xn_3(i,j) = g1(end,:)*g2(end,:); 
            end
        end
        R_1=inv(QQ_1); tau_1(n,k) = R_1(k,:)*L_1*Q_1'*Xn_1*U_1*L_1*QQ_1(:,k);
        R_2=inv(QQ_2); tau_2(n,k) = R_2(k,:)*L_2*Q_2'*Xn_2*U_2*L_2*QQ_2(:,k);
        R_3=inv(QQ_3); tau_3(n,k) = R_3(k,:)*L_3*Q_3'*Xn_3*U_3*L_3*QQ_3(:,k);   
     end
end


% cross-validation for all i,j densities
 for k=1:K,    
     minJ = 2; maxJ = 20; JJ = minJ:1:maxJ;
     CV=zeros(1,length(JJ)); for j=minJ:maxJ, CV(j-minJ+1) = crossvalidation(tau_1,k,j,y,1); end; CV1= CV; H_1(k) = JJ(CV==min(CV));
     CV=zeros(1,length(JJ)); for j=minJ:maxJ, CV(j-minJ+1) = crossvalidation(tau_2,k,j,y,2); end; CV2= CV; H_2(k) = JJ(CV==min(CV));
     CV=zeros(1,length(JJ)); for j=minJ:maxJ, CV(j-minJ+1) = crossvalidation(tau_3,k,j,y,3); end; CV3= CV; H_3(k) = JJ(CV==min(CV));
 end; 

%H_1 = [5, 5];
%H_2 = [5, 5];
%H_3 = [5, 5];

% DENSITY ESTIMATION
% construction of the density estimator via kernel representation (eigenvectors)
kernel = @(x,y,kappa) g((1:kappa+1)',x)'*g((1:kappa+1)',y);

fhat1 = @(a,k) mean((tau_1(:,k)*ones(1,length(a))).*kernel(y1,a,H_1(k)));
fhat2 = @(a,k) mean((tau_2(:,k)*ones(1,length(a))).*kernel(y2,a,H_2(k)));
fhat3 = @(a,k) mean((tau_3(:,k)*ones(1,length(a))).*kernel(y3,a,H_3(k)));

% (optional plot of estimates)
bmin = -4; bmax = 10; yi = [bmin:.1:bmax]';

%figure(1); subplot(1,3,1); hold on; pdfs1 = [fhat1(yi,1)',fhat1(yi,2)']; plot(yi,pdfs1(:,1),'black',yi,pdfs1(:,2),'black'); plot(yi,normpdf(yi,mu1(1),sd1(1)),'blue',yi,normpdf(yi,mu2(1),sd2(1)),'blue');
%figure(1); subplot(1,3,2); hold on; pdfs2 = [fhat2(yi,1)',fhat2(yi,2)']; plot(yi,pdfs2(:,1),'black',yi,pdfs2(:,2),'black'); plot(yi,normpdf(yi,mu1(2),sd1(2)),'blue',yi,normpdf(yi,mu2(2),sd2(2)),'blue');
%figure(1); subplot(1,3,3); hold on; pdfs3 = [fhat3(yi,1)',fhat3(yi,2)']; plot(yi,pdfs3(:,1),'black',yi,pdfs3(:,2),'black'); plot(yi,normpdf(yi,mu1(3),sd1(3)),'blue',yi,normpdf(yi,mu2(3),sd2(3)),'blue');


% checking for label-swapping; based on comparison of implied first moments
means1(1) = integral(@(a) a.*fhat1(a',1),bmin,bmax); means1(2) = integral(@(a) a.*fhat1(a',2),bmin,bmax); 
means2(1) = integral(@(a) a.*fhat2(a',1),bmin,bmax); means2(2) = integral(@(a) a.*fhat2(a',2),bmin,bmax); 
means3(1) = integral(@(a) a.*fhat3(a',1),bmin,bmax); means3(2) = integral(@(a) a.*fhat3(a',2),bmin,bmax); 

% integrated squared error calculations
m = @(t,k) mu1(t).*(k==1) + mu2(t).*(k==2);

ise1=zeros(1,2); sqerror1 = @(x,k1,k2) (fhat1(x',k1)-nctpdf(x,dof,m(1,k2))).^2;
ise2=zeros(1,2); sqerror2 = @(x,k1,k2) (fhat2(x',k1)-nctpdf(x,dof,m(2,k2))).^2;
ise3=zeros(1,2); sqerror3 = @(x,k1,k2) (fhat3(x',k1)-nctpdf(x,dof,m(3,k2))).^2;


if means1(1)<means1(2), 
    ise1(1) = integral(@(a) sqerror1(a,1,1),bmin,bmax);
    ise1(2) = integral(@(a) sqerror1(a,2,2),bmin,bmax); pi1 = [phat1(1) phat1(2)];
else
    ise1(1) = integral(@(a) sqerror1(a,2,1),bmin,bmax);
    ise1(2) = integral(@(a) sqerror1(a,1,2),bmin,bmax); pi1 = [phat1(2) phat1(1)];
end

if means2(1)<means2(2), 
    ise2(1) = integral(@(a) sqerror2(a,1,1),bmin,bmax);
    ise2(2) = integral(@(a) sqerror2(a,2,2),bmin,bmax); pi2 = [phat2(1) phat2(2)];
else
    ise2(1) = integral(@(a) sqerror2(a,2,1),bmin,bmax);
    ise2(2) = integral(@(a) sqerror2(a,1,2),bmin,bmax); pi2 = [phat2(2) phat2(1)];
end

if means3(1)<means3(2), 
    ise3(1) = integral(@(a) sqerror3(a,1,1),bmin,bmax);
    ise3(2) = integral(@(a) sqerror3(a,2,2),bmin,bmax); pi3 = [phat3(1) phat3(2)];
else
    ise3(1) = integral(@(a) sqerror3(a,2,1),bmin,bmax);
    ise3(2) = integral(@(a) sqerror3(a,1,2),bmin,bmax); pi3 = [phat3(2) phat3(1)];
end


function [objective] = crossvalidation(tau,k,J,y,dir)

g = @(i,y) hf_function_value   ( size(y,1), max(i)-1, y)' ; % Hermite system
kernel = @(x,y,kappa) g((1:kappa+1)',x)'*g((1:kappa+1)',y); % implied kernel function

% bias term calculations
N = size(y,1); lou = zeros(N,1);
for n=1:N, lou(n) = mean(tau([1:n-1,n+1:N],k).*kernel(y([1:n-1,n+1:N],dir),y(n,dir),J)); end % leave-one-out estimators
biasterm = mean(lou.*tau(:,k)); 

% variance term calculations
b = mean((tau(:,k)*ones(1,J+1)).*g((1:J+1)',y(:,dir))'); varsterm = b*b';

% corss-validation objective function
objective = varsterm-2*biasterm;














