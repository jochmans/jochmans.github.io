function [F] = SkewNormalPDF(X,mu,sigma,alpha)
%Z = (X-mu)./sigma; F = normcdf(Z)-2*Owen(Z,alpha); % CDF
F = 2*normpdf(X,mu,sigma)*normcdf(alpha*(X-mu)/sigma);