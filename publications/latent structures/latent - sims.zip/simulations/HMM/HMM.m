function HMM(N)


R = 500;

for r=1:R,
    [pdfs pdfq ste inf yi yi1 yi2 mu1 mu2 sd1 sd2 alpha1 alpha2] = Estimation(N);
    
    PDF1s(r,:) = pdfs(:,1)'; INF1(r,:) = inf(:,1)'; PDF1q(r,:) = pdfq(:,1)'; STD1(r,:) = ste(:,1)'; % LBD1(r,:) = lbd(:,1)'; UBD1(r,:) = ubd(:,1)'; 
    PDF2s(r,:) = pdfs(:,2)'; INF2(r,:) = inf(:,2)'; PDF2q(r,:) = pdfq(:,2)'; STD2(r,:) = ste(:,2)'; % LBD2(r,:) = lbd(:,2)'; UBD2(r,:) = ubd(:,2)'; 
    
end


for iii=1:length(yi), f1(iii) = SkewNormalPDF(yi(iii),mu1,sd1,alpha1); end;
for iii=1:length(yi), f2(iii) = SkewNormalPDF(yi(iii),mu2,sd2,alpha2); end;

%yi1 = [-1.9200,-1.7570,-1.6170,-1.4760,-1.3250,-1.1580,-0.9640,-0.7180,-0.3550]';  % dectiles of f1
%yi2 = [ 0.3550, 0.7180, 0.9640, 1.1580, 1.3260, 1.4760, 1.6170, 1.7570, 1.9200]';  % dectiles of f2;

figure(1); hold on;

plot(yi,f1,'black',yi,f2,'black');

plot(yi ,mean(PDF1s),'black--',yi ,mean(PDF2s),'black--');

YI1 = [yi1 yi1]; BOUND1 = [mean(PDF1q)'-1.96*mean(STD1)' mean(PDF1q)'+1.96*mean(STD1)']; plot(YI1,BOUND1,'black o'); plot(YI1',BOUND1','black--'); 
YI2 = [yi2 yi2]; BOUND2 = [mean(PDF2q)'-1.96*mean(STD2)' mean(PDF2q)'+1.96*mean(STD2)']; plot(YI2,BOUND2,'black o'); plot(YI2',BOUND2','black--');

YI1 = [yi1 yi1]; BOUND1 = [mean(PDF1q)'-1.96* std(PDF1q)' mean(PDF1q)'+1.96*std(PDF1q)']; plot(YI1,BOUND1,'black *'); plot(YI1',BOUND1','black--'); 
YI2 = [yi2 yi2]; BOUND2 = [mean(PDF2q)'-1.96* std(PDF2q)' mean(PDF2q)'+1.96*std(PDF2q)']; plot(YI2,BOUND2,'black *'); plot(YI2',BOUND2','black--');

%plot(yi1,mean(LBD1),'black o',yi1,mean(UBD1),'black o');
%plot(yi2,mean(LBD2),'black o',yi2,mean(UBD2),'black o');

plot(yi,mean(INF1),'blue-.' ,yi,mean(INF2),'blue-.' ); % still have to add empirical std of the density estimator here




function [pdfs pdfq ste inf yi yi1 yi2 mu1 mu2 sd1 sd2 alpha1 alpha2] = Estimation(N) 

%% POPULATION MODEL
T = 3   ; % number of outcome variables
K = 2   ; % number of mixing proportions
I =  5-1; % number of basis functions for SVD
J =  5-1; % number of basis functions for diagonalization

mu1 = -2; mu2 =  2; % component means
sd1 =  1; sd2 =  1; % component standard deviations

alpha1 = 5; rho1 = alpha1/sqrt(1+alpha1^2); % skewness of first component
alpha2 =-5; rho2 = alpha2/sqrt(1+alpha2^2); % skewness of second component

A     = [0.75 0.25 ; ...
         0.25 0.75]; % matrix of transition probabilities
       
pi0   = [A(2,1)/(1-A(2,2)+A(1,2)); ...
         A(1,2)/(1-A(2,2)+A(1,2))]; % induced steady-state distribution  
     
%% SAMPLE
y = zeros(N,T); 
z = zeros(N,T); 

% Markov chain for latent states
u1 = rand(N,1); z(:,1) =               1*(u1<=pi0(1))+2*(u1>pi0(1))                                               ; 
u2 = rand(N,1); z(:,2) = (z(:,1)==1).*(1*(u2<=A(1,1))+2*(u2>A(1,1))) + (z(:,1)==2).*(1*(u2<=A(2,1))+2*(u2>A(2,1))); 
u3 = rand(N,1); z(:,3) = (z(:,2)==1).*(1*(u3<=A(1,1))+2*(u3>A(1,1))) + (z(:,2)==2).*(1*(u3<=A(2,1))+2*(u3>A(2,1)));

% skewed emission distributions
u = randn(N,1); v = randn(N,1); w = rho1*u+sqrt(1-rho1^2)*v; yL = w.*(u>=0)-w.*(u<0); yL = mu1 + sd1*yL;
u = randn(N,1); v = randn(N,1); w = rho2*u+sqrt(1-rho2^2)*v; yR = w.*(u>=0)-w.*(u<0); yR = mu2 + sd2*yR; 
y1 = (z(:,1)==1).*yL + (z(:,1)==2).*yR;

u = randn(N,1); v = randn(N,1); w = rho1*u+sqrt(1-rho1^2)*v; yL = w.*(u>=0)-w.*(u<0); yL = mu1 + sd1*yL;
u = randn(N,1); v = randn(N,1); w = rho2*u+sqrt(1-rho2^2)*v; yR = w.*(u>=0)-w.*(u<0); yR = mu2 + sd2*yR; 
y2 = (z(:,2)==1).*yL + (z(:,2)==2).*yR;

u = randn(N,1); v = randn(N,1); w = rho1*u+sqrt(1-rho1^2)*v; yL = w.*(u>=0)-w.*(u<0); yL = mu1 + sd1*yL;
u = randn(N,1); v = randn(N,1); w = rho2*u+sqrt(1-rho2^2)*v; yR = w.*(u>=0)-w.*(u<0); yR = mu2 + sd2*yR; 
y3 = (z(:,3)==1).*yL + (z(:,3)==2).*yR;

y = [y1,y2,y3];

%% ESTIMATION
% INPUT MATRICES
g = @(i,y) hf_function_value   ( size(y,1), max(i)-1, y)'; % orthonormalized Hermite polynomials

% Estimation of Fourier coefficients from marginals
B1 = mean(g((1:J+1)',y2),2);

B2 = zeros(I+1,I+1);
for i = 1:I+1;
     for j = 1:I+1;
         g1 = g(i,y1); g2 = g(j,y3); B2(i,j) = mean(g1(end,:).*g2(end,:),2); 
     end
end

B3 = zeros(I+1,I+1,J+1);
for i = 1:I+1;
     for j = 1:I+1;
         for k = 1:J+1
             g1 = g(i,y1); g2 = g(k,y2); g3 = g(j,y3); B3(i,j,k) = mean(g1(end,:).*g2(end,:).*g3(end,:),2);
         end
     end
end

% Whitening of B2 matrices
[Q,L,U] = svd(B2); L_ = sqrt(abs(L)); L_ = real(diag(1./diag(L_(1:K,1:K)))); Q = Q(:,1:K); U = U(:,1:K);
W = zeros(K,K,J+1); for k=1:J+1, W(:,:,k) = L_*Q'*B3(:,:,k)*U*L_; end; WW = reshape(W,K,K*(J+1));

% Estimation of joint eigenvectors and associated eigenvalues
[QQ, ~, ~, D]= JDTM(W,1e-6,100); for j=1:J+1, D(:,:,j) = diag(diag(D(:,:,j))); end;
     
% LEAST-SQUARES FIT FOR MIXING PROPORTIONS
%for k=1:J+1, G(k,:) = diag(D(:,:,k))'; end; GG = inv(G'*G)*G'; phat  = GG*B1,     
 
% CROSS-VALIDATION FOR DENSITY ESTIMATION
% construction of `Omega' weights for density estimator
Xn = zeros(I+1,I+1);
for k=1:K, 
    for n=1:N, % weights
        for i = 1:I+1;
            for j = 1:I+1;
                g1 = g(i,y1(n)); g2 = g(j,y3(n)); Xn(i,j) = g1(end,:)*g2(end,:);    
            end
        end
        R=inv(QQ); tau(n,k) = R(k,:)*L_*Q'*Xn*U*L_*QQ(:,k);  
     end
end

% cross-validation for all i,j densities
 for k=1:K,    
     minJ = 3; maxJ = 20; JJ = minJ:1:maxJ;
     CV=zeros(1,length(JJ)); for j=minJ:maxJ, CV(j-minJ+1) = crossvalidation(tau,k,j,y,2); end; H(k) = JJ(CV==min(CV));
 end; 

 % DENSITY ESTIMATION
% construction of the density estimator via kernel representation (eigenvectors)
kernel = @(x,y,kappa) g((1:kappa+1)',x)'*g((1:kappa+1)',y);

fhat = @(a,k) mean((tau(:,k)*ones(1,length(a))).*kernel(y2,a,H(k)));
se = @(a,k) std((tau(:,k)*ones(1,length(a))).*kernel(y2,a,H(k)))/sqrt(N);

% checking for label-swapping; based on comparison of implied first moments
bmin = -5; bmax=5;
mean1 = integral(@(a) a.*fhat(a',1),bmin,bmax);  
mean2 = integral(@(a) a.*fhat(a',2),bmin,bmax); 

if mean1<mean2, 
    flip=0; % ordering is correct 
else 
    flip=1; % ordering is incorrect

end

yi1 = [-1.9200,-1.7570,-1.6170,-1.4760,-1.3250,-1.1580,-0.9640,-0.7180,-0.3550]';  % dectiles of f1
yi2 = [ 0.3550, 0.7180, 0.9640, 1.1580, 1.3260, 1.4760, 1.6170, 1.7570, 1.9200]';  % dectiles of f2;

yi = [bmin:.1:bmax]'; 
if flip==0,
    pdfs = [fhat(yi ,1)', fhat(yi ,2)'];
    pdfq = [fhat(yi1,1)', fhat(yi2,2)'];
     ste = [  se(yi1,1)',   se(yi2,2)'];
    %lbd = [fhat(yi1,1)'-1.96*se(yi1,1)' , fhat(yi2,2)'-1.96*se(yi2,2)' ];
    %ubd = [fhat(yi1,1)'+1.96*se(yi1,1)' , fhat(yi2,2)'+1.96*se(yi2,2)' ];
    
    inf = [ksdensity(y2(z(:,2)==1),yi), ksdensity(y2(z(:,2)==2),yi)];
else
    pdfs = [fhat(yi ,2)', fhat(yi ,1)'];
    pdfq = [fhat(yi1,2)', fhat(yi2,1)'];
     ste = [  se(yi1,2)',   se(yi2,1)'];
    %lbd = [fhat(yi2,2)'-1.96*se(yi2,2)' , fhat(yi1,1)'-1.96*se(yi1,1)' ];
    %ubd = [fhat(yi2,2)'+1.96*se(yi2,2)' , fhat(yi1,1)'+1.96*se(yi1,1)' ];
    
    inf = [ksdensity(y2(z(:,2)==1),yi), ksdensity(y2(z(:,2)==2),yi)];
end


%% CROSS-VALIDATION FUNCTION
function [objective] = crossvalidation(tau,k,J,y,dir)

g = @(i,y) hf_function_value   ( size(y,1), max(i)-1, y)' ; % Hermite system
kernel = @(x,y,kappa) g((1:kappa+1)',x)'*g((1:kappa+1)',y); % implied kernel function

% bias term calculations
N = size(y,1); lou = zeros(N,1);
for n=1:N, lou(n) = mean(tau([1:n-1,n+1:N],k).*kernel(y([1:n-1,n+1:N],dir),y(n,dir),J)); end % leave-one-out estimators
biasterm = mean(lou.*tau(:,k)); 

% variance term calculations
b = mean((tau(:,k)*ones(1,J+1)).*g((1:J+1)',y(:,dir))'); varsterm = b*b';

% cross-validation objective function
objective = varsterm-2*biasterm;