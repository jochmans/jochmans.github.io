function [A]= quasi_shrt(A,threshold)



[m,nm] = size(A); % n matrices of size m x m
n = nm/m;

if nargin==1, threshold=sqrt(eps); end;
%if nargin==1, threshold=1e-03; end;
maxiter = 500;


encore=1; iter = 1;
while encore, encore=0;
      for p=1:m-1,
          for q=p+1:m,
              %%% Shear transformation
              %%% --------------------
              top = 0; bot= 0;
              for i=1:n, 
                 a  = A(:,1+(i-1)*m:i*m);
                 In = a.*a; j = 1:1:m; j(p)=[]; j(q-1)=[];  Gn = sum(In(p,j)+In(q,j)+In(j,p)'+In(j,q)'   );
                                                            Kn = sum(a(p,j).*a(q,j)-(a(j,p).*a(j,q))')    ;
                                                            dn = a(p,p)-a(q,q)                            ;
                                                            en = a(p,q)-a(q,p)                            ;
                                                            
                 top = top + (Kn-en*dn);
                 bot = bot + (2*(dn^2+en^2)+Gn);
              end
              y = atanh(top/bot)  ;
              % Shear transformation computation
              c = cosh(y); s = sinh(y);  ss = s; % [abs(c) abs(s)]
              S = eye(m) ; S(p,p) = c; S(q,q) = c;
                           S(p,q) = s; S(q,p) = s;
              
              % construct A_prime
              %encore=encore | (abs(s)>threshold);
              if (abs(s)>threshold),
                 for i=1:n, a1 = A(:,1+(i-1)*m:i*m); Ap(:,1+(i-1)*m:i*m) = S\a1*S; end % Ap = S^{-1}AS
              else 
                  Ap = A;
              end
     
              %%% Unitary transformation
              %%% ----------------------
              % compute theta
              sum_de = 0; dif_de = 0;
              for i=1:n,
                  a = Ap(:,1+(i-1)*m:i*m);
                  dn = a(p,p)-a(q,q); en =-a(q,p)-a(p,q);
                  sum_de = sum_de + dn*en    ;
                  dif_de = dif_de + dn^2-en^2;
              end
              theta = .25*atan(2*sum_de/dif_de);
              % sign check
              crit  = cos(4*theta)*dif_de+2*sin(4*theta)*sum_de;
              theta = theta*sign(crit);
              
              % Unitary transformation computation
              c = cos(theta); s = sin(theta); 
              U = eye(m); U(p,p) = c; U(q,q) = c;
                          U(p,q) = s; U(q,p) =-s;
              %encore=encore | (abs(s)>threshold);
              % construct A_primeprime
              if (abs(s)>threshold),
                 for i=1:n, a1 = Ap(:,1+(i-1)*m:i*m); App(:,1+(i-1)*m:i*m) = U'*a1*U; end % App = U'ApU 
              else
                  App = Ap;
              end
             % update A
              A = App;
              %encore=encore | (abs(ss)>threshold); % | (abs(ss)>threshold);
              encore=encore | ((abs(s)>threshold) && (abs(ss)>threshold));
          end % of the loop on q
      end % of the loop on p
      encore = encore && iter<=maxiter; % if iter>maxiter, disp('max iter reached'); end; 
      iter = iter+1;
     % diagonal=0; count = count+1;
     % for i=1:n,  v = diag(A(:,1+(i-1)*m:i*m).*A(:,1+(i-1)*m:i*m),0); 
     %             diagonal = diagonal + norm(A(:,1+(i-1)*m:i*m).*A(:,1+(i-1)*m:i*m)-diag(v),'fro')^2;
end
  

     % encore=  iter<=250 | abs(s)>.0001; % && abs(ss)>.0001 % (abs(diagonal)>threshold) &&
     % if iter==250, disp('max iter reached'); diagonal, abs(s), end
      
%end % of the while loop




