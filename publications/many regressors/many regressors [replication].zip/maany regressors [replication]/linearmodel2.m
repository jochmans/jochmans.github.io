function linearmodel2(q)
% Matlab routine to replicate simulation results
% This routine has covariates w that are uniform on [-1,1]
% This variation on the design does not feature in the current draft of the paper
% The design is taken from CJN

R = 100; beta = 1; n = 700;

reject1 = zeros(R,1); cwidth1 = reject1;
reject2 = zeros(R,1); cwidth2 = reject2;


for r=1:R,
    w = zeros(n,q);
    w = [ones(n,1), -1 + 2*rand(n,q-1)]; x = randn(n,1); y = x*beta+randn;
         
    [b v1 v2] = regression(y,x,w);
    reject1(r,1) = abs((b-beta)/sqrt(v1))>=1.96;
    reject2(r,1) = abs((b-beta)/sqrt(v2))>=1.96;
    cwidth1(r,1) = 2*1.96*sqrt(max(v1,0));
    cwidth2(r,1) = 2*1.96*sqrt(max(v2,0));
    
end

mean(reject1), mean(cwidth1),
mean(reject2), mean(cwidth2),



function [b v1 v2] = regression(y,x,w)
[n q] = size(w);

a = regress(y,w); yhat = w*a;
a = regress(x,w); xhat = w*a; vhat = x-xhat; b = regress(y,vhat); ehat = (y-yhat)- (x-xhat)*b;

X = [x w]; H = eye(n)-X*inv(X'*X)*X'; L = eye(n)./diag(H); echeck = L*ehat;
M = eye(n)-w*inv(w'*w)*w';  if rank(M.*M)<size(M.*M,1), M2=eye(size(M.*M,1)); else M2 = inv(M.*M); end 

vx = mean((vhat.*vhat))  ;

vv1 = ((vhat.*vhat))'*M2*(ehat.*ehat)/n^2; v1 = (vv1)/vx^2; % CJN

perfect = (isnan(echeck)==1 | echeck==0);
vhat(perfect==1)=[]; y(perfect==1)=[]; echeck(perfect==1)=[]; 

vv2 = mean((vhat.*vhat).*(y   .*echeck))/n; v2 = (vv2)/vx^2; % LOO

