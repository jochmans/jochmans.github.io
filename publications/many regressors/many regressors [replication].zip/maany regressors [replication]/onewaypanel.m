function onewaypanel(T)
% Matlab routine to replicate simulation results in the Appendix (Table A.2)

R = 10000; beta = 1; N = floor(700/T);

reject0 = zeros(R,1); cwidth0 = reject0; indbeta = zeros(R,1); indvars = zeros(R,3);
reject1 = zeros(R,1); cwidth1 = reject1;
reject2 = zeros(R,1); cwidth2 = reject2;

parfor r=1:R,
    X = randn(N,T); alpha = zeros(N,1); Y = alpha*ones(1,T)+X*beta+randn(N,T);
    
    y = reshape(Y',N*T,1); 
    x = reshape(X',N*T,1);
    w = kron(eye(N),ones(T,1));
    
    [b v0 v1 v2] = regression(y,x,w);
    
    if T==2, % use EW for CJN when T=2
        DY = Y(:,2)-Y(:,1); DX = X(:,2)-X(:,1); DU = DY-b*DX; 
        v1 = inv(mean(DX.*DX))*mean((DX.*DX).*(DU.*DU))*inv(mean(DX.*DX))/N;
    end
    
    indbeta(r,1) = b      ;
    indvars(r,:) = [v0 max(0,v1) max(0,v2)];
    reject0(r,1) = abs((b-beta)/sqrt(v0))>=1.96;
    reject1(r,1) = abs((b-beta)/sqrt(v1))>=1.96;
    reject2(r,1) = abs((b-beta)/sqrt(v2))>=1.96;
    cwidth0(r,1) = 2*1.96*sqrt(max(v0,0));
    cwidth1(r,1) = 2*1.96*sqrt(max(v1,0));
    cwidth2(r,1) = 2*1.96*sqrt(max(v2,0));
    
end

[N,T],
[std(indbeta) mean(sqrt(indvars)), std(sqrt(indvars))],
[mean(reject0), mean(cwidth0), mean(reject1), mean(cwidth1), mean(reject2), mean(cwidth2)],



function [b v0 v1 v2] = regression(y,x,w)
[n q] = size(w);

a = regress(y,w); yhat = w*a;
a = regress(x,w); xhat = w*a; vhat = x-xhat; b = regress(y,vhat); ehat = (y-yhat)- (x-xhat)*b;

M = eye(n)-w*inv(w'*w)*w'; L = eye(n)./diag(M); echeck = L*ehat;
  
if rank(M.*M)<size(M.*M,1), M2=eye(size(M.*M,1)); else M2 = inv(M.*M); end 



vx = mean((vhat.*vhat))  ;

vv0 = ((vhat.*vhat))'*eye(n,n)*(ehat.*ehat)/n^2; v0 = (vv0)/vx^2; 

vv1 = ((vhat.*vhat))'*M2*(ehat.*ehat)/n^2; v1 = (vv1)/vx^2; % CJN

perfect = (isnan(echeck)==1 | echeck==0);
vhat(perfect==1)=[]; y(perfect==1)=[]; echeck(perfect==1)=[]; 
vv2 = mean((vhat.*vhat).*(y   .*echeck))/n; v2 = (vv2)/vx^2; % LOO
