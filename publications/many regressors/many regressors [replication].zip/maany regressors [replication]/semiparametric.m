function semiparametric
% Matlab routine to replicate simulation results in the Appendix (Table A.1)

R = 10000; n = 700; dimz = 6; mdegree = 5; beta = 1; 

reject0 = zeros(R,mdegree); cwidth0 = reject0; indvars0 = reject0; indbeta = zeros(R,mdegree); 
reject1 = zeros(R,mdegree); cwidth1 = reject1; indvars1 = reject1;
reject2 = zeros(R,mdegree); cwidth2 = reject2; indvars2 = reject2;

g = @(z) exp(-sqrt(sqrt(z'*z)));
h = @(z) exp( sqrt(sqrt(z'*z)));


parfor r=1:R,
    z = -1 + 2*rand(n,dimz);  x = zeros(n,1); y = zeros(n,1);
    for i = 1:n, 
        x(i) =             h(z(i,:)') + randn;
        y(i) = x(i)*beta + g(z(i,:)') + randn;
    end
    for degree=1:mdegree,
        [b v0 v1 v2] = regression(y,x,z,degree);
        indbeta(r,degree) = b      ;
        indvars0(r,degree) = [v0];
        indvars1(r,degree) = [max(v1,0)];
        indvars2(r,degree) = [max(v2,0)];
        reject0(r,degree) = abs((b-beta)/sqrt(v0))>=1.96;
        reject1(r,degree) = abs((b-beta)/sqrt(v1))>=1.96;
        reject2(r,degree) = abs((b-beta)/sqrt(v2))>=1.96;
        cwidth0(r,degree) = 2*1.96*sqrt(max(v0,0));
        cwidth1(r,degree) = 2*1.96*sqrt(max(v1,0));
        cwidth2(r,degree) = 2*1.96*sqrt(max(v2,0));
    end
end


[std(indbeta)],
[mean(sqrt(indvars0)); mean(sqrt(indvars1)); mean(sqrt(indvars2))], 
[ std(sqrt(indvars0));  std(sqrt(indvars1));  std(sqrt(indvars2))], 
[mean(reject0); mean(reject1); mean(reject2)],
[mean(cwidth0); mean(cwidth1); mean(cwidth2)],


function [b v0 v1 v2] = regression(y,x,z,degree)
[n dim] = size(z); q = (factorial(dim+degree)/(factorial(dim)*factorial(degree))); w = zeros(n,q);

for i=1:n, [w(i,:)] =  polynomial(z(i,:),degree); end

[n q] = size(w);
a = regress(y,w); yhat = w*a;
a = regress(x,w); xhat = w*a; vhat = x-xhat; b = regress(y,vhat); ehat = (y-yhat)- (x-xhat)*b;

M = eye(n)-w*inv(w'*w)*w';  if rank(M.*M)<size(M.*M,1), M2=eye(size(M.*M,1)); else M2 = inv(M.*M); end 

L = eye(n)./diag(M); echeck = L*ehat;

vx = mean((vhat.*vhat))  ;

vv0 = ((vhat.*vhat))'*eye(n,n)*(ehat.*ehat)/n^2; v0 = (vv0)/vx^2;
vv1 = ((vhat.*vhat))'*M2*(ehat.*ehat)/n^2; v1 = (vv1)/vx^2; % CJN
vv2 = mean((vhat.*vhat).*(y   .*echeck))/n; v2 = (vv2)/vx^2; % LOO



 
function [p] =  polynomial(z,degree)
dim = length(z); % z is row vector

p = [1 z];
if degree>=2
    new = z.^2; 
    for i=1:dim, new = [new, z(i).*z(i+1:end)]; end; p = [p, new];
end
if degree>=3
    new = z.^3; 
    for i=1:dim, for j=i+1:dim, new = [new, z(i).*z(j).*z(j+1:end)]; end; end;
    for i=1:dim, new = [new, z(i).*(z(i+1:end).^2)]; end; 
    for i=1:dim, new = [new, (z(i)).^2.*z(i+1:end)]; end;  p = [p, new];
end
if degree>=4
    new = z.^4; 
    for i=1:dim, for j=i+1:dim, for k=j+1:dim; new = [new, z(i).*z(j).*z(k).*z(k+1:end)]; end; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).*z(j).*z(j+1:end).^2]; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).*z(j).^2.*z(j+1:end)]; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).^2.*z(j).*z(j+1:end)]; end; end;
    for i=1:dim, new = [new, z(i).^2.*(z(i+1:end).^2)]; end;
    for i=1:dim, new = [new, z(i).*(z(i+1:end).^3)]; end; 
    for i=1:dim, new = [new, (z(i)).^3.*z(i+1:end)]; end;  p = [p, new];
end
if degree>=5
    new = z.^5; 
    for i=1:dim, for j=i+1:dim, for k=j+1:dim, for ell=k+1:dim; new = [new, z(i).*z(j).*z(k).*z(ell).*z(ell+1:end)]; end; end; end; end;
    for i=1:dim, for j=i+1:dim, for k=j+1:dim, new = [new, z(i).^2.*z(j).*z(k).*z(k+1:end)]; end; end; end;
    for i=1:dim, for j=i+1:dim, for k=j+1:dim, new = [new, z(i).*z(j).^2.*z(k).*z(k+1:end)]; end; end; end;
    for i=1:dim, for j=i+1:dim, for k=j+1:dim, new = [new, z(i).*z(j).*z(k).^2.*z(k+1:end)]; end; end; end;
    for i=1:dim, for j=i+1:dim, for k=j+1:dim, new = [new, z(i).*z(j).*z(k).*z(k+1:end).^2]; end; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).*z(j).*z(j+1:end).^3]; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).*z(j).^3.*z(j+1:end)]; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).^3.*z(j).*z(j+1:end)]; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).*z(j)^2.*z(j+1:end).^2]; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).^2.*z(j).*z(j+1:end).^2]; end; end;
    for i=1:dim, for j=i+1:dim, new = [new, z(i).^2.*z(j).^2.*z(j+1:end)]; end; end;
    for i=1:dim, new = [new, z(i).^2.*(z(i+1:end).^3)]; end;
    for i=1:dim, new = [new, z(i).^3.*(z(i+1:end).^2)]; end;
    for i=1:dim, new = [new, z(i).*(z(i+1:end).^4)]; end; 
    for i=1:dim, new = [new, (z(i)).^4.*z(i+1:end)]; end;  p = [p, new];
end

if length(p)~=(factorial(dim+degree)/(factorial(dim)*factorial(degree))), display('too few basis functions'); end






