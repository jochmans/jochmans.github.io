function SkewNormal

close all; clear; clc;

muG = 0; alphaG = 2.5; % alphaG>0; G is right-skewed
muH =-0; alphaH =-2.5; % alphaH<0; H is  left-skewed 

Q = 1/2; % P(X=1)
P = [3/4 1/4; 1/4 3/4]; % transition matrix X -> T: [0 to 0, 0 to 1; 1 to 0, 1 to 1]

n = 500;

C = .5; d = 6/10; % .5 .7 1 1.5 2

YY = min(muG,muH)-3.5:.25:3.5+max(muG,muH); %-1.5:.25:1.5; %-3:.1:3;
for i=1:length(YY),
    trueG(i) = SkewNormalCDF(YY(i),muG,1,alphaG);
    trueH(i) = SkewNormalCDF(YY(i),muH,1,alphaH);
end


R = 5000; r = 1;
%for r=1:R,
while r<=R
% data generation according to parameters
    [Y X] = DataGeneration(n,muG,muH,alphaG,alphaH,Q,P);
    
    % estimation and inference of mixing proportions
    [lambda0 selambda0 iq0 kq0] = EstimateProportionatA(Y,X,C,d,0); cilambda0 = lambda0-1.96*selambda0 <= P(1,2) & P(1,2) <= lambda0+1.96*selambda0;
    [lambda1 selambda1 iq1 kq1] = EstimateProportionatA(Y,X,C,d,1); cilambda1 = lambda1-1.96*selambda1 <= P(2,2) & P(2,2) <= lambda1+1.96*selambda1;
    
    % estimation and inference on component distributions   
    [Ghat0 Hhat0 SEGhat0 SEHhat0] = EstimateComponentsonA(Y,X,C,d,YY,0);    
     ciGhat0 = Ghat0-1.96*SEGhat0 <= trueG & trueG <= Ghat0+1.96*SEGhat0;
     ciHhat0 = Hhat0-1.96*SEHhat0 <= trueH & trueH <= Hhat0+1.96*SEHhat0;
     
   % [Ghat1 Hhat1 SEGhat1 SEHhat1] = EstimateComponentsonA(Y,X,C,d,YY,1);
   %  ciGhat1 = Ghat1-1.96*SEGhat1 <= trueG & trueG <= Ghat1+1.96*SEGhat1;
   %  ciHhat1 = Hhat1-1.96*SEHhat1 <= trueH & trueH <= Hhat1+1.96*SEHhat1;
    
    
    % vectorizing results for lambda
    lambda(r,:) = [lambda0 lambda1]; selambda(r,:) = [selambda0 selambda1]; cilambda(r,:) = [cilambda0 cilambda1];
    
    % vectorizing results for G and H
    G0(r,:) = Ghat0; seG0(r,:) = SEGhat0; ciG0(r,:) = ciGhat0;
    H0(r,:) = Hhat0; seH0(r,:) = SEHhat0; ciH0(r,:) = ciHhat0; 
    
   % G1(r,:) = Ghat1; seG1(r,:) = SEGhat1; ciG1(r,:) = ciGhat1;
   % H1(r,:) = Hhat1; seH1(r,:) = SEHhat1; ciH1(r,:) = ciHhat1; 
    
    % rate results for tails
    iotaq(r,:) = [iq0 iq1];
    kappq(r,:) = [kq0 kq1];
    
   % iq0, kq0,
   
   totalR = r+1;
   if isinf(lambda(r,:))==0, r = r+1; end
   
end

totalR,

[mean(iotaq); mean(kappq)],

 disp('results for lambda0 and lambda1');
 disp('-----------------------------------------------------------------------------');
 Bias  = mean(lambda) - [P(1,2) P(2,2)],
 SD    = std(lambda),
 SE_SD = mean(selambda)./std(lambda),
 CI    = mean(cilambda),

% disp('results for G0 and H0');
% disp('-----------------------------------------------------------------------------');
% Bias_SD_SESD_CI = [YY', (mean(G0) - trueG)', (mean(H0) - trueH)', std(G0)', std(H0)', mean(seG0)'./std(G0)', mean(seH0)'./std(H0)', mean(ciG0)', mean(ciH0)'],
 

figure(1); % G0
% estimators for G by
plot(YY,mean(G0),'black'); hold on; % estimator
plot(YY,  trueG ,'blue' ); hold on; % true curve
% inference for G
plot(YY,mean(G0)-1.96*mean(seG0),'black--',YY,mean(G0)+1.96*mean(seG0),'black--'); hold on;
plot(YY,mean(G0)-1.96* std(G0)  ,'red--'  ,YY,mean(G0)+1.96* std(G0)  ,'red--'  ); hold on;

figure(2); % H0
% estimators for H
plot(YY,mean(H0),'black'); hold on; % estimator
plot(YY,   trueH,'blue' ); hold on; % true curve
% inference for H
plot(YY,mean(H0)-1.96*mean(seH0),'black--',YY,mean(H0)+1.96*mean(seH0),'black--'); hold on; 
plot(YY,mean(H0)-1.96* std(H0)  ,'red--'  ,YY,mean(H0)+1.96* std(H0)  ,'red--'  ); hold on;





function [Y X] = DataGeneration(n,muG,muH,alphaG,alphaH,Q,P)
% parameter setup and low-order moments
rhoG = alphaG/sqrt(1+alphaG^2); sigmaG = 1; % meanG = muG + sigmaG*rhoG*sqrt(2/pi); varG = sigmaG^2*(1 - rhoG^2*2/pi);
rhoH = alphaH/sqrt(1+alphaH^2); sigmaH = 1; % meanH = muH + sigmaH*rhoH*sqrt(2/pi); varH = sigmaH^2*(1 - rhoH^2*2/pi);

% randomly generate instrument values according to P(X=1) = px
S = rand(n,1); X = (S > 1-Q);

% determine type T given instrument value X according to P(T=A|X=B) = P
S = rand(n,1); T = (X==0).*(S>=P(1,1)) + (X==1).*(S>=P(2,1)); 

% Draw from G and H given T
U = randn(n,1); V = randn(n,1); W = rhoG*U+sqrt(1-rhoG^2)*V; YG = W.*(U>=0)-W.*(U<0); YG = muG + sigmaG*YG;
U = randn(n,1); V = randn(n,1); W = rhoH*U+sqrt(1-rhoH^2)*V; YH = W.*(U>=0)-W.*(U<0); YH = muH + sigmaH*YH;

% Mix outcomes across types according to P
Y = T.*YG + (1-T).*YH;


function [lambda se iq kq] = EstimateProportionatA(Y,X,C,d,A)
% Definitions
Fyx = @(y,x) mean((Y<=y).*(X-x==0))./mean((X-x==0)); % observable cum dist Y<=y|X=x
Syx = @(y,x) mean((Y> y).*(X-x==0))./mean((X-x==0)); % observable survival Y> y|X=x

% Choice of cut-off points (iota and kappa)
n0 = sum(X==0)      ; n1 = sum(X==1)      ; 
C0 = n0*log(log(n0)); C1 = n1*log(log(n1));  

switch A
    case 0
         % Estimate intermediate quantiles zeta-(1,0), zeta+(1,0)
         kappa = C*C0^d; r = quantile(Y(X==0),(n0-kappa)/n0); kq = (n0-kappa)/n0; % (n0-kappa)/n0-th quantile of cond. distribution 
         iota  = C*C0^d; l = quantile(Y(X==0),    iota  /n0); iq =       iota/n0; %      iota /n0-th quantile of cond. distribution 
         
         zeta_min = @(z1,z2) Fyx(l,z1)./Fyx(l,z2); zmin = zeta_min(1,0); vmin = zmin*(n0/n1+zmin)/iota ;
         zeta_max = @(z1,z2) Syx(r,z1)./Syx(r,z2); zmax = zeta_max(1,0); vmax = zmax*(n0/n1+zmax)/kappa;
         
         % Estimate mixing proportions at X=0
         lambda = abs(1-zmin)/abs(zmax-zmin);       
         dmin = (1-zmax)/(zmax-zmin)^2; dmax = -(1-zmin)/(zmax-zmin)^2; se = sqrt(dmin^2*vmin+dmax^2*vmax);
        
    case 1
         % Estimate intermediate quantiles zeta-(0,1), zeta+(0,1)
         kappa = C*C1^d; r = quantile(Y(X==1),(n1-kappa)/n1); kq = (n1-kappa)/n1; % (n1-kappa)/n1-th quantile of cond. distribution 
         iota  = C*C1^d; l = quantile(Y(X==1),    iota  /n1); iq =       iota/n1; %      iota /n1-th quantile of cond. distribution 
         
         zeta_min = @(z1,z2) Fyx(l,z1)./Fyx(l,z2); zmin = zeta_min(0,1); vmin = zmin*(n1/n0+zmin)/iota ;
         zeta_max = @(z1,z2) Syx(r,z1)./Syx(r,z2); zmax = zeta_max(0,1); vmax = zmax*(n1/n0+zmax)/kappa;
         
         % Estimate mixing proportions at X=1
         lambda = abs(1-zmin)/abs(zmax-zmin);       
         dmin = (1-zmax)/(zmax-zmin)^2; dmax = -(1-zmin)/(zmax-zmin)^2; se = sqrt(dmin^2*vmin+dmax^2*vmax);
end


function [Ghat Hhat SEGhat SEHhat] = EstimateComponentsonA(Y,X,C,d,A,base) % SEGhatcorrected SEHhatcorrected
% Definitions
Fyx = @(y,x) mean((Y<=y).*(X-x==0))./mean((X-x==0)); % observable cum dist Y<=y|X=x
Syx = @(y,x) mean((Y> y).*(X-x==0))./mean((X-x==0)); % observable survival Y> y|X=x

% Choice of cut-off points (iota and kappa)
n0 = sum(X==0)      ; n1 = sum(X==1)      ; 
C0 = n0*log(log(n0)); C1 = n1*log(log(n1));  

switch base
    case 0
         % Estimate intermediate quantiles zeta-(1,0), zeta+(1,0)
         kappa = C*C0^d; r = quantile(Y(X==0),(n0-kappa)/n0); % (n0-kappa)/n0-th quantile of cond. distribution 
         iota  = C*C0^d; l = quantile(Y(X==0),    iota/n0  ); %      iota /n0-th quantile of cond. distribution 
         
         zeta_min = @(z1,z2) Fyx(l,z1)./Fyx(l,z2); zmin = zeta_min(1,0); vmin = zmin*(n0/n1+zmin)/iota ;
         zeta_max = @(z1,z2) Syx(r,z1)./Syx(r,z2); zmax = zeta_max(1,0); vmax = zmax*(n0/n1+zmax)/kappa;
         
         % Function setup to estimate components on A
         G = @(a) Fyx(a,0)-(1./(1-zmin)).*(Fyx(a,0)-Fyx(a,1)); varG = @(a) (Fyx(a,0)-Fyx(a,1)).^2.*vmin./(1-zmin)^4; seG = @(a) sqrt(varG(a));
         H = @(a) Fyx(a,0)-(1./(1-zmax)).*(Fyx(a,0)-Fyx(a,1)); varH = @(a) (Fyx(a,0)-Fyx(a,1)).^2.*vmax./(1-zmax)^4; seH = @(a) sqrt(varH(a));
         
         % Small-sample corrected variance
%           varB  = @(b) mean((X==b).*(X~=b)); varA = @(a,b) mean((Y<=a & X==b).*(Y>a & X~=b)); covAB = @(a,b) mean((Y<=a & X==b))-mean((Y<=a)).*mean((X==b));
%           noise = @(a,b) (varA(a,b)-2*Fyx(a,b)*covAB(a,b)+Fyx(a,b)^2*varB(b))/(mean(X==b))^2;
%           dFA = 1-(1./(1-zmin)); 
%           dFB =   (1./(1-zmin)); Gpen = @(a) (dFA^2*noise(a,0)+ dFB^2*noise(a,1))/iota; 
%           
%           dFA = 1-(1./(1-zmax)); 
%           dFB =   (1./(1-zmax)); Hpen = @(a) (dFA^2*noise(a,0)+ dFB^2*noise(a,1))/iota; 
         
        
    case 1
         % Estimate intermediate quantiles zeta-(0,1), zeta+(0,1)
         kappa = C*C1^d; r = quantile(Y(X==1),(n1-kappa)/n1); % (n1-kappa)/n1-th quantile of cond. distribution 
         iota  = C*C1^d; l = quantile(Y(X==1),    iota/n1  ); %      iota /n1-th quantile of cond. distribution 
         
         zeta_min = @(z1,z2) Fyx(l,z1)./Fyx(l,z2); zmin = zeta_min(0,1); vmin = zmin*(n1/n0+zmin)/iota ;
         zeta_max = @(z1,z2) Syx(r,z1)./Syx(r,z2); zmax = zeta_max(0,1); vmax = zmax*(n1/n0+zmax)/kappa;
         
         % Function setup to estimate components on A
         G = @(a) Fyx(a,1)-(1./(1-zmin)).*(Fyx(a,1)-Fyx(a,0)); varG = @(a) (Fyx(a,1)-Fyx(a,0)).^2.*vmin./(1-zmin)^4; seG = @(a) sqrt(varG(a));
         H = @(a) Fyx(a,1)-(1./(1-zmax)).*(Fyx(a,1)-Fyx(a,0)); varH = @(a) (Fyx(a,1)-Fyx(a,0)).^2.*vmax./(1-zmax)^4; seH = @(a) sqrt(varH(a));
         
         % Small-sample corrected variance
%          varB  = @(b) mean((X==b).*(X~=b)); varA = @(a,b) mean((Y<=a & X==b).*(Y>a & X~=b)); covAB = @(a,b) mean((Y<=a & X==b))-mean((Y<=a)).*mean((X==b));
%          noise = @(a,b) (varA(a,b)-2*Fyx(a,b)*covAB(a,b)+Fyx(a,b)^2*varB(b))/(mean(X==b))^2;
%          dFA = 1-(1./(1-zmin)); 
%          dFB =   (1./(1-zmin)); Gpen = @(a) (dFA^2*noise(a,1)+ dFB^2*noise(a,0))/iota; 
%          
%          dFA = 1-(1./(1-zmax)); 
%          dFB =   (1./(1-zmax)); Hpen = @(a) (dFA^2*noise(a,1)+ dFB^2*noise(a,0))/iota;      
end

num = length(A);
for i = 1:num,
    a = A(i);
    Ghat(i) = G(a); SEGhat(i) = seG(a); %SEGhatcorrected(i) = seG(a)+Gpen(a);
    Hhat(i) = H(a); SEHhat(i) = seH(a); %SEHhatcorrected(i) = seH(a)+Hpen(a);
end


function [F] = SkewNormalCDF(X,mu,sigma,alpha)
Z = (X-mu)./sigma; F = normcdf(Z)-2*Owen(Z,alpha);