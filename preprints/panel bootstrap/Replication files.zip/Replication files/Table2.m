function Table2

clear; close all; clc;

% set parameters
R = 2500; 
B = 999; C =0; 

% initiate simulation for each design, in turn
rho0 = 0.00; Table2bis(rho0,R,B,C); 
rho0 = 0.50; Table2bis(rho0,R,B,C); 
rho0 = 1.00; Table2bis(rho0,R,B,C); 
rho0 = 1.50; Table2bis(rho0,R,B,C); 



function Table2bis(rho0,R,B,C)


%% DATA PREPARATION
% load data
load('lfp_psid_fs.txt','-ascii'); data = lfp_psid_fs; clear lfp_psid_fs; 
T =              9; % nr of time periods
N = size(data,1)/T; % nr of units
dim =          6+1;  % nr of regressors
% % select outcome and regressors
Y=zeros(    T,N); 
X=zeros(dim*T,N);
for i=1:N
    Y(:,i) = data(1+(i-1)*T:i*T,3); 
    for k=1:dim 
        X(1+(k-1)*T:k*T,i) = data(1+(i-1)*T:i*T,3+k); 
    end
end
YR = X(1+(1-1)*T:1*T,:); % lagged outcome 
X1 = X(1+(2-1)*T:2*T,:); % # of kids < 2 
X2 = X(1+(3-1)*T:3*T,:); % # of 2 < kids < 6
X3 = X(1+(4-1)*T:4*T,:); % # of kids > 6
X4 = X(1+(5-1)*T:5*T,:); % log(husband_income) (1995 $)
X5 = X(1+(6-1)*T:6*T,:); % age
X6 = X(1+(7-1)*T:7*T,:); % age squared
Y0 = X(1,:)            ; % initial condition

% drop units for which there is no change in labor-force participation
uninformative = mean(Y,1)==0 | mean(Y,1)==1 ;
 
Y( :,uninformative==1) = [];
YR(:,uninformative==1) = [];
Y0(:,uninformative==1) = [];
X1(:,uninformative==1) = []; X2(:,uninformative==1) = [];
X3(:,uninformative==1) = []; X4(:,uninformative==1) = [];
X5(:,uninformative==1) = []; X6(:,uninformative==1) = [];

[T N] = size(Y); clear data; 


%% SET PARAMETER VALUES FOR DGP
% compute the maximum likelihood estimates (theta0, fe0) from the original data
Z=cell(1,2);  Z{1}=Y; Z{2}=[YR;X1;X2;X3;X4;X5;X6]; 
[theta0 fe0]=NewtonPartitionedMax(@LoglProbit,zeros(dim,1),zeros(N,1),Z{:});
% set autoregressive coefficient to user-specified value rho0
theta0(1) = rho0; clear Z;

%% PERFORM SIMULATION FOR CHOSEN DGP
RHO = zeros(R,4); STD = zeros(R,2); CR = zeros(R,7); % LENGTH = zeros(R,7);
parfor r=1:R 
    [Z,~,~] =  DataGeneration(fe0,theta0,N,T,Y0,X1,X2,X3,X4,X5,X6); 
    % maximum likelihood estimator
    [mle fe]=NewtonPartitionedMax(@LoglProbit,zeros(dim,1),zeros(N,1),Z{:});
    % Fisher information estimator
    [~, ~, ~,Htheta, Hfe, Hfetheta]=LoglProbit(mle,fe,Z{:});
    H1 = [Htheta  , Hfetheta']; H2 = [Hfetheta, diag(Hfe)]; Information = -[H1;H2]/(N*T);
    % std error and confidence intervals
    avar = inv(Information)/(N*T); pavar = avar(1:length(mle),1:length(mle)); 
    se=sqrt(diag(pavar));
    ci0 = [mle-1.96*se, mle+1.96*se];
    % Hahn-Kuersteiner correction
    hk=mle-HKProbit(mle,fe,Z{:},1); cia = [hk-1.96*se, hk+1.96*se];
     % Fernandez-Val correction
    fv=mle-FVProbit(mle,fe,Z{:},1); cib = [fv-1.96*se, fv+1.96*se];
    % bootstrap inference
    [ci1 ci2 ci3 ci4 bias stde] = DoubleBootstrapInference(fe,mle,se,N,T,Y0,X1,X2,X3,X4,X5,X6,B,C);
    bc_median = mle-bias(:,1); 
    bc_mean   = mle-bias(:,2);

    RHO(r,:) = [mle(1), hk(1), fv(1), bc_median(1)];
    STD(r,:) = [se(1), stde(1)];
    CR(r,:) = [rho0 >= ci0(1,1) & rho0<=ci0(1,2),...
               rho0 >= cia(1,1) & rho0<=cia(1,2),...
               rho0 >= cib(1,1) & rho0<=cib(1,2),...
               rho0 >= ci1(1,1) & rho0<=ci1(1,2),...
               rho0 >= ci3(1,1) & rho0<=ci3(1,2),...
               rho0 >= ci2(1,1) & rho0<=ci2(1,2),...
               rho0 >= ci4(1,1) & rho0<=ci4(1,2)];  
end


% write away results to Table2.txt

fileID = fopen('Table2.txt','a'); fprintf(fileID, 'Table 2 \n\n');

fprintf(fileID, 'Method Bias Standard deviation Coverage rate \n\n');
fprintf(fileID, '               true value %6.3f  \n\n',rho0);

towrite = [mean(RHO(:,1))-rho0 std(RHO(:,1)) mean(CR(:,1))];
fprintf(fileID,'Maximum likelihood %6.3f %6.3f %6.3f\n',towrite);
towrite = [mean(RHO(:,2))-rho0 std(RHO(:,2)) mean(CR(:,2))];
fprintf(fileID,'Hahn-Kuersteiner %6.3f %6.3f %6.3f\n',towrite);
towrite = [mean(RHO(:,3))-rho0 std(RHO(:,3)) mean(CR(:,3))];
fprintf(fileID,'Fernandez-Val %6.3f %6.3f %6.3f\n',towrite);
towrite = [mean(RHO(:,4))-rho0 std(RHO(:,4)) mean(CR(:,4))];
fprintf(fileID,'(Basic) bootstrap %6.3f %6.3f %6.3f\n',towrite);


fclose(fileID);





function [ci1 ci2 ci3 ci4 bias stde] = DoubleBootstrapInference(FE,theta,std,N,T,Y0,X1,X2,X3,X4,X5,X6,B,C)
%B = 999; C = floor(10*sqrt(B));
dim = length(theta);
MLE1 = zeros(B,  dim); Tstat1 = zeros(B,  dim); STD1 = MLE1; 
MLE2 = zeros(B,C,dim); Tstat2 = zeros(B,C,dim); STD2 = MLE2; 

for b=1:B
   % parametric data replication
   [Z1,~,NN1] =  DataGeneration(FE,theta,N,T,Y0,X1,X2,X3,X4,X5,X6); 
   % estimation
   [mle1 fe1 logl flag iter]=NewtonPartitionedMax(@LoglProbit,zeros(dim,1),zeros(NN1,1),Z1{:});
   % std error calculation
   [logl gtheta gfe Htheta Hfe Hfetheta]=LoglProbit(mle1,fe1,Z1{:});
    H1 = [Htheta  , Hfetheta']; H2 = [Hfetheta, diag(Hfe)]; Information = -[H1;H2]/(NN1*T);
    avar = inv(Information)/(NN1*T); pavar = avar(1:length(mle1),1:length(mle1)); 
    stdb1=sqrt(diag(pavar));

    MLE1(b,:) = mle1-theta; Tstat1(b,:) = (mle1-theta)./stdb1; STD1(b,:) = stdb1;
  
if C>0    
   for c=1:C   
      [Z2,~,NN2] =  DataGeneration(fe1,mle1,NN1,T,Y0,X1,X2,X3,X4,X5,X6); 
      [mle2 fe2 logl flag iter]=NewtonPartitionedMax(@LoglProbit,zeros(dim,1),zeros(NN2,1),Z2{:});
      [logl gtheta gfe Htheta Hfe Hfetheta]=LoglProbit(mle2,fe2,Z2{:});
       H1 = [Htheta  , Hfetheta']; H2 = [Hfetheta, diag(Hfe)]; Information = -[H1;H2]/(NN2*T);
       avar = inv(Information)/(NN2*T); pavar = avar(1:length(mle2),1:length(mle2)); 
       stdb2=sqrt(diag(pavar));

       MLE2(b,c,:) = mle2-mle1; Tstat2(b,c,:) = (mle2-mle1)./stdb2; STD2(b,c,:) = stdb2; 
   end  
end

end

ci1 = zeros(dim,2); ci2 = ci1; ci3 = ci1; ci4 = ci1; bias = zeros(dim,2); stde = zeros(dim,1);
for k=1:dim
    ci1(k,:) = [theta(k) -        quantile(  MLE1(:,k),     .975), theta(k) -        quantile(  MLE1(:,k),     .025)];
    ci2(k,:) = [theta(k) - std(k)*quantile(Tstat1(:,k),     .975), theta(k) - std(k)*quantile(Tstat1(:,k),     .025)];

    bias(k,:) = [quantile(  MLE1(:,k),.50), mean(MLE1(:,k))];
    stde(k,:) = [sqrt(var(MLE1(:,k)))];

    if C>0

    pbeta975 = @(beta) (mean(MLE1(:,k)+theta(k) - quantile(MLE2(:,:,k),beta*(0<beta && beta<1)+0.001*(beta<0)+0.999*(beta>1),2) <= theta(k))-.975).^2; 
    b975 = fminsearch(pbeta975,.975); 

    pbeta025 = @(beta) (mean(MLE1(:,k)+theta(k) - quantile(MLE2(:,:,k),beta*(0<beta && beta<1)+0.001*(beta<0)+0.999*(beta>1),2) <= theta(k))-.025).^2; 
    b025 = fminsearch(pbeta025,.025); 

    if b025<0, b025 = 0.001; end; if b025>1, b025 = .999; end
    if b975<0, b975 = 0.001; end; if b975>1, b975 = .999; end

    ci3(k,:) = [theta(k) - quantile(MLE1(:,k),     b975), theta(k) - quantile(MLE1(:,k),     b025)];


    pbeta975 = @(beta) (mean(MLE1(:,k)+theta(k) - STD1(:,k).*quantile(Tstat2(:,:,k),beta*(0<beta && beta<1)+0.001*(beta<0)+0.999*(beta>1),2) <= theta(k))-.975).^2; 
    b975 = fminsearch(pbeta975,.975); 

    pbeta025 = @(beta) (mean(MLE1(:,k)+theta(k) - STD1(:,k).*quantile(Tstat2(:,:,k),beta*(0<beta && beta<1)+0.001*(beta<0)+0.999*(beta>1),2) <= theta(k))-.025).^2; 
    b025 = fminsearch(pbeta025,.025); 

    if b025<0, b025 = 0.001; end; if b025>1, b025 = .999; end
    if b975<0, b975 = 0.001; end; if b975>1, b975 = .999; end

    ci4(k,:) = [theta(k) - std(k)*quantile(Tstat1(:,k),     b975), theta(k) - std(k)*quantile(Tstat1(:,k),     b025)];
    
    else
        ci3(k,:) = [0, 0];
        ci4(k,:) = [0, 0];
    end
end



function [Z,Y0,N] =  DataGeneration(fe,theta,N,T,Y0,X1,X2,X3,X4,X5,X6)
% Generate data Y = (T+1)xN matrix from probit model; passed along as cell array Z
Y=zeros(T+1,N); 
Y(1,:) = Y0;
error = randn(T,N);
for t=2:T+1
    Y(t,:)=(fe'+theta(1)*Y(t-1,:)+theta(2)*X1(t-1,:)+theta(3)*X2(t-1,:)+theta(4)*X3(t-1,:)+theta(5)*X4(t-1,:)+theta(6)*X5(t-1,:)+theta(7)*X6(t-1,:)+error(t-1,:))>=0;
end
YL=Y; YR=Y; YL(1,:)=[]; YR(end,:)=[];
Z=cell(1,2);  Z{1}=YL; Z{2}=[YR;X1;X2;X3;X4;X5;X6];


function bias=HKProbit(mle,fe,Y,X,m) % m is bandwidth parameter
% computes bias approximation from Hahn-Kuersteiner (2011)
[T N]=size(Y); K = length(mle);
I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end; 
s=max(std(I)); ss=mean(mean(I)); I=(I-ss)/s;

F=normcdf(I); ind1=F==1; ind0=F==0; ind=ind1+ind0; succes=ind==0; 

A=1-F; logF=log(F);
       logA=log(A); 


logf=-0.5*(log(2*pi)+I.*I);
logFA=logF+logA;  B=exp(logf-logFA); C=-I.*B; D=(I.*I-1).*B; 
E=Y-F;

E=E.*succes;  E(isnan(E)==1)=0; E(isinf(E)==1)=0;
B=B.*succes;  B(isnan(B)==1)=0; B(isinf(B)==1)=0;
C=C.*succes;  C(isnan(C)==1)=0; C(isinf(C)==1)=0;


EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB;

H=H.*succes;  H(isnan(H)==1)=0; H(isinf(H)==1)=0;
J=J.*succes;  J(isnan(J)==1)=0; J(isinf(J)==1)=0;

HH=sum(H); HH(HH==0)=realmax;

for k=1:K, DFETHETA{k} = -ones(T,1)*(sum(X(1+(k-1)*T:k*T,:).*H) ./HH); end

for k=1:K,    
    for kk=1:K, 
        DFETHETATHETA{k,kk} = ones(T,1)*((sum(J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*sum(X(1+(k-1)*T:k*T,:).*H)...
                            - sum(X(1+(k-1)*T:k*T,:).*J.*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})).*HH)./((HH).^2));
    end
end

V=EB; Vfe=H; Vfefe=J;
for k=1:K,        
    Utheta{k}  = EB.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k});
    Uthetafe{k}=  H.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k});
    for kk=1:K,
        Uthetatheta{k,kk} = H.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}).*(X(1+(kk-1)*T:kk*T,:)+DFETHETA{kk})+EB.*DFETHETATHETA{k,kk};
    end
    Uthetafefe{k}=J.*(X(1+(k-1)*T:k*T,:)+DFETHETA{k}) ;
end
    
    
% compute spectra and cross-spectra
M=(-m:1:m); GVV=zeros(length(M),N); GVUtheta=cell(1,K); for k=1:K, GVUtheta{k}=zeros(length(M),N); end 
for j=1:length(M)
    l=max(1,M(j)+1); u=min(T,T+M(j));
    gVV =V(l:u,:).*V(l-M(j):u-M(j),:);    GVV(j,:) =mean(gVV);
    for k=1:K, gVU=V(l:u,:).*Uthetafe{k}(l-M(j):u-M(j),:); GVUtheta{k}(j,:)=mean(gVU); end
end
fVV=sum(GVV);  fVUtheta=cell(1,K); for k=1:K, fVUtheta{k} = sum(GVUtheta{k}); end


% form bias estimate
DEN=zeros(K,K); NUM=zeros(K,1);
for k=1:K, for kk=1:K, DEN(k,kk) = mean(mean(Uthetatheta{k,kk})); end; 
           NUM(k) = mean(fVUtheta{k}./mean(Vfe)-(mean(Uthetafefe{k}).*fVV)./(2*(mean(Vfe)).^2)); 
end
c = rcond(DEN); 
if isnan(c)==1,  
    disp('non-defined conditioning number')
end
bias=1/T*(inv(DEN)*NUM); 



function [bias]=FVProbit(mle,fe,Y,X,m) % m is bandwidth parameter
% computes bias approximation for Probit from Fernandez-Val (2009)
[T N]=size(Y); K = length(mle);
I=ones(T,1)*fe'; for k=1:K, I = I+mle(k)*X(1+(k-1)*T:k*T,:); end; 

F=normcdf(I); ind1=F==1; ind0=F==0; ind=ind1+ind0; succes=ind==0;


A=1-F; logF=log(F);
       logA=log(A);


logf=-0.5*(log(2*pi)+I.*I);
logFA=logF+logA;  B=exp(logf-logFA); C=-I.*B; D=(I.*I-1).*B; 
E=Y-F;

E=E.*succes;  E(isnan(E)==1)=0; E(isinf(E)==1)=0;
B=B.*succes;  B(isnan(B)==1)=0; B(isinf(B)==1)=0;
C=C.*succes;  C(isnan(C)==1)=0; C(isinf(C)==1)=0;


EB=E.*B; EC=E.*C; ED=E.*D; H=EC-EB.*EB; J=ED-3*EB.*EC+2*EB.*EB.*EB;


H=H.*succes;  H(isnan(H)==1)=0; H(isinf(H)==1)=0;
J=J.*succes;  J(isnan(J)==1)=0; J(isinf(J)==1)=0;


h=B; f=exp(logf); 
f=f.*succes;  f(isnan(f)==1)=0; f(isinf(f)==1)=0; 
g=C./B.*f;   g(isnan(g)==1)=0; g(isinf(g)==1)=0;


sigma=1./mean(h.*f); sigma(isnan(sigma)==1)=0; sigma(isinf(sigma)==1)=0;  psi = (h.*E).*(ones(T,1)*sigma); 
for k=1:K, 
    for kk=1:K, 
        jj      = mean(h.*f.*X(1+(k-1)*T:k*T,:).*X(1+(kk-1)*T:kk*T,:))- mean(h.*f.*X(1+(k-1)*T:k*T,:)).*mean(h.*f.*X(1+(kk-1)*T:kk*T,:)).*sigma; 
        j(k,kk) = mean(jj);
    end
end

betabeta=zeros(1,N);
for mm=1:m, for t=mm+1:T, betabeta = betabeta+(h(t,:).*f(t,:).*psi(t-mm,:))/((T-mm)); end; end
beta = -mean(h.*g).*sigma.^2/2-betabeta.*sigma;

bb = cell(1,K); 
for k=1:K, 
    bb{k}=zeros(1,N); x=X(1+(k-1)*T:k*T,:); 
    for mm=1:m, for t=mm+1:T, bb{k} = bb{k}+(h(t,:).*f(t,:).*x(t,:).*psi(t-mm,:))/((T-mm)); end; end
    b(k) = mean(-mean(h.*f.*x).*beta-mean(h.*g.*x).*sigma/2-bb{k});
end
bias = 1/T*(inv(j)*b');

function [logl gtheta gfe Htheta Hfe Hfetheta]=LoglProbit(mle,fe,YY,XX)
% computes likelihood (logl), partitioned score (g) and partitioned hessian (H)
[T N]=size(YY); K = length(mle); II=ones(T,1)*fe'; for k=1:K, II = II+mle(k)*XX(1+(k-1)*T:k*T,:); end
F=normcdf(II); A=1-F; logF=log(F); logA=log(A); logFA=logF+logA;
logf=-0.5*(log(2*pi)+II.*II); B=exp(logf-logFA); C=-II.*B;  % B=f/(F(1-F)) C=df/(F(1-F)) 
E=YY-F; EB=E.*B; EC=E.*C; H=EC-EB.*EB; for k=1:K, XH{k}=XX(1+(k-1)*T:k*T,:).*H; end

I=II; Y=YY   ; X=XX;
logl=sum(sum(Y.*logF+(1-Y).*logA)); gfe=sum(EB)'; Hfe=sum(H)';
for k=1:K,
    gtheta(k)=sum(sum(X(1+(k-1)*T:k*T,:).*EB)); Hfetheta(:,k)=sum(XH{k})';
    for kk=1:K, Htheta(k,kk)=sum(sum(X(1+(k-1)*T:k*T,:).*XH{kk}))  ; end    
end
gtheta=gtheta';



function [x1,x2,f,condition,it]=NewtonPartitionedMax(FUN,x1,x2,varargin)
% maximises FUN, starting at (x1,x2) by Newton-Raphson method
% while exploiting sparsity of hessian 
tol=1e-4; maxit=100; smalleststep=.5^20;
it=1; condition=1; improvement=1; k=length(x1);
[f g1 g2 H1 H2 H21]=feval(FUN,x1,x2,varargin{:});
while it<=maxit && condition==1 && improvement==1
    J21=H21./(H2*ones(1,k)); A=inv(H1-H21'*J21); % pinv
    d1=-A*(g1-J21'*g2); d2=-g2./H2-J21*d1;
    step=1; improvement=0;
    while step>=smalleststep && improvement==0
        [ff gg1 gg2 HH1 HH2 HH21]=feval(FUN,x1+step*d1,x2+step*d2,varargin{:});
        if (ff-f)/abs(f)>=-1e-6
            improvement=1; condition=sqrt(step*step*(d1'*d1+d2'*d2))>tol & (ff-f)>tol;
            x1=x1+step*d1; f=ff; g1=gg1; H1=HH1; H21=HH21;
            x2=x2+step*d2;       g2=gg2; H2=HH2;
        else
            step=step/2;
        end
    end
    it=it+1;
end
it=it-1;

